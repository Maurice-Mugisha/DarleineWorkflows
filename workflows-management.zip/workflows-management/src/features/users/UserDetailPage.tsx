import { Link } from "react-router-dom";
import { ArrowLeft, Pencil, Mail, Briefcase, ShieldCheck, User as UserIcon } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { Badge } from "@/shared/ui/badge";
import { Card, CardContent } from "@/shared/ui/card";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PageLoader from "@/shared/components/PageLoader";
import InitialsAvatar from "@/shared/components/InitialsAvatar";
import InfoField from "@/shared/components/InfoField";
import NotFoundPage from "@/features/errors/NotFoundPage";
import useUserDetailPage from "@/features/users/hooks/useUserDetailPage";
import getUserInitials from "@/features/users/utils/getUserInitials";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function UserDetailPage() {
  const { user, roleLabel, isLoading, isNotFound } = useUserDetailPage();

  if (isLoading) {
    return (
      <DashboardLayout title="Member details" subtitle="View this member's profile and role.">
        <PageLoader />
      </DashboardLayout>
    );
  }

  if (isNotFound || user === null) {
    return <NotFoundPage />;
  }

  const fullName = `${user.first_name} ${user.last_name}`;
  const editPath = ROUTE_PATHS.editUser.replace(":userId", user.id);

  return (
    <DashboardLayout title="Member details" subtitle="View this member's profile and role.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.members}>
            <ArrowLeft />
            Back to members
          </Link>
        </Button>

        <Card className="from-primary/10 via-card to-card gap-0 bg-gradient-to-br py-0">
          <CardContent className="p-6 sm:p-8">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="flex items-center gap-4">
                <InitialsAvatar
                  initials={getUserInitials(user)}
                  className="size-16 text-xl shadow-sm"
                />
                <div className="min-w-0">
                  <h2 className="text-2xl font-semibold tracking-tight">{fullName}</h2>
                  <p className="text-muted-foreground mt-0.5">{user.job_title}</p>
                  <Badge className="mt-2">{roleLabel}</Badge>
                </div>
              </div>
              <Button asChild>
                <Link to={editPath} state={{ user }}>
                  <Pencil />
                  Edit
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4 sm:grid-cols-2">
          <InfoField icon={UserIcon} label="First name" value={user.first_name} />
          <InfoField icon={UserIcon} label="Last name" value={user.last_name} />
          <InfoField icon={Mail} label="Email" value={user.email} />
          <InfoField icon={Briefcase} label="Job title" value={user.job_title} />
          <InfoField icon={ShieldCheck} label="Role" value={roleLabel} />
        </div>
      </div>
    </DashboardLayout>
  );
}
