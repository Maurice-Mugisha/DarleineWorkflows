import { Link } from "react-router-dom";
import { Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import UsersList from "@/features/users/components/UsersList";
import useUsersPage from "@/features/users/hooks/useUsersPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function UsersPage() {
  const { users, roleNameById, isLoading, handleDeleteUser } = useUsersPage();

  const headerAction = (
    <Button asChild>
      <Link to={ROUTE_PATHS.createUser}>
        <Plus />
        New member
      </Link>
    </Button>
  );

  return (
    <DashboardLayout
      title="Members"
      subtitle="Manage the people in your workspace and their roles."
      action={headerAction}
    >
      <UsersList
        users={users}
        roleNameById={roleNameById}
        isLoading={isLoading}
        onDelete={handleDeleteUser}
      />
    </DashboardLayout>
  );
}
