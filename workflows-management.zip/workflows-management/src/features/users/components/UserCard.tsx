import { Badge } from "@/shared/ui/badge";
import InitialsAvatar from "@/shared/components/InitialsAvatar";
import UserActionsMenu from "@/features/users/components/UserActionsMenu";
import getUserRoleLabel from "@/features/users/utils/getUserRoleLabel";
import getUserInitials from "@/features/users/utils/getUserInitials";
import type { User } from "@/features/users/types/user";

interface UserCardProps {
  user: User;
  roleNameById: Record<string, string>;
  onDelete: (userId: string) => Promise<void>;
}

export default function UserCard({ user, roleNameById, onDelete }: UserCardProps) {
  const roleLabel = getUserRoleLabel(user, roleNameById);

  return (
    <div className="border-border bg-card flex items-start gap-3 rounded-md border p-4">
      <InitialsAvatar initials={getUserInitials(user)} />
      <div className="min-w-0 flex-1">
        <p className="font-medium">
          {user.first_name} {user.last_name}
        </p>
        <p className="text-muted-foreground truncate text-sm">{user.email}</p>
        <p className="text-muted-foreground text-sm">{user.job_title}</p>
        <Badge variant="secondary" className="mt-2">
          {roleLabel}
        </Badge>
      </div>
      <UserActionsMenu user={user} roleName={roleLabel} onDelete={onDelete} />
    </div>
  );
}
