import { useMemo } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/shared/ui/card";
import TextField from "@/shared/components/TextField";
import SelectField from "@/shared/components/SelectField";
import useUserForm from "@/features/users/hooks/useUserForm";
import { NO_ROLE_VALUE } from "@/features/users/schemas/userSchema";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { User } from "@/features/users/types/user";

interface UserFormProps {
  existingUser?: User;
}

export default function UserForm({ existingUser }: UserFormProps) {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit, roles, isLoadingRoles } =
    useUserForm({ existingUser });

  const isEditing = existingUser !== undefined;

  const roleOptions = useMemo(
    () => [
      { value: NO_ROLE_VALUE, label: "No role" },
      ...roles.map((role) => ({ value: role.id, label: role.name })),
    ],
    [roles],
  );

  return (
    <form noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Member details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-5">
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                id="firstName"
                label="First name"
                placeholder="Jane"
                value={values.firstName}
                error={errors.firstName}
                required
                onValueChange={getFieldHandler("firstName")}
              />
              <TextField
                id="lastName"
                label="Last name"
                placeholder="Doe"
                value={values.lastName}
                error={errors.lastName}
                required
                onValueChange={getFieldHandler("lastName")}
              />
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                id="email"
                label="Email"
                type="email"
                placeholder="jane@company.com"
                value={values.email}
                error={errors.email}
                required
                onValueChange={getFieldHandler("email")}
              />
              <TextField
                id="jobTitle"
                label="Job title"
                placeholder="Operations Manager"
                value={values.jobTitle}
                error={errors.jobTitle}
                required
                onValueChange={getFieldHandler("jobTitle")}
              />
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                id="password"
                label="Password"
                type="password"
                placeholder={isEditing ? "Leave blank to keep current" : "At least 8 characters"}
                value={values.password}
                error={errors.password}
                required={!isEditing}
                onValueChange={getFieldHandler("password")}
              />
              <SelectField
                id="roleId"
                label="Role"
                placeholder={isLoadingRoles ? "Loading roles..." : "Select a role"}
                value={values.roleId}
                options={roleOptions}
                error={errors.roleId}
                onValueChange={getFieldHandler("roleId")}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="gap-3">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : isEditing ? "Save changes" : "Create member"}
          </Button>
          <Button type="button" variant="ghost" asChild>
            <Link to={ROUTE_PATHS.members}>Cancel</Link>
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
