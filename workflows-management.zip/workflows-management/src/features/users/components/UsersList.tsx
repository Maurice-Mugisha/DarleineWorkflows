import { Skeleton } from "@/shared/ui/skeleton";
import UsersTable from "@/features/users/components/UsersTable";
import UserCard from "@/features/users/components/UserCard";
import UsersEmptyState from "@/features/users/components/UsersEmptyState";
import type { User } from "@/features/users/types/user";

interface UsersListProps {
  users: User[];
  roleNameById: Record<string, string>;
  isLoading: boolean;
  onDelete: (userId: string) => Promise<void>;
}

function LoadingRows() {
  return (
    <div className="flex flex-col gap-3">
      {Array.from({ length: 4 }).map((_, index) => (
        <div key={index} className="border-border rounded-lg border p-4">
          <Skeleton className="mb-2 h-5 w-48" />
          <Skeleton className="h-4 w-64" />
        </div>
      ))}
    </div>
  );
}

export default function UsersList({ users, roleNameById, isLoading, onDelete }: UsersListProps) {
  if (isLoading) {
    return <LoadingRows />;
  }

  if (users.length === 0) {
    return <UsersEmptyState />;
  }

  return (
    <>
      <div className="hidden md:block">
        <UsersTable users={users} roleNameById={roleNameById} onDelete={onDelete} />
      </div>
      <div className="flex flex-col gap-3 md:hidden">
        {users.map((user) => (
          <UserCard key={user.id} user={user} roleNameById={roleNameById} onDelete={onDelete} />
        ))}
      </div>
    </>
  );
}
