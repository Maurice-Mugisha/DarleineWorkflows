import { Link } from "react-router-dom";
import { Users, Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { ROUTE_PATHS } from "@/routes/routePaths";

const MEMBER_BENEFITS = [
  {
    text: "Invite the people who run your workflows and steps.",
    accent: "border-l-primary bg-primary/5",
  },
  {
    text: "Assign each member a role to control what they can access.",
    accent: "border-l-amber-500 bg-amber-50 dark:border-l-amber-400 dark:bg-amber-950/30",
  },
  {
    text: "Keep your workspace team organized in one place.",
    accent: "border-l-emerald-500 bg-emerald-50 dark:border-l-emerald-400 dark:bg-emerald-950/30",
  },
];

export default function UsersEmptyState() {
  return (
    <div className="border-border flex flex-col items-center rounded-xl border border-dashed py-16 text-center">
      <span className="bg-primary/10 text-primary mb-6 flex size-20 items-center justify-center rounded-2xl">
        <Users className="size-10" />
      </span>

      <h2 className="text-2xl font-semibold tracking-tight">No members yet</h2>
      <p className="text-muted-foreground mt-2 max-w-md">
        Add members to your workspace so your team can start running workflows together.
      </p>

      <ul className="mt-8 flex w-full max-w-lg flex-col gap-3">
        {MEMBER_BENEFITS.map((benefit) => (
          <li
            key={benefit.text}
            className={`border-border rounded-lg border-l-4 px-4 py-3 text-left text-sm ${benefit.accent}`}
          >
            {benefit.text}
          </li>
        ))}
      </ul>

      <Button size="lg" className="mt-8" asChild>
        <Link to={ROUTE_PATHS.createUser}>
          <Plus />
          Add your first member
        </Link>
      </Button>
    </div>
  );
}
