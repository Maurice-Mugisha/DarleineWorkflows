import { useState } from "react";
import { Link } from "react-router-dom";
import { MoreHorizontal, Eye, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/shared/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import ConfirmDialog from "@/shared/components/ConfirmDialog";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { User } from "@/features/users/types/user";

interface UserActionsMenuProps {
  user: User;
  roleName: string;
  onDelete: (userId: string) => Promise<void>;
}

export default function UserActionsMenu({ user, roleName, onDelete }: UserActionsMenuProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const fullName = `${user.first_name} ${user.last_name}`;
  const detailPath = ROUTE_PATHS.userDetail.replace(":userId", user.id);
  const editPath = ROUTE_PATHS.editUser.replace(":userId", user.id);

  const handleDelete = async () => {
    setIsDeleting(true);
    await onDelete(user.id);
    setIsDeleting(false);
    setShowDeleteDialog(false);
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="size-8 shrink-0"
            aria-label="Member actions"
          >
            <MoreHorizontal className="size-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem asChild>
            <Link to={detailPath} state={{ user, roleName }}>
              <Eye />
              View details
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link to={editPath} state={{ user }}>
              <Pencil />
              Update
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem variant="destructive" onClick={() => setShowDeleteDialog(true)}>
            <Trash2 />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onConfirm={handleDelete}
        onCancel={() => setShowDeleteDialog(false)}
        title="Delete member"
        message={`Are you sure you want to delete "${fullName}"? This action cannot be undone.`}
        isLoading={isDeleting}
      />
    </>
  );
}
