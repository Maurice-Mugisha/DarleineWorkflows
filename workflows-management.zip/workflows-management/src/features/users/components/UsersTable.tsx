import { Badge } from "@/shared/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/shared/ui/table";
import InitialsAvatar from "@/shared/components/InitialsAvatar";
import UserActionsMenu from "@/features/users/components/UserActionsMenu";
import getUserRoleLabel from "@/features/users/utils/getUserRoleLabel";
import getUserInitials from "@/features/users/utils/getUserInitials";
import type { User } from "@/features/users/types/user";

interface UsersTableProps {
  users: User[];
  roleNameById: Record<string, string>;
  onDelete: (userId: string) => Promise<void>;
}

export default function UsersTable({ users, roleNameById, onDelete }: UsersTableProps) {
  return (
    <div className="border-border overflow-hidden rounded-md border">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50 hover:bg-muted/50">
            <TableHead className="text-muted-foreground px-4 text-xs tracking-wide uppercase">
              Member
            </TableHead>
            <TableHead className="text-muted-foreground px-4 text-xs tracking-wide uppercase">
              Job title
            </TableHead>
            <TableHead className="text-muted-foreground px-4 text-xs tracking-wide uppercase">
              Role
            </TableHead>
            <TableHead className="w-12 px-4" />
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.map((user) => {
            const roleLabel = getUserRoleLabel(user, roleNameById);

            return (
              <TableRow key={user.id}>
                <TableCell className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <InitialsAvatar initials={getUserInitials(user)} className="size-9 text-xs" />
                    <div className="min-w-0">
                      <p className="font-medium">
                        {user.first_name} {user.last_name}
                      </p>
                      <p className="text-muted-foreground truncate text-sm">{user.email}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-muted-foreground px-4 py-3">{user.job_title}</TableCell>
                <TableCell className="px-4 py-3">
                  <Badge variant="secondary">{roleLabel}</Badge>
                </TableCell>
                <TableCell className="px-4 py-3 text-right">
                  <UserActionsMenu user={user} roleName={roleLabel} onDelete={onDelete} />
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}
