import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import UserForm from "@/features/users/components/UserForm";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function CreateUserPage() {
  return (
    <DashboardLayout title="Add member" subtitle="Invite a new member to your workspace.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.members}>
            <ArrowLeft />
            Back to members
          </Link>
        </Button>
        <UserForm />
      </div>
    </DashboardLayout>
  );
}
