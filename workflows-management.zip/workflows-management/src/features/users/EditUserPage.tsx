import { Link, useLocation, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PageLoader from "@/shared/components/PageLoader";
import NotFoundPage from "@/features/errors/NotFoundPage";
import UserForm from "@/features/users/components/UserForm";
import useResolvedEntity from "@/shared/hooks/useResolvedEntity";
import { fetchUserByIdRequest } from "@/features/users/services/userApi";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { User } from "@/features/users/types/user";

export default function EditUserPage() {
  const location = useLocation();
  const { userId } = useParams();
  const stateUser = (location.state as { user?: User } | null)?.user ?? null;

  const {
    entity: user,
    isLoading,
    isNotFound,
  } = useResolvedEntity<User>({
    stateEntity: stateUser,
    id: userId,
    fetchById: fetchUserByIdRequest,
  });

  if (isLoading) {
    return (
      <DashboardLayout title="Edit member" subtitle="Update this member's details.">
        <PageLoader />
      </DashboardLayout>
    );
  }

  if (isNotFound || user === null) {
    return <NotFoundPage />;
  }

  return (
    <DashboardLayout title="Edit member" subtitle="Update this member's details.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.members}>
            <ArrowLeft />
            Back to members
          </Link>
        </Button>
        <UserForm existingUser={user} />
      </div>
    </DashboardLayout>
  );
}
