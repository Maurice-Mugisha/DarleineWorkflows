import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";
import { fetchAllRolesRequest } from "@/features/roles/services/roleApi";
import { createUserRequest, updateUserRequest } from "@/features/users/services/userApi";
import buildUserPayload from "@/features/users/utils/buildUserPayload";
import {
  buildUserSchema,
  NO_ROLE_VALUE,
  type UserFormValues,
} from "@/features/users/schemas/userSchema";
import type { Role } from "@/features/roles/types/role";
import type { User } from "@/features/users/types/user";

interface UseUserFormOptions {
  existingUser?: User;
}

function buildInitialValues(existingUser?: User): UserFormValues {
  return {
    firstName: existingUser?.first_name ?? "",
    lastName: existingUser?.last_name ?? "",
    email: existingUser?.email ?? "",
    jobTitle: existingUser?.job_title ?? "",
    password: "",
    roleId: existingUser?.role_id ?? NO_ROLE_VALUE,
  };
}

export default function useUserForm({ existingUser }: UseUserFormOptions) {
  const navigate = useNavigate();
  const [roles, setRoles] = useState<Role[]>([]);
  const [isLoadingRoles, setIsLoadingRoles] = useState(true);

  const schema = useMemo(() => buildUserSchema(existingUser !== undefined), [existingUser]);

  useEffect(() => {
    let cancelled = false;

    fetchAllRolesRequest()
      .then((data) => {
        if (!cancelled) {
          setRoles(data);
        }
      })
      .catch(() => {
        if (!cancelled) {
          toast.error("Unable to load roles.");
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoadingRoles(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const form = useZodForm<UserFormValues>({
    schema,
    initialValues: buildInitialValues(existingUser),
    onValidSubmit: async (values) => {
      try {
        if (existingUser) {
          await updateUserRequest(buildUserPayload(values, existingUser));
          navigate(ROUTE_PATHS.members, { state: { userUpdated: true } });
        } else {
          await createUserRequest(buildUserPayload(values));
          navigate(ROUTE_PATHS.members, { state: { userCreated: true } });
        }
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to save the member. Please try again."));
      }
    },
  });

  return { ...form, roles, isLoadingRoles };
}
