import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import useResolvedEntity from "@/shared/hooks/useResolvedEntity";
import { fetchUserByIdRequest } from "@/features/users/services/userApi";
import { fetchAllRolesRequest } from "@/features/roles/services/roleApi";
import getUserRoleLabel from "@/features/users/utils/getUserRoleLabel";
import type { User } from "@/features/users/types/user";

export default function useUserDetailPage() {
  const location = useLocation();
  const { userId } = useParams();
  const state = location.state as { user?: User; roleName?: string } | null;
  const stateUser = state?.user ?? null;
  const stateRoleName = state?.roleName;

  const {
    entity: user,
    isLoading,
    isNotFound,
  } = useResolvedEntity<User>({
    stateEntity: stateUser,
    id: userId,
    fetchById: fetchUserByIdRequest,
  });

  const [roleNameById, setRoleNameById] = useState<Record<string, string>>({});

  useEffect(() => {
    if (stateRoleName !== undefined) {
      return;
    }

    let cancelled = false;
    fetchAllRolesRequest()
      .then((roles) => {
        if (!cancelled) {
          const lookup: Record<string, string> = {};
          for (const role of roles) {
            lookup[role.id] = role.name;
          }
          setRoleNameById(lookup);
        }
      })
      .catch(() => {
        // Role name is non-critical; falls back to "Unknown role".
      });

    return () => {
      cancelled = true;
    };
  }, [stateRoleName]);

  const roleLabel = stateRoleName ?? (user ? getUserRoleLabel(user, roleNameById) : "");

  return { user, roleLabel, isLoading, isNotFound };
}
