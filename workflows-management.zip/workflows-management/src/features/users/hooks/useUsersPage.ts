import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { fetchWorkspaceUsersRequest, deleteUserRequest } from "@/features/users/services/userApi";
import { fetchAllRolesRequest } from "@/features/roles/services/roleApi";
import type { User } from "@/features/users/types/user";

export default function useUsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [roleNameById, setRoleNameById] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(true);

  useNavigationSuccessToast("userCreated", "Member created successfully.");
  useNavigationSuccessToast("userUpdated", "Member updated successfully.");

  useEffect(() => {
    let cancelled = false;

    async function fetchUsers() {
      try {
        const data = await fetchWorkspaceUsersRequest();
        if (!cancelled) {
          setUsers(data);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load members."));
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    async function fetchRoles() {
      try {
        const data = await fetchAllRolesRequest();
        if (!cancelled) {
          const lookup: Record<string, string> = {};
          for (const role of data) {
            lookup[role.id] = role.name;
          }
          setRoleNameById(lookup);
        }
      } catch {
        // Role names are non-critical; the list falls back to "No role".
      }
    }

    fetchUsers();
    fetchRoles();

    return () => {
      cancelled = true;
    };
  }, []);

  const handleDeleteUser = async (userId: string) => {
    try {
      await deleteUserRequest(userId);
      setUsers((previousUsers) => previousUsers.filter((user) => user.id !== userId));
      toast.success("Member deleted.");
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to delete the member."));
    }
  };

  return { users, roleNameById, isLoading, handleDeleteUser };
}
