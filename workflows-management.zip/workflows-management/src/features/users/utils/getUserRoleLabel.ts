import type { User } from "@/features/users/types/user";

export default function getUserRoleLabel(user: User, roleNameById: Record<string, string>): string {
  if (!user.role_id) {
    return "No role";
  }
  return roleNameById[user.role_id] ?? "Unknown role";
}
