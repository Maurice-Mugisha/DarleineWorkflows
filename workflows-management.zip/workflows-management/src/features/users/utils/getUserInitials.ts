import type { User } from "@/features/users/types/user";

export default function getUserInitials(user: User): string {
  const first = user.first_name.trim().charAt(0);
  const last = user.last_name.trim().charAt(0);
  const initials = `${first}${last}`.toUpperCase();
  return initials || user.email.charAt(0).toUpperCase() || "U";
}
