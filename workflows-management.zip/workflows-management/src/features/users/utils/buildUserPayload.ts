import getCurrentWorkspaceId from "@/shared/lib/currentWorkspace";
import { NO_ROLE_VALUE, type UserFormValues } from "@/features/users/schemas/userSchema";
import type { User } from "@/features/users/types/user";

export default function buildUserPayload(values: UserFormValues, existingUser?: User): User {
  const trimmedPassword = values.password.trim();

  return {
    id: existingUser?.id ?? crypto.randomUUID(),
    workspace_id: getCurrentWorkspaceId(),
    first_name: values.firstName.trim(),
    last_name: values.lastName.trim(),
    email: values.email.trim(),
    password: trimmedPassword !== "" ? trimmedPassword : (existingUser?.password ?? ""),
    job_title: values.jobTitle.trim(),
    role_id: values.roleId === NO_ROLE_VALUE ? undefined : values.roleId,
  };
}
