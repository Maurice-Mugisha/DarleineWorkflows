import { z } from "zod";

export function buildUserSchema(isEditing: boolean) {
  const passwordRule = isEditing
    ? z
        .string()
        .refine(
          (value) => value === "" || value.length >= 8,
          "Password must be at least 8 characters.",
        )
    : z.string().min(8, "Password must be at least 8 characters.");

  return z.object({
    firstName: z.string().min(2, "First name must be at least 2 characters."),
    lastName: z.string().min(2, "Last name must be at least 2 characters."),
    email: z.email("Enter a valid email address."),
    jobTitle: z.string().min(2, "Job title must be at least 2 characters."),
    password: passwordRule,
    roleId: z.string(),
  });
}

export type UserFormValues = z.infer<ReturnType<typeof buildUserSchema>>;

export const NO_ROLE_VALUE = "none";
