export interface User {
  id: string;
  workspace_id: string;
  first_name: string;
  last_name: string;
  email: string;
  password: string;
  job_title: string;
  role_id?: string | null;
}
