import apiClient from "@/shared/lib/apiClient";
import getCurrentWorkspaceId from "@/shared/lib/currentWorkspace";
import type { User } from "@/features/users/types/user";

export async function fetchWorkspaceUsersRequest(): Promise<User[]> {
  const response = await apiClient.get<User[]>(
    `/user/retrieve_all_users/${encodeURIComponent(getCurrentWorkspaceId())}`,
  );
  return response.data;
}

export async function fetchUserByIdRequest(userId: string): Promise<User> {
  const response = await apiClient.get<User>(`/user/retrieve_a_user/${encodeURIComponent(userId)}`);
  return response.data;
}

export async function createUserRequest(payload: User): Promise<void> {
  await apiClient.post("/user/register_a_user", payload);
}

export async function updateUserRequest(payload: User): Promise<void> {
  await apiClient.post("/user/update_a_user", payload);
}

export async function deleteUserRequest(userId: string): Promise<void> {
  await apiClient.delete("/user/delete_a_user", {
    params: { user_id: userId },
  });
}
