import apiClient from "@/shared/lib/apiClient";
import type { Workflow } from "@/features/workflows/types/workflow";
import getCurrentWorkspaceId from "@/shared/lib/currentWorkspace";

export async function createWorkflowRequest(payload: Workflow): Promise<void> {
  await apiClient.post("/workflow/register_a_workflow", payload);
}

export async function updateWorkflowRequest(payload: Workflow): Promise<void> {
  await apiClient.post("/workflow/update_a_workflow", payload);
}

export async function deleteWorkflowRequest(workflowId: string): Promise<void> {
  await apiClient.delete("/workflow/delete_a_workflow", {
    params: { workflow_id: workflowId },
  });
}

export async function fetchWorkspaceWorkflowsRequest(): Promise<Workflow[]> {
  const response = await apiClient.get<Workflow[]>(
    `/workflow/retrieve_all_workflows/${encodeURIComponent(getCurrentWorkspaceId())}`,
  );
  return response.data;
}

export async function fetchWorkflowByIdRequest(workflowId: string): Promise<Workflow> {
  const response = await apiClient.get<Workflow>(
    `/workflow/retrieve_a_workflow/${encodeURIComponent(workflowId)}`,
  );
  return response.data;
}
