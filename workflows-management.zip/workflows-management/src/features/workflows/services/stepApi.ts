import apiClient from "@/shared/lib/apiClient";
import type { CreateStepPayload, Step } from "@/features/workflows/types/step";

export async function createStepRequest(payload: CreateStepPayload): Promise<void> {
  await apiClient.post("/step/register_a_step", payload);
}

export async function fetchWorkflowStepsRequest(workflowId: string): Promise<Step[]> {
  const response = await apiClient.get<Step[]>(
    `/step/retrieve_workflow_steps/${encodeURIComponent(workflowId)}`,
  );
  return response.data;
}

export async function updateStepRequest(payload: Step): Promise<void> {
  await apiClient.post("/step/update_a_step", payload);
}

export async function deleteStepRequest(stepId: string): Promise<void> {
  await apiClient.delete("/step/delete_a_step", {
    params: { step_id: stepId },
  });
}
