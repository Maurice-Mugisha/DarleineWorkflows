import { Link } from "react-router-dom";
import { Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import WorkflowList from "@/features/workflows/components/WorkflowList";
import useWorkflowsPage from "@/features/workflows/hooks/useWorkflowsPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function WorkflowsPage() {
  const { workflows, isLoading } = useWorkflowsPage();

  const headerAction = (
    <Button asChild>
      <Link to={ROUTE_PATHS.createWorkflow}>
        <Plus />
        Create workflow
      </Link>
    </Button>
  );

  return (
    <DashboardLayout
      title="Workflows"
      subtitle="Design and manage the steps your team runs."
      action={headerAction}
    >
      <WorkflowList workflows={workflows} isLoading={isLoading} />
    </DashboardLayout>
  );
}
