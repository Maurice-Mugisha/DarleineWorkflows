import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PageLoader from "@/shared/components/PageLoader";
import NotFoundPage from "@/features/errors/NotFoundPage";
import CreateProcessForm from "@/features/workflows/components/CreateProcessForm";
import useCreateProcessPageData from "@/features/workflows/hooks/useCreateProcessPageData";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function CreateProcessPage() {
  const { workflow, nextStepNumber, isLoading, isNotFound } = useCreateProcessPageData();

  if (isLoading) {
    return (
      <DashboardLayout title="Add process" subtitle="Add a process to this workflow.">
        <PageLoader />
      </DashboardLayout>
    );
  }

  if (isNotFound || workflow === null) {
    return <NotFoundPage />;
  }

  const detailPath = ROUTE_PATHS.workflowDetail.replace(":workflowId", workflow.id);

  return (
    <DashboardLayout title="Add process" subtitle="Add a process to this workflow.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={detailPath} state={{ workflow }}>
            <ArrowLeft />
            Back to workflow
          </Link>
        </Button>
        <CreateProcessForm workflow={workflow} nextStepNumber={nextStepNumber} />
      </div>
    </DashboardLayout>
  );
}
