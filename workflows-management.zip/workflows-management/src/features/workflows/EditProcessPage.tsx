import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PageLoader from "@/shared/components/PageLoader";
import NotFoundPage from "@/features/errors/NotFoundPage";
import CreateProcessForm from "@/features/workflows/components/CreateProcessForm";
import useEditProcessPageData from "@/features/workflows/hooks/useEditProcessPageData";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function EditProcessPage() {
  const { workflow, step, isLoading, isNotFound } = useEditProcessPageData();

  if (isLoading) {
    return (
      <DashboardLayout title="Edit step" subtitle="Update this step.">
        <PageLoader />
      </DashboardLayout>
    );
  }

  if (isNotFound || workflow === null || step === null) {
    return <NotFoundPage />;
  }

  const detailPath = ROUTE_PATHS.workflowDetail.replace(":workflowId", workflow.id);

  return (
    <DashboardLayout title="Edit step" subtitle="Update this step.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={detailPath} state={{ workflow }}>
            <ArrowLeft />
            Back to workflow
          </Link>
        </Button>
        <CreateProcessForm
          workflow={workflow}
          nextStepNumber={step.step_number}
          existingStep={step}
        />
      </div>
    </DashboardLayout>
  );
}
