import { Link } from "react-router-dom";
import { ListChecks } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/shared/ui/card";
import { Badge } from "@/shared/ui/badge";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Workflow } from "@/features/workflows/types/workflow";

interface WorkflowCardProps {
  workflow: Workflow;
}

export default function WorkflowCard({ workflow }: WorkflowCardProps) {
  const isActive = workflow.status === "Active";
  const isMandatory = workflow.is_mandatory === "Yes";
  const detailPath = ROUTE_PATHS.workflowDetail.replace(":workflowId", workflow.id);

  return (
    <Link to={detailPath} state={{ workflow }} className="block">
      <Card className="h-full transition-shadow hover:shadow-md">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Badge variant={isActive ? "default" : "secondary"}>{workflow.status}</Badge>
            {isMandatory ? <Badge variant="outline">Mandatory</Badge> : null}
          </div>
          <CardTitle className="mt-2">{workflow.name}</CardTitle>
          <CardDescription>{workflow.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground flex items-center gap-2 text-sm">
            <ListChecks className="size-4" />
            {workflow.number_of_steps} steps
          </p>
        </CardContent>
      </Card>
    </Link>
  );
}
