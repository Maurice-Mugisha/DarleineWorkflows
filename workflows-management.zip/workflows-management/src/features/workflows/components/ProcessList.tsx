import { Link } from "react-router-dom";
import { Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { Badge } from "@/shared/ui/badge";
import { Card, CardContent } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import ProcessCard from "@/features/workflows/components/ProcessCard";
import ProcessEmptyState from "@/features/workflows/components/ProcessEmptyState";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Step } from "@/features/workflows/types/step";
import type { Workflow } from "@/features/workflows/types/workflow";

interface ProcessListProps {
  steps: Step[];
  workflow: Workflow;
  maxProcesses: number;
  roleNameById: Record<string, string>;
  isLoading: boolean;
  onDelete: (stepId: string) => Promise<void>;
}

function LoadingProcesses() {
  return (
    <div className="flex flex-col gap-4">
      {Array.from({ length: 2 }).map((_, index) => (
        <Card key={index}>
          <CardContent className="p-6">
            <Skeleton className="mb-2 h-5 w-32" />
            <Skeleton className="mb-1 h-4 w-full" />
            <Skeleton className="h-4 w-24" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default function ProcessList({
  steps,
  workflow,
  maxProcesses,
  roleNameById,
  isLoading,
  onDelete,
}: ProcessListProps) {
  const nextStepNumber = steps.length + 1;
  const hasReachedLimit = steps.length >= maxProcesses;
  const createProcessPath = ROUTE_PATHS.createProcess.replace(":workflowId", workflow.id);

  return (
    <section className="flex flex-col gap-4">
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <h2 className="text-lg font-semibold tracking-tight">Processes</h2>
          <Badge variant="secondary">
            {steps.length} / {maxProcesses}
          </Badge>
        </div>
        {!hasReachedLimit ? (
          <Button size="sm" asChild>
            <Link to={createProcessPath} state={{ workflow, nextStepNumber }}>
              <Plus />
              Add process
            </Link>
          </Button>
        ) : null}
      </div>

      {hasReachedLimit && !isLoading ? (
        <p className="text-muted-foreground text-sm">
          This workflow has reached its limit of {maxProcesses}{" "}
          {maxProcesses === 1 ? "process" : "processes"}.
        </p>
      ) : null}

      {isLoading ? (
        <LoadingProcesses />
      ) : steps.length === 0 ? (
        <ProcessEmptyState maxProcesses={maxProcesses} workflow={workflow} />
      ) : (
        <div className="flex flex-col gap-4">
          {steps.map((step, index) => (
            <ProcessCard
              key={step.id}
              step={step}
              workflow={workflow}
              roleNameById={roleNameById}
              isFirstOrOnly={steps.length === 1 || index === 0}
              onDelete={onDelete}
            />
          ))}
        </div>
      )}
    </section>
  );
}
