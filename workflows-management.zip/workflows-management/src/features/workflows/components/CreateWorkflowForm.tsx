import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/shared/ui/card";
import TextField from "@/shared/components/TextField";
import TextareaField from "@/shared/components/TextareaField";
import SelectField from "@/shared/components/SelectField";
import useCreateWorkflowForm from "@/features/workflows/hooks/useCreateWorkflowForm";
import { MANDATORY_OPTIONS, STATUS_OPTIONS } from "@/features/workflows/utils/workflowOptions";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Workflow } from "@/features/workflows/types/workflow";

interface CreateWorkflowFormProps {
  existingWorkflow?: Workflow;
}

export default function CreateWorkflowForm({ existingWorkflow }: CreateWorkflowFormProps) {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit } = useCreateWorkflowForm({
    existingWorkflow,
  });

  const isEditing = existingWorkflow !== undefined;
  const cancelTo = isEditing
    ? ROUTE_PATHS.workflowDetail.replace(":workflowId", existingWorkflow.id)
    : ROUTE_PATHS.workflows;

  return (
    <form noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Workflow details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-5">
            <TextField
              id="name"
              label="Workflow name"
              placeholder="Employee onboarding"
              value={values.name}
              error={errors.name}
              required
              onValueChange={getFieldHandler("name")}
            />

            <TextareaField
              id="description"
              label="Description"
              placeholder="What does this workflow manage?"
              value={values.description ?? ""}
              error={errors.description}
              onValueChange={getFieldHandler("description")}
            />

            <div className="grid gap-5 sm:grid-cols-2">
              <SelectField
                id="isMandatory"
                label="Mandatory"
                placeholder="Select"
                value={values.isMandatory}
                options={MANDATORY_OPTIONS}
                error={errors.isMandatory}
                required
                onValueChange={getFieldHandler("isMandatory")}
              />
              <TextField
                id="numberOfSteps"
                label="Number of steps"
                type="number"
                min={0}
                placeholder="0"
                value={values.numberOfSteps}
                error={errors.numberOfSteps}
                required
                onValueChange={getFieldHandler("numberOfSteps")}
              />
            </div>

            <SelectField
              id="status"
              label="Status"
              placeholder="Select a status"
              value={values.status}
              options={STATUS_OPTIONS}
              error={errors.status}
              required
              onValueChange={getFieldHandler("status")}
            />
          </div>
        </CardContent>
        <CardFooter className="gap-3">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : isEditing ? "Save changes" : "Create workflow"}
          </Button>
          <Button type="button" variant="ghost" asChild>
            <Link to={cancelTo}>Cancel</Link>
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
