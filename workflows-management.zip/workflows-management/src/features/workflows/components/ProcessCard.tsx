import { useState } from "react";
import { Link } from "react-router-dom";
import { MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import { Button } from "@/shared/ui/button";
import { Badge } from "@/shared/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/shared/ui/card";
import ConfirmDialog from "@/shared/components/ConfirmDialog";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Step } from "@/features/workflows/types/step";
import type { Workflow } from "@/features/workflows/types/workflow";

interface ProcessCardProps {
  step: Step;
  workflow: Workflow;
  roleNameById: Record<string, string>;
  isFirstOrOnly: boolean;
  onDelete: (stepId: string) => Promise<void>;
}

export default function ProcessCard({
  step,
  workflow,
  roleNameById,
  isFirstOrOnly,
  onDelete,
}: ProcessCardProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const percentageColor = step.percentage >= step.warning_threshold ? "bg-primary" : "bg-amber-500";
  const editProcessPath = ROUTE_PATHS.editProcess
    .replace(":workflowId", workflow.id)
    .replace(":stepId", step.id);

  const handleDelete = async () => {
    setIsDeleting(true);
    await onDelete(step.id);
    setIsDeleting(false);
    setShowDeleteDialog(false);
  };

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-3">
              <span className="text-muted-foreground flex size-8 items-center justify-center rounded-md border text-xs font-medium">
                {step.step_number}
              </span>
              <div>
                <CardTitle className="text-base">{step.name}</CardTitle>
                {step.description ? (
                  <CardDescription className="mt-1">{step.description}</CardDescription>
                ) : null}
              </div>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="size-8">
                  <MoreHorizontal className="size-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link to={editProcessPath} state={{ workflow, step }}>
                    <Pencil />
                    Edit
                  </Link>
                </DropdownMenuItem>
                {!isFirstOrOnly ? (
                  <DropdownMenuItem variant="destructive" onClick={() => setShowDeleteDialog(true)}>
                    <Trash2 />
                    Delete
                  </DropdownMenuItem>
                ) : null}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant={step.status === "Active" ? "default" : "secondary"}>
                {step.status}
              </Badge>
              <Badge variant="outline" className="font-mono text-xs">
                {step.code}
              </Badge>
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium">{step.percentage}%</span>
              </div>
              <div className="bg-muted h-1.5 w-full overflow-hidden rounded-full">
                <div
                  className={`h-full rounded-full ${percentageColor}`}
                  style={{ width: `${step.percentage}%` }}
                />
              </div>
            </div>
            <p className="text-muted-foreground text-xs">
              Warning threshold: {step.warning_threshold}%
              {step.percentage < step.warning_threshold ? (
                <span className="ml-1 font-medium text-amber-600 dark:text-amber-400">(below)</span>
              ) : null}
            </p>
            {step.role_id_list && step.role_id_list.length > 0 ? (
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-muted-foreground text-xs">Roles:</span>
                {step.role_id_list.map((roleId) => (
                  <Badge key={roleId} variant="outline">
                    {roleNameById[roleId] ?? "Unknown role"}
                  </Badge>
                ))}
              </div>
            ) : null}
          </div>
        </CardContent>
      </Card>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onConfirm={handleDelete}
        onCancel={() => setShowDeleteDialog(false)}
        title="Delete process"
        message={`Are you sure you want to delete process ${step.step_number} "${step.name}"? This action cannot be undone.`}
        isLoading={isDeleting}
      />
    </>
  );
}
