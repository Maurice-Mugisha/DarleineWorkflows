import { Link } from "react-router-dom";
import { Workflow } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { Skeleton } from "@/shared/ui/skeleton";
import WorkflowCard from "@/features/workflows/components/WorkflowCard";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Workflow as WorkflowType } from "@/features/workflows/types/workflow";

interface WorkflowListProps {
  workflows: WorkflowType[];
  isLoading?: boolean;
}

const EMPTY_STATE_BENEFITS = [
  {
    text: "Define repeatable processes your team can follow step by step.",
    accent: "border-l-primary bg-primary/5",
  },
  {
    text: "Track progress with percentages and warning thresholds.",
    accent: "border-l-amber-500 bg-amber-50 dark:border-l-amber-400 dark:bg-amber-950/30",
  },
  {
    text: "Keep every case visible so nothing slips through the cracks.",
    accent: "border-l-emerald-500 bg-emerald-50 dark:border-l-emerald-400 dark:bg-emerald-950/30",
  },
];

function LoadingCards() {
  return (
    <>
      {Array.from({ length: 3 }).map((_, index) => (
        <div key={index} className="border-border rounded-xl border p-6">
          <Skeleton className="mb-3 h-5 w-16" />
          <Skeleton className="mb-2 h-6 w-48" />
          <Skeleton className="mb-4 h-4 w-full" />
          <Skeleton className="h-4 w-24" />
        </div>
      ))}
    </>
  );
}

function EmptyState() {
  return (
    <div className="border-border flex flex-col items-center rounded-xl border border-dashed py-16 text-center">
      <span className="bg-primary/10 text-primary mb-6 flex size-20 items-center justify-center rounded-2xl">
        <Workflow className="size-10" />
      </span>

      <h2 className="text-2xl font-semibold tracking-tight">No workflows yet</h2>
      <p className="text-muted-foreground mt-2 max-w-md">
        Create your first workflow to start tracking processes with clarity.
      </p>

      <ul className="mt-8 flex w-full max-w-lg flex-col gap-3">
        {EMPTY_STATE_BENEFITS.map((benefit) => (
          <li
            key={benefit.text}
            className={`border-border rounded-lg border-l-4 px-4 py-3 text-left text-sm ${benefit.accent}`}
          >
            {benefit.text}
          </li>
        ))}
      </ul>

      <Button size="lg" className="mt-8" asChild>
        <Link to={ROUTE_PATHS.createWorkflow}>Create your first workflow</Link>
      </Button>
    </div>
  );
}

export default function WorkflowList({ workflows, isLoading = false }: WorkflowListProps) {
  if (isLoading) {
    return (
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <LoadingCards />
      </div>
    );
  }

  if (workflows.length === 0) {
    return <EmptyState />;
  }

  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {workflows.map((workflow) => (
        <WorkflowCard key={workflow.id} workflow={workflow} />
      ))}
    </div>
  );
}
