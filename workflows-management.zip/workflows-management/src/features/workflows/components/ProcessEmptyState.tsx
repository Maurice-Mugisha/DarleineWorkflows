import { Link } from "react-router-dom";
import { Waypoints, Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Workflow } from "@/features/workflows/types/workflow";

interface ProcessEmptyStateProps {
  maxProcesses: number;
  workflow: Workflow;
}

const PROCESS_BENEFITS = [
  {
    text: "Give each stage a clear owner and a defined order.",
    accent: "border-l-primary bg-primary/5",
  },
  {
    text: "Set progress and warning thresholds to catch delays early.",
    accent: "border-l-amber-500 bg-amber-50 dark:border-l-amber-400 dark:bg-amber-950/30",
  },
  {
    text: "See exactly where every case stands at a glance.",
    accent: "border-l-emerald-500 bg-emerald-50 dark:border-l-emerald-400 dark:bg-emerald-950/30",
  },
];

export default function ProcessEmptyState({ maxProcesses, workflow }: ProcessEmptyStateProps) {
  const createProcessPath = ROUTE_PATHS.createProcess.replace(":workflowId", workflow.id);

  return (
    <div className="border-border flex flex-col items-center rounded-xl border border-dashed py-14 text-center">
      <span className="bg-primary/10 text-primary mb-6 flex size-20 items-center justify-center rounded-2xl">
        <Waypoints className="size-10" />
      </span>

      <h3 className="text-2xl font-semibold tracking-tight">No processes yet</h3>
      <p className="text-muted-foreground mt-2 max-w-md">
        Break this workflow into ordered processes your team can follow, each with its own progress
        and warning threshold. This workflow can hold up to{" "}
        <span className="text-foreground font-medium">{maxProcesses}</span>{" "}
        {maxProcesses === 1 ? "process" : "processes"}.
      </p>

      <ul className="mt-8 flex w-full max-w-lg flex-col gap-3">
        {PROCESS_BENEFITS.map((benefit) => (
          <li
            key={benefit.text}
            className={`border-border rounded-lg border-l-4 px-4 py-3 text-left text-sm ${benefit.accent}`}
          >
            {benefit.text}
          </li>
        ))}
      </ul>

      <Button size="lg" className="mt-8" asChild>
        <Link to={createProcessPath} state={{ workflow, nextStepNumber: 1 }}>
          <Plus />
          Create your first process
        </Link>
      </Button>
    </div>
  );
}
