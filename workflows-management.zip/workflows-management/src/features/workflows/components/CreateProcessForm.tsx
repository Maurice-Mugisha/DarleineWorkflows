import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/shared/ui/card";
import { Separator } from "@/shared/ui/separator";
import TextField from "@/shared/components/TextField";
import TextareaField from "@/shared/components/TextareaField";
import SelectField from "@/shared/components/SelectField";
import useCreateProcessForm from "@/features/workflows/hooks/useCreateProcessForm";
import useProcessFormData from "@/features/workflows/hooks/useProcessFormData";
import RoleCheckboxGroup from "@/features/workflows/components/RoleCheckboxGroup";
import ProcessTimingFields from "@/features/workflows/components/ProcessTimingFields";
import { STATUS_OPTIONS } from "@/features/workflows/utils/workflowOptions";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Step } from "@/features/workflows/types/step";
import type { Workflow } from "@/features/workflows/types/workflow";

interface CreateProcessFormProps {
  workflow: Workflow;
  nextStepNumber: number;
  existingStep?: Step;
}

export default function CreateProcessForm({
  workflow,
  nextStepNumber,
  existingStep,
}: CreateProcessFormProps) {
  const { values, errors, isSubmitting, setFieldValue, getFieldHandler, handleSubmit } =
    useCreateProcessForm({ workflow, nextStepNumber, existingStep });
  const { roles, timeUnits, isLoading } = useProcessFormData();

  const isEditing = existingStep !== undefined;
  const stepNumber = existingStep?.step_number ?? nextStepNumber;
  const isFirstStep = stepNumber === 1;
  const detailPath = ROUTE_PATHS.workflowDetail.replace(":workflowId", workflow.id);

  const toggleRole = (roleId: string) => {
    const nextRoleIds = values.roleIds.includes(roleId)
      ? values.roleIds.filter((id) => id !== roleId)
      : [...values.roleIds, roleId];
    setFieldValue("roleIds", nextRoleIds);
  };

  return (
    <form noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Workfow Step Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-6">
            <TextField
              id="stepName"
              label="Step name"
              placeholder="Submit documents"
              value={values.name}
              error={errors.name}
              required
              onValueChange={getFieldHandler("name")}
            />

            <TextareaField
              id="stepDescription"
              label="Description"
              placeholder="What happens in this step?"
              value={values.description ?? ""}
              error={errors.description}
              onValueChange={getFieldHandler("description")}
            />

            <div className="grid gap-5 sm:grid-cols-3">
              <SelectField
                id="stepStatus"
                label="Status"
                placeholder="Select"
                value={values.status}
                options={STATUS_OPTIONS}
                error={errors.status}
                required
                onValueChange={getFieldHandler("status")}
              />
              <TextField
                id="stepPercentage"
                label="Percentage"
                type="number"
                min={0}
                placeholder="0"
                value={values.percentage}
                error={errors.percentage}
                required
                onValueChange={getFieldHandler("percentage")}
              />
              <TextField
                id="stepWarningThreshold"
                label="Warning threshold"
                type="number"
                min={0}
                placeholder="75"
                value={values.warningThreshold}
                error={errors.warningThreshold}
                required
                onValueChange={getFieldHandler("warningThreshold")}
              />
            </div>

            <Separator />

            <ProcessTimingFields
              values={values}
              errors={errors}
              timeUnits={timeUnits}
              isFirstStep={isFirstStep}
              getFieldHandler={getFieldHandler}
            />

            <Separator />

            <RoleCheckboxGroup
              roles={roles}
              selectedRoleIds={values.roleIds}
              isLoading={isLoading}
              onToggle={toggleRole}
            />
          </div>
        </CardContent>
        <CardFooter className="gap-3">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : isEditing ? "Save changes" : "Add workflow step"}
          </Button>
          <Button type="button" variant="ghost" asChild>
            <Link to={detailPath} state={{ workflow }}>
              Cancel
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
