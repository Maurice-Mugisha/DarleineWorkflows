import { Checkbox } from "@/shared/ui/checkbox";
import { Label } from "@/shared/ui/label";
import type { Role } from "@/features/roles/types/role";

interface RoleCheckboxGroupProps {
  roles: Role[];
  selectedRoleIds: string[];
  isLoading: boolean;
  onToggle: (roleId: string) => void;
}

export default function RoleCheckboxGroup({
  roles,
  selectedRoleIds,
  isLoading,
  onToggle,
}: RoleCheckboxGroupProps) {
  return (
    <div className="flex flex-col gap-2">
      <Label>Access roles</Label>
      <p className="text-muted-foreground text-sm">
        Choose which roles can access this step. You can pick as many as you need.
      </p>

      {isLoading ? (
        <p className="text-muted-foreground py-2 text-sm">Loading roles...</p>
      ) : roles.length === 0 ? (
        <p className="text-muted-foreground py-2 text-sm">No roles available yet.</p>
      ) : (
        <div className="flex flex-col gap-3 pt-1">
          {roles.map((role) => {
            const checkboxId = `role-${role.id}`;
            const isSelected = selectedRoleIds.includes(role.id);

            return (
              <div key={role.id} className="flex items-center gap-3">
                <Checkbox
                  id={checkboxId}
                  checked={isSelected}
                  onCheckedChange={() => onToggle(role.id)}
                  className="mt-0.5"
                />
                <Label
                  htmlFor={checkboxId}
                  className="flex flex-col items-start gap-0.5 font-normal"
                >
                  <span className="font-medium">{role.name}</span>
                  <span className="text-muted-foreground text-xs">{role.description}</span>
                </Label>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
