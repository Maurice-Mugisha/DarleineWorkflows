import { useMemo } from "react";
import TextField from "@/shared/components/TextField";
import SelectField from "@/shared/components/SelectField";
import { Label } from "@/shared/ui/label";
import type { CreateStepFormValues } from "@/features/workflows/schemas/createStepSchema";
import type { FieldErrors } from "@/shared/types/form";

interface ProcessTimingFieldsProps {
  values: CreateStepFormValues;
  errors: FieldErrors<CreateStepFormValues>;
  timeUnits: string[];
  isFirstStep: boolean;
  getFieldHandler: <Field extends keyof CreateStepFormValues>(
    field: Field,
  ) => (value: CreateStepFormValues[Field]) => void;
}

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

export default function ProcessTimingFields({
  values,
  errors,
  timeUnits,
  isFirstStep,
  getFieldHandler,
}: ProcessTimingFieldsProps) {
  const timeUnitOptions = useMemo(
    () => timeUnits.map((unit) => ({ value: unit, label: capitalize(unit) })),
    [timeUnits],
  );

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-col gap-3">
        <Label>Process step time</Label>
        <div className="grid gap-5 sm:grid-cols-2">
          <TextField
            id="processTimeValue"
            label="Value"
            type="number"
            min={0}
            placeholder="0"
            value={values.processTimeValue}
            error={errors.processTimeValue}
            required
            onValueChange={getFieldHandler("processTimeValue")}
          />
          <SelectField
            id="processTimeUnit"
            label="Unit"
            placeholder="Select a unit"
            value={values.processTimeUnit}
            options={timeUnitOptions}
            error={errors.processTimeUnit}
            required
            onValueChange={getFieldHandler("processTimeUnit")}
          />
        </div>
      </div>

      <div className="flex flex-col gap-3">
        <Label>Preceding step time</Label>
        {isFirstStep ? (
          <p className="text-muted-foreground text-sm">
            Not applicable for the first process. It is automatically set to 0.
          </p>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2">
            <TextField
              id="precedingTimeValue"
              label="Value"
              type="number"
              min={0}
              placeholder="0"
              value={values.precedingTimeValue}
              error={errors.precedingTimeValue}
              required
              onValueChange={getFieldHandler("precedingTimeValue")}
            />
            <SelectField
              id="precedingTimeUnit"
              label="Unit"
              placeholder="Select a unit"
              value={values.precedingTimeUnit}
              options={timeUnitOptions}
              error={errors.precedingTimeUnit}
              required
              onValueChange={getFieldHandler("precedingTimeUnit")}
            />
          </div>
        )}
      </div>
    </div>
  );
}
