import { Link } from "react-router-dom";
import { ArrowLeft, MoreVertical, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/shared/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import { Card, CardDescription, CardHeader, CardTitle } from "@/shared/ui/card";
import { Badge } from "@/shared/ui/badge";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Workflow } from "@/features/workflows/types/workflow";

interface WorkflowDetailHeaderProps {
  workflow: Workflow;
  onDeleteClick: () => void;
  isDeleting: boolean;
}

export default function WorkflowDetailHeader({
  workflow,
  onDeleteClick,
  isDeleting,
}: WorkflowDetailHeaderProps) {
  const isActive = workflow.status === "Active";
  const isMandatory = workflow.is_mandatory === "Yes";

  return (
    <div className="flex flex-col gap-4">
      <Button variant="ghost" size="sm" asChild className="w-fit">
        <Link to={ROUTE_PATHS.workflows}>
          <ArrowLeft />
          Back to workflows
        </Link>
      </Button>

      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="flex flex-col gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant={isActive ? "default" : "secondary"}>{workflow.status}</Badge>
                {isMandatory ? <Badge variant="outline">Mandatory</Badge> : null}
              </div>
              <CardTitle className="text-2xl">{workflow.name}</CardTitle>
              <CardDescription>{workflow.description}</CardDescription>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="shrink-0"
                  aria-label="Workflow actions"
                  disabled={isDeleting}
                >
                  <MoreVertical />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuItem asChild>
                  <Link
                    to={ROUTE_PATHS.editWorkflow.replace(":workflowId", workflow.id)}
                    state={{ workflow }}
                  >
                    <Pencil />
                    Edit
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem variant="destructive" onClick={onDeleteClick}>
                  <Trash2 />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardHeader>
      </Card>
    </div>
  );
}
