import { Link, useLocation, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PageLoader from "@/shared/components/PageLoader";
import NotFoundPage from "@/features/errors/NotFoundPage";
import CreateWorkflowForm from "@/features/workflows/components/CreateWorkflowForm";
import useResolvedEntity from "@/shared/hooks/useResolvedEntity";
import { fetchWorkflowByIdRequest } from "@/features/workflows/services/workflowApi";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Workflow } from "@/features/workflows/types/workflow";

export default function EditWorkflowPage() {
  const location = useLocation();
  const { workflowId } = useParams();
  const stateWorkflow = (location.state as { workflow?: Workflow } | null)?.workflow ?? null;

  const {
    entity: workflow,
    isLoading,
    isNotFound,
  } = useResolvedEntity<Workflow>({
    stateEntity: stateWorkflow,
    id: workflowId,
    fetchById: fetchWorkflowByIdRequest,
  });

  if (isLoading) {
    return (
      <DashboardLayout title="Edit workflow" subtitle="Update this workflow's details.">
        <PageLoader />
      </DashboardLayout>
    );
  }

  if (isNotFound || workflow === null) {
    return <NotFoundPage />;
  }

  return (
    <DashboardLayout title="Edit workflow" subtitle="Update this workflow's details.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link
            to={ROUTE_PATHS.workflowDetail.replace(":workflowId", workflow.id)}
            state={{ workflow }}
          >
            <ArrowLeft />
            Back to details
          </Link>
        </Button>
        <CreateWorkflowForm existingWorkflow={workflow} />
      </div>
    </DashboardLayout>
  );
}
