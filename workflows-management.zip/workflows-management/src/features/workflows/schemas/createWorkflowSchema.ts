import { z } from "zod";

export const createWorkflowSchema = z.object({
  name: z.string().min(2, "Workflow name must be at least 2 characters."),
  description: z.string().optional(),
  isMandatory: z.string().min(1, "Please choose whether this workflow is mandatory."),
  status: z.string().min(1, "Please select a status."),
  numberOfSteps: z
    .string()
    .min(1, "Please enter the number of steps.")
    .refine((value) => /^\d+$/.test(value), "Number of steps must be a whole number (0 or more)."),
});

export type CreateWorkflowFormValues = z.infer<typeof createWorkflowSchema>;
