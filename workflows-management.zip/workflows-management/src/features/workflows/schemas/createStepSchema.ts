import { z } from "zod";

const wholeNumber = (label: string) =>
  z
    .string()
    .min(1, `Please enter ${label}.`)
    .refine((value) => /^\d+$/.test(value), `${label} must be a whole number.`);

export const createStepSchema = z.object({
  name: z.string().min(2, "Step name must be at least 2 characters."),
  description: z.string().optional(),
  status: z.string().min(1, "Please select a status."),
  percentage: wholeNumber("a percentage"),
  warningThreshold: wholeNumber("a warning threshold"),
  roleIds: z.array(z.string()),
  processTimeUnit: z.string().min(1, "Please select a time unit."),
  processTimeValue: wholeNumber("the process step time"),
  precedingTimeUnit: z.string().min(1, "Please select a time unit."),
  precedingTimeValue: wholeNumber("the preceding step time"),
});

export type CreateStepFormValues = z.infer<typeof createStepSchema>;
