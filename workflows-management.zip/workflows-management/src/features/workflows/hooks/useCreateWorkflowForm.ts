import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";
import {
  createWorkflowSchema,
  type CreateWorkflowFormValues,
} from "@/features/workflows/schemas/createWorkflowSchema";
import buildCreateWorkflowPayload from "@/features/workflows/utils/buildCreateWorkflowPayload";
import {
  createWorkflowRequest,
  updateWorkflowRequest,
} from "@/features/workflows/services/workflowApi";
import type { Workflow } from "@/features/workflows/types/workflow";

export interface UseCreateWorkflowFormOptions {
  existingWorkflow?: Workflow;
}

function buildInitialValues(existingWorkflow?: Workflow): CreateWorkflowFormValues {
  if (existingWorkflow) {
    return {
      name: existingWorkflow.name,
      description: existingWorkflow.description,
      isMandatory: existingWorkflow.is_mandatory,
      status: existingWorkflow.status,
      numberOfSteps: String(existingWorkflow.number_of_steps),
    };
  }

  return {
    name: "",
    description: "",
    isMandatory: "",
    status: "Draft",
    numberOfSteps: "0",
  };
}

export default function useCreateWorkflowForm({ existingWorkflow }: UseCreateWorkflowFormOptions) {
  const navigate = useNavigate();

  return useZodForm<CreateWorkflowFormValues>({
    schema: createWorkflowSchema,
    initialValues: buildInitialValues(existingWorkflow),
    onValidSubmit: async (values) => {
      try {
        const payload = buildCreateWorkflowPayload(values);

        if (existingWorkflow) {
          const updatedPayload = { ...payload, id: existingWorkflow.id };
          await updateWorkflowRequest(updatedPayload);
          navigate(ROUTE_PATHS.workflowDetail.replace(":workflowId", existingWorkflow.id), {
            state: { workflow: updatedPayload },
          });
        } else {
          await createWorkflowRequest(payload);
          navigate(ROUTE_PATHS.workflows, { state: { workflowCreated: true } });
        }
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to save the workflow. Please try again."));
      }
    },
  });
}
