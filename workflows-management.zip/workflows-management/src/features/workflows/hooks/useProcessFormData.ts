import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { fetchAllRolesRequest } from "@/features/roles/services/roleApi";
import { fetchAllTimeUnitsRequest } from "@/features/time/services/timeApi";
import type { Role } from "@/features/roles/types/role";

const EXCLUDED_PROCESS_ROLE_NAME = "super admin";

function filterAssignableRoles(roles: Role[]): Role[] {
  return roles.filter((role) => role.name.trim().toLowerCase() !== EXCLUDED_PROCESS_ROLE_NAME);
}

export default function useProcessFormData() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [timeUnits, setTimeUnits] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function fetchFormData() {
      try {
        const [rolesData, timeUnitsData] = await Promise.all([
          fetchAllRolesRequest(),
          fetchAllTimeUnitsRequest(),
        ]);
        if (!cancelled) {
          setRoles(filterAssignableRoles(rolesData));
          setTimeUnits(timeUnitsData);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load roles and time units."));
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    fetchFormData();

    return () => {
      cancelled = true;
    };
  }, []);

  return { roles, timeUnits, isLoading };
}
