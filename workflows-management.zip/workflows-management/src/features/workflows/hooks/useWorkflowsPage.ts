import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { fetchWorkspaceWorkflowsRequest } from "@/features/workflows/services/workflowApi";
import type { Workflow } from "@/features/workflows/types/workflow";

export default function useWorkflowsPage() {
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  useNavigationSuccessToast("workflowCreated", "Workflow created successfully.");

  useEffect(() => {
    let cancelled = false;

    async function fetchWorkflows() {
      try {
        const data = await fetchWorkspaceWorkflowsRequest();
        if (!cancelled) {
          setWorkflows(data);
        }
      } catch (error) {
        if (!cancelled) {
          const message = getApiErrorMessage(error, "Unable to load workflows.");
          setFetchError(message);
          toast.error(message);
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    fetchWorkflows();

    return () => {
      cancelled = true;
    };
  }, []);

  return {
    workflows,
    isLoading,
    fetchError,
  };
}
