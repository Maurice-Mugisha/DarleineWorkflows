import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";
import {
  createStepSchema,
  type CreateStepFormValues,
} from "@/features/workflows/schemas/createStepSchema";
import { createStepRequest, updateStepRequest } from "@/features/workflows/services/stepApi";
import generateStepCode from "@/features/workflows/utils/generateStepCode";
import buildStepPayload from "@/features/workflows/utils/buildStepPayload";
import type { Step } from "@/features/workflows/types/step";
import type { Workflow } from "@/features/workflows/types/workflow";
import {
  PROCESS_STEP_TIME_CATEGORY,
  PRECEDING_STEP_TIME_CATEGORY,
} from "@/features/time/utils/timeCategories";

const DEFAULT_TIME_UNIT = "hour";

interface UseCreateProcessFormOptions {
  workflow: Workflow;
  nextStepNumber: number;
  existingStep?: Step;
}

function findTimeValue(step: Step | undefined, category: string): string {
  const match = step?.time_list?.find((time) => time.time_unit_category === category);
  return match ? String(match.time_unit_value) : "0";
}

function findTimeUnit(step: Step | undefined, category: string): string {
  const match = step?.time_list?.find((time) => time.time_unit_category === category);
  return match?.time_unit ?? DEFAULT_TIME_UNIT;
}

function buildInitialValues(existingStep?: Step): CreateStepFormValues {
  return {
    name: existingStep?.name ?? "",
    description: existingStep?.description ?? "",
    status: existingStep?.status ?? "Active",
    percentage: existingStep ? String(existingStep.percentage) : "0",
    warningThreshold: existingStep ? String(existingStep.warning_threshold) : "75",
    roleIds: existingStep?.role_id_list ?? [],
    processTimeUnit: findTimeUnit(existingStep, PROCESS_STEP_TIME_CATEGORY),
    processTimeValue: findTimeValue(existingStep, PROCESS_STEP_TIME_CATEGORY),
    precedingTimeUnit: findTimeUnit(existingStep, PRECEDING_STEP_TIME_CATEGORY),
    precedingTimeValue: findTimeValue(existingStep, PRECEDING_STEP_TIME_CATEGORY),
  };
}

export default function useCreateProcessForm({
  workflow,
  nextStepNumber,
  existingStep,
}: UseCreateProcessFormOptions) {
  const navigate = useNavigate();
  const detailPath = ROUTE_PATHS.workflowDetail.replace(":workflowId", workflow.id);

  return useZodForm<CreateStepFormValues>({
    schema: createStepSchema,
    initialValues: buildInitialValues(existingStep),
    onValidSubmit: async (values) => {
      try {
        if (existingStep) {
          await updateStepRequest(
            buildStepPayload({
              values,
              stepId: existingStep.id,
              workflowId: workflow.id,
              stepNumber: existingStep.step_number,
              code: existingStep.code,
              existingTimes: existingStep.time_list,
            }),
          );
          navigate(detailPath, { state: { workflow, processUpdated: true } });
        } else {
          await createStepRequest(
            buildStepPayload({
              values,
              stepId: crypto.randomUUID(),
              workflowId: workflow.id,
              stepNumber: nextStepNumber,
              code: generateStepCode(),
            }),
          );
          navigate(detailPath, { state: { workflow, processCreated: true } });
        }
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to save the step. Please try again."));
      }
    },
  });
}
