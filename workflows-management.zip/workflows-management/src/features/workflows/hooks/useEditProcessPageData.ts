import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import useResolvedEntity from "@/shared/hooks/useResolvedEntity";
import { fetchWorkflowByIdRequest } from "@/features/workflows/services/workflowApi";
import { fetchWorkflowStepsRequest } from "@/features/workflows/services/stepApi";
import type { Workflow } from "@/features/workflows/types/workflow";
import type { Step } from "@/features/workflows/types/step";

export default function useEditProcessPageData() {
  const location = useLocation();
  const { workflowId, stepId } = useParams();
  const state = location.state as { workflow?: Workflow; step?: Step } | null;
  const stateWorkflow = state?.workflow ?? null;
  const stateStep = state?.step ?? null;
  const needsStepFetch = stateStep === null;

  const {
    entity: workflow,
    isLoading: isLoadingWorkflow,
    isNotFound: workflowNotFound,
  } = useResolvedEntity<Workflow>({
    stateEntity: stateWorkflow,
    id: workflowId,
    fetchById: fetchWorkflowByIdRequest,
  });

  const [step, setStep] = useState<Step | null>(stateStep);
  const [isLoadingStep, setIsLoadingStep] = useState(needsStepFetch);
  const [stepNotFound, setStepNotFound] = useState(false);

  const workflowIdentifier = workflow?.id;

  useEffect(() => {
    if (!needsStepFetch || workflowIdentifier === undefined || stepId === undefined) {
      return;
    }

    let cancelled = false;
    setIsLoadingStep(true);
    fetchWorkflowStepsRequest(workflowIdentifier)
      .then((steps) => {
        if (cancelled) {
          return;
        }
        const foundStep = steps.find((candidate) => candidate.id === stepId) ?? null;
        if (foundStep) {
          setStep(foundStep);
        } else {
          setStepNotFound(true);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setStepNotFound(true);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoadingStep(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [needsStepFetch, workflowIdentifier, stepId]);

  const isNotFound = workflowNotFound || stepNotFound;
  const isLoading = !isNotFound && (isLoadingWorkflow || (needsStepFetch && isLoadingStep));

  return { workflow, step, isLoading, isNotFound };
}
