import { useEffect, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import useResolvedEntity from "@/shared/hooks/useResolvedEntity";
import {
  deleteWorkflowRequest,
  fetchWorkflowByIdRequest,
} from "@/features/workflows/services/workflowApi";
import {
  fetchWorkflowStepsRequest,
  deleteStepRequest,
} from "@/features/workflows/services/stepApi";
import { fetchAllRolesRequest } from "@/features/roles/services/roleApi";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Workflow } from "@/features/workflows/types/workflow";
import type { Step } from "@/features/workflows/types/step";

export default function useWorkflowDetailPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { workflowId } = useParams();
  const stateWorkflow = (location.state as { workflow?: Workflow } | null)?.workflow ?? null;

  const {
    entity: workflow,
    isLoading: isLoadingWorkflow,
    isNotFound,
  } = useResolvedEntity<Workflow>({
    stateEntity: stateWorkflow,
    id: workflowId,
    fetchById: fetchWorkflowByIdRequest,
  });

  const [steps, setSteps] = useState<Step[]>([]);
  const [roleNameById, setRoleNameById] = useState<Record<string, string>>({});
  const [isLoadingSteps, setIsLoadingSteps] = useState(true);
  const [isDeletingWorkflow, setIsDeletingWorkflow] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  useNavigationSuccessToast("processCreated", "Step created successfully.");
  useNavigationSuccessToast("processUpdated", "Step updated successfully.");

  const workflowIdentifier = workflow?.id;

  useEffect(() => {
    if (workflowIdentifier === undefined) {
      return;
    }

    let cancelled = false;

    async function fetchSteps() {
      try {
        const data = await fetchWorkflowStepsRequest(workflowIdentifier!);
        if (!cancelled) {
          setSteps(data);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load steps."));
        }
      } finally {
        if (!cancelled) {
          setIsLoadingSteps(false);
        }
      }
    }

    async function fetchRoles() {
      try {
        const data = await fetchAllRolesRequest();
        if (!cancelled) {
          const lookup: Record<string, string> = {};
          for (const role of data) {
            lookup[role.id] = role.name;
          }
          setRoleNameById(lookup);
        }
      } catch {
        // Role names are non-critical; process cards fall back to "Unknown role".
      }
    }

    fetchSteps();
    fetchRoles();

    return () => {
      cancelled = true;
    };
  }, [workflowIdentifier]);

  const handleDeleteWorkflow = async () => {
    if (workflow === null) {
      return;
    }
    setIsDeletingWorkflow(true);
    try {
      await deleteWorkflowRequest(workflow.id);
      toast.success("Workflow deleted.");
      navigate(ROUTE_PATHS.workflows, { replace: true });
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to delete the workflow."));
    } finally {
      setIsDeletingWorkflow(false);
      setShowDeleteDialog(false);
    }
  };

  const handleDeleteStep = async (stepId: string) => {
    try {
      await deleteStepRequest(stepId);
      setSteps((previousSteps) => previousSteps.filter((step) => step.id !== stepId));
      toast.success("Step deleted.");
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to delete the step."));
    }
  };

  return {
    workflow,
    isLoadingWorkflow,
    isNotFound,
    steps,
    roleNameById,
    isLoadingSteps,
    isDeletingWorkflow,
    showDeleteDialog,
    setShowDeleteDialog,
    handleDeleteWorkflow,
    handleDeleteStep,
  };
}
