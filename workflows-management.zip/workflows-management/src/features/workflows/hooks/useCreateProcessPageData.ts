import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import useResolvedEntity from "@/shared/hooks/useResolvedEntity";
import { fetchWorkflowByIdRequest } from "@/features/workflows/services/workflowApi";
import { fetchWorkflowStepsRequest } from "@/features/workflows/services/stepApi";
import type { Workflow } from "@/features/workflows/types/workflow";

export default function useCreateProcessPageData() {
  const location = useLocation();
  const { workflowId } = useParams();
  const state = location.state as { workflow?: Workflow; nextStepNumber?: number } | null;
  const stateWorkflow = state?.workflow ?? null;
  const stateNextStepNumber = state?.nextStepNumber;
  const needsStepFetch = stateNextStepNumber === undefined;

  const {
    entity: workflow,
    isLoading: isLoadingWorkflow,
    isNotFound,
  } = useResolvedEntity<Workflow>({
    stateEntity: stateWorkflow,
    id: workflowId,
    fetchById: fetchWorkflowByIdRequest,
  });

  const [nextStepNumber, setNextStepNumber] = useState(stateNextStepNumber ?? 1);
  const [isLoadingSteps, setIsLoadingSteps] = useState(needsStepFetch);

  const workflowIdentifier = workflow?.id;

  useEffect(() => {
    if (!needsStepFetch || workflowIdentifier === undefined) {
      return;
    }

    let cancelled = false;
    setIsLoadingSteps(true);
    fetchWorkflowStepsRequest(workflowIdentifier)
      .then((steps) => {
        if (!cancelled) {
          setNextStepNumber(steps.length + 1);
        }
      })
      .catch(() => {
        // Fall back to the default of 1 if steps can't be loaded.
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoadingSteps(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [needsStepFetch, workflowIdentifier]);

  const isLoading = !isNotFound && (isLoadingWorkflow || (needsStepFetch && isLoadingSteps));

  return { workflow, nextStepNumber, isLoading, isNotFound };
}
