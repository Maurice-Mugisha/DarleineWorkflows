import type { CreateStepFormValues } from "@/features/workflows/schemas/createStepSchema";
import type { Step } from "@/features/workflows/types/step";
import type { Time } from "@/features/time/types/time";
import {
  PROCESS_STEP_TIME_CATEGORY,
  PRECEDING_STEP_TIME_CATEGORY,
} from "@/features/time/utils/timeCategories";

interface BuildStepPayloadParams {
  values: CreateStepFormValues;
  stepId: string;
  workflowId: string;
  stepNumber: number;
  code: string;
  existingTimes?: Time[] | null;
}

function findTimeId(existingTimes: Time[] | null | undefined, category: string): string {
  const match = existingTimes?.find((time) => time.time_unit_category === category);
  return match?.id ?? crypto.randomUUID();
}

export default function buildStepPayload({
  values,
  stepId,
  workflowId,
  stepNumber,
  code,
  existingTimes,
}: BuildStepPayloadParams): Step {
  const isFirstStep = stepNumber === 1;

  const timeList: Time[] = [
    {
      id: findTimeId(existingTimes, PROCESS_STEP_TIME_CATEGORY),
      step_id: stepId,
      time_unit: values.processTimeUnit,
      time_unit_category: PROCESS_STEP_TIME_CATEGORY,
      time_unit_value: Number(values.processTimeValue),
    },
    {
      id: findTimeId(existingTimes, PRECEDING_STEP_TIME_CATEGORY),
      step_id: stepId,
      time_unit: values.precedingTimeUnit,
      time_unit_category: PRECEDING_STEP_TIME_CATEGORY,
      time_unit_value: isFirstStep ? 0 : Number(values.precedingTimeValue),
    },
  ];

  return {
    id: stepId,
    workflow_id: workflowId,
    name: values.name.trim(),
    description: values.description?.trim() ?? "",
    step_number: stepNumber,
    status: values.status,
    percentage: Number(values.percentage),
    warning_threshold: Number(values.warningThreshold),
    code,
    role_id_list: values.roleIds,
    time_list: timeList,
  };
}
