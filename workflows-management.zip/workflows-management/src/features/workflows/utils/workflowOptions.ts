export interface WorkflowSelectOption {
  value: string;
  label: string;
}

export const MANDATORY_OPTIONS: WorkflowSelectOption[] = [
  { value: "Yes", label: "Yes" },
  { value: "No", label: "No" },
];

export const STATUS_OPTIONS: WorkflowSelectOption[] = [
  { value: "Draft", label: "Draft" },
  { value: "Active", label: "Active" },
  { value: "Inactive", label: "Inactive" },
];
