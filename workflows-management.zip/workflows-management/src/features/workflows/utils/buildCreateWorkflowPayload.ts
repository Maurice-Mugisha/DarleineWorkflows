import type { CreateWorkflowFormValues } from "@/features/workflows/schemas/createWorkflowSchema";
import type { Workflow } from "@/features/workflows/types/workflow";
import getCurrentWorkspaceId from "@/shared/lib/currentWorkspace";

export default function buildCreateWorkflowPayload(values: CreateWorkflowFormValues): Workflow {
  return {
    id: crypto.randomUUID(),
    workspace_id: getCurrentWorkspaceId(),
    name: values.name.trim(),
    description: values.description?.trim() ?? "",
    is_mandatory: values.isMandatory,
    number_of_steps: Number(values.numberOfSteps),
    status: values.status,
  };
}
