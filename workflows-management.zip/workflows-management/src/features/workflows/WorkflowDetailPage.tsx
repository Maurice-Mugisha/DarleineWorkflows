import DashboardLayout from "@/shared/components/DashboardLayout";
import PageLoader from "@/shared/components/PageLoader";
import ConfirmDialog from "@/shared/components/ConfirmDialog";
import NotFoundPage from "@/features/errors/NotFoundPage";
import WorkflowDetailHeader from "@/features/workflows/components/WorkflowDetailHeader";
import ProcessList from "@/features/workflows/components/ProcessList";
import useWorkflowDetailPage from "@/features/workflows/hooks/useWorkflowDetailPage";

export default function WorkflowDetailPage() {
  const {
    workflow,
    isLoadingWorkflow,
    isNotFound,
    steps,
    roleNameById,
    isLoadingSteps,
    isDeletingWorkflow,
    showDeleteDialog,
    setShowDeleteDialog,
    handleDeleteWorkflow,
    handleDeleteStep,
  } = useWorkflowDetailPage();

  if (isLoadingWorkflow) {
    return (
      <DashboardLayout title="Workflow" subtitle="Workflow details and its steps.">
        <PageLoader />
      </DashboardLayout>
    );
  }

  if (isNotFound || workflow === null) {
    return <NotFoundPage />;
  }

  return (
    <DashboardLayout title={workflow.name} subtitle="Workflow details and its steps.">
      <div className="flex flex-col gap-8">
        <WorkflowDetailHeader
          workflow={workflow}
          onDeleteClick={() => setShowDeleteDialog(true)}
          isDeleting={isDeletingWorkflow}
        />

        <ProcessList
          steps={steps}
          workflow={workflow}
          maxProcesses={workflow.number_of_steps}
          roleNameById={roleNameById}
          isLoading={isLoadingSteps}
          onDelete={handleDeleteStep}
        />
      </div>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onConfirm={handleDeleteWorkflow}
        onCancel={() => setShowDeleteDialog(false)}
        title="Delete workflow"
        message={`Are you sure you want to delete "${workflow.name}"? All steps and associated data will be permanently removed.`}
        isLoading={isDeletingWorkflow}
      />
    </DashboardLayout>
  );
}
