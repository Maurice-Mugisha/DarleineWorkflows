export interface Workflow {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  is_mandatory: string;
  number_of_steps: number;
  status: string;
}
