import type { Time } from "@/features/time/types/time";

export interface Step {
  id: string;
  workflow_id: string;
  name: string;
  description: string;
  step_number: number;
  status: string;
  percentage: number;
  warning_threshold: number;
  code: string;
  role_id_list?: string[] | null;
  time_list?: Time[] | null;
  workflow_case_step_status?: string | null;
}

export type CreateStepPayload = Step;
