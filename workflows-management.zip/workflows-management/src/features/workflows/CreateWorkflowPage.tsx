import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import CreateWorkflowForm from "@/features/workflows/components/CreateWorkflowForm";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function CreateWorkflowPage() {
  return (
    <DashboardLayout title="Create workflow" subtitle="Define a new workflow for your team.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.workflows}>
            <ArrowLeft />
            Back to workflows
          </Link>
        </Button>
        <CreateWorkflowForm />
      </div>
    </DashboardLayout>
  );
}
