import { z } from "zod";

export const reportSchema = z.object({
  reportText: z.string().min(10, "Report text must be at least 10 characters."),
  documentUrl: z.string().max(2000, "URL must be 2000 characters or fewer.").optional(),
});

export type ReportFormValues = z.infer<typeof reportSchema>;
