export interface Report {
  id: string;
  step_id: string;
  user_id: string;
  workflow_case_id: string;
  report_text: string;
  optional_document_url?: string | null;
}

export type CreateReportPayload = Report;
