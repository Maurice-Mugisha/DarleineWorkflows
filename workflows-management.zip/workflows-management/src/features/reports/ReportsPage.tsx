import DashboardLayout from "@/shared/components/DashboardLayout";
import ReportsList from "@/features/reports/components/ReportsList";
import useReportsPage from "@/features/reports/hooks/useReportsPage";

export default function ReportsPage() {
  const { reports, userNameById, isLoading, handleDeleteReport } = useReportsPage();

  return (
    <DashboardLayout title="Reports" subtitle="Documentation filed when steps complete.">
      <ReportsList
        reports={reports}
        userNameById={userNameById}
        isLoading={isLoading}
        onDelete={handleDeleteReport}
      />
    </DashboardLayout>
  );
}
