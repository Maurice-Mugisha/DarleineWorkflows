import apiClient from "@/shared/lib/apiClient";
import type { Report } from "@/features/reports/types/report";

export async function fetchAllReportsRequest(): Promise<Report[]> {
  const response = await apiClient.get<Report[]>("/report/retrieve_all_reports");
  return response.data;
}

export async function createReportRequest(payload: Report): Promise<void> {
  await apiClient.post("/report/register_a_report", payload);
}

export async function deleteReportRequest(reportId: string): Promise<void> {
  await apiClient.delete("/report/delete_a_report", {
    params: { report_id: reportId },
  });
}
