import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Trash2 } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { Badge } from "@/shared/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/shared/ui/card";
import DashboardLayout from "@/shared/components/DashboardLayout";
import ConfirmDialog from "@/shared/components/ConfirmDialog";
import useReportDetailPage from "@/features/reports/hooks/useReportDetailPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function ReportDetailPage() {
  const { report, handleDeleteReport } = useReportDetailPage();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  if (report === null) {
    return null;
  }

  return (
    <DashboardLayout title="Report" subtitle="Report filed for a completed step.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.reports}>
            <ArrowLeft />
            Back to reports
          </Link>
        </Button>

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <CardTitle className="text-xl">Report details</CardTitle>
              <Button
                variant="ghost"
                size="icon"
                className="size-8 shrink-0"
                aria-label="Delete report"
                onClick={() => setShowDeleteDialog(true)}
              >
                <Trash2 className="text-destructive size-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-4">
              <div>
                <p className="text-muted-foreground text-xs uppercase">Report text</p>
                <p className="mt-1 text-sm whitespace-pre-wrap">{report.report_text}</p>
              </div>
              {report.optional_document_url ? (
                <div>
                  <p className="text-muted-foreground text-xs uppercase">Document</p>
                  <a
                    href={report.optional_document_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary mt-1 block text-sm font-medium hover:underline"
                  >
                    {report.optional_document_url}
                  </a>
                </div>
              ) : null}
              <div>
                <p className="text-muted-foreground text-xs uppercase">Step</p>
                <Badge variant="outline" className="mt-1">
                  Unknown step
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onConfirm={handleDeleteReport}
        onCancel={() => setShowDeleteDialog(false)}
        title="Delete report"
        message="Are you sure you want to delete this report? This action cannot be undone."
      />
    </DashboardLayout>
  );
}
