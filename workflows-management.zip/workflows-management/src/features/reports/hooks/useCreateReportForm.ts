import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import useAuth from "@/shared/hooks/useAuth";
import { ROUTE_PATHS } from "@/routes/routePaths";
import { reportSchema, type ReportFormValues } from "@/features/reports/schemas/reportSchema";
import buildReportPayload from "@/features/reports/utils/buildReportPayload";
import { createReportRequest } from "@/features/reports/services/reportApi";

const INITIAL_VALUES: ReportFormValues = {
  reportText: "",
  documentUrl: "",
};

export default function useCreateReportForm() {
  const navigate = useNavigate();
  const { caseId } = useParams();
  const [searchParams] = useSearchParams();
  const stepId = searchParams.get("stepId") ?? "";
  const { user } = useAuth();

  return useZodForm<ReportFormValues>({
    schema: reportSchema,
    initialValues: INITIAL_VALUES,
    onValidSubmit: async (values) => {
      try {
        const resolvedStepId = stepId.trim();
        if (resolvedStepId === "") {
          toast.error("No step selected. Please file a report from a completed step.");
          return;
        }

        const resolvedUserId = user?.id ?? "";
        if (resolvedUserId === "") {
          toast.error("Unable to identify your user account. Please try again.");
          return;
        }

        const resolvedCaseId = caseId ?? "";

        await createReportRequest(
          buildReportPayload({
            values,
            stepId: resolvedStepId,
            userId: resolvedUserId,
            workflowCaseId: resolvedCaseId,
          }),
        );

        navigate(ROUTE_PATHS.caseDetail.replace(":caseId", resolvedCaseId), {
          state: { reportCreated: true },
        });
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to create the report. Please try again."));
      }
    },
  });
}
