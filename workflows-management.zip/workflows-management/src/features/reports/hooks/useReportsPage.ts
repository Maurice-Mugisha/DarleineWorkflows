import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { fetchAllReportsRequest, deleteReportRequest } from "@/features/reports/services/reportApi";
import { fetchWorkspaceUsersRequest } from "@/features/users/services/userApi";
import type { Report } from "@/features/reports/types/report";

export default function useReportsPage() {
  const [reports, setReports] = useState<Report[]>([]);
  const [userNameById, setUserNameById] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(true);

  useNavigationSuccessToast("reportCreated", "Report created successfully.");

  useEffect(() => {
    let cancelled = false;

    async function fetchData() {
      const [reportsResult, usersResult] = await Promise.allSettled([
        fetchAllReportsRequest(),
        fetchWorkspaceUsersRequest(),
      ]);

      if (cancelled) return;

      if (reportsResult.status === "fulfilled") {
        setReports(reportsResult.value);
      } else {
        toast.error(getApiErrorMessage(reportsResult.reason, "Unable to load reports."));
      }

      if (usersResult.status === "fulfilled") {
        const lookup: Record<string, string> = {};
        for (const user of usersResult.value) {
          lookup[user.id] = `${user.first_name} ${user.last_name}`;
        }
        setUserNameById(lookup);
      }

      setIsLoading(false);
    }

    fetchData();

    return () => {
      cancelled = true;
    };
  }, []);

  const handleDeleteReport = async (reportId: string) => {
    try {
      await deleteReportRequest(reportId);
      setReports((prev) => prev.filter((r) => r.id !== reportId));
      toast.success("Report deleted.");
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to delete the report."));
    }
  };

  return { reports, userNameById, isLoading, handleDeleteReport };
}
