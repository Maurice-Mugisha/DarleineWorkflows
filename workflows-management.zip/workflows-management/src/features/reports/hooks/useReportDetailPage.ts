import { useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { deleteReportRequest } from "@/features/reports/services/reportApi";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Report } from "@/features/reports/types/report";

export default function useReportDetailPage() {
  const location = useLocation();
  const navigate = useNavigate();

  const report = (location.state as { report?: Report } | null)?.report ?? null;

  if (report === null) {
    navigate(ROUTE_PATHS.reports, { replace: true });
  }

  const handleDeleteReport = async () => {
    if (report === null) return;

    try {
      await deleteReportRequest(report.id);
      toast.success("Report deleted.");
      navigate(ROUTE_PATHS.reports, { replace: true });
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to delete the report."));
    }
  };

  return { report, handleDeleteReport };
}
