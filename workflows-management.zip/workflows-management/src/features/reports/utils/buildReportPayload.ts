import type { ReportFormValues } from "@/features/reports/schemas/reportSchema";
import type { Report } from "@/features/reports/types/report";

interface BuildReportPayloadParams {
  values: ReportFormValues;
  stepId: string;
  userId: string;
  workflowCaseId: string;
  reportId?: string;
}

export default function buildReportPayload({
  values,
  stepId,
  userId,
  workflowCaseId,
  reportId,
}: BuildReportPayloadParams): Report {
  return {
    id: reportId ?? crypto.randomUUID(),
    step_id: stepId,
    user_id: userId,
    workflow_case_id: workflowCaseId,
    report_text: values.reportText.trim(),
    optional_document_url: "https://www.rycowb.org/wp-content/uploads/2023/07/Narrative-Report-Template.pdf",
  };
}
