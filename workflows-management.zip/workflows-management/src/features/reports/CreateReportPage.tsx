import { Link, Navigate, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import ReportForm from "@/features/reports/components/ReportForm";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function CreateReportPage() {
  const { caseId } = useParams();

  if (caseId === undefined) {
    return <Navigate to={ROUTE_PATHS.reports} replace />;
  }

  return (
    <DashboardLayout title="File a report" subtitle="Document the outcome of a completed step.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.caseDetail.replace(":caseId", caseId)}>
            <ArrowLeft />
            Back to case
          </Link>
        </Button>
        <ReportForm />
      </div>
    </DashboardLayout>
  );
}
