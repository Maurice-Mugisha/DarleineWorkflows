import { useState } from "react";
import { Link } from "react-router-dom";
import { Eye, Trash2 } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { Badge } from "@/shared/ui/badge";
import ConfirmDialog from "@/shared/components/ConfirmDialog";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Report } from "@/features/reports/types/report";

interface ReportRowProps {
  report: Report;
  userName: string;
  onDelete: (reportId: string) => Promise<void>;
}

export default function ReportRow({ report, userName, onDelete }: ReportRowProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const textPreview =
    report.report_text.length > 150 ? report.report_text.slice(0, 150) + "..." : report.report_text;

  const handleDelete = async () => {
    setIsDeleting(true);
    await onDelete(report.id);
    setIsDeleting(false);
    setShowDeleteDialog(false);
  };

  return (
    <>
      <div className="border-border flex items-start justify-between gap-4 rounded-md border p-4">
        <div className="min-w-0 flex-1">
          <p className="text-sm">{textPreview}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            {report.optional_document_url ? (
              <a
                href={report.optional_document_url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary text-xs font-medium hover:underline"
                onClick={(e) => e.stopPropagation()}
              >
                Document
              </a>
            ) : null}
            <Badge variant="outline" className="text-xs">
              {userName || "Unknown user"}
            </Badge>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-1">
          <Button variant="ghost" size="icon" className="size-8" aria-label="View report" asChild>
            <Link
              to={ROUTE_PATHS.reportDetail.replace(":reportId", report.id)}
              state={{ report, userName }}
            >
              <Eye className="size-4" />
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="size-8"
            aria-label="Delete report"
            onClick={() => setShowDeleteDialog(true)}
          >
            <Trash2 className="text-destructive size-4" />
          </Button>
        </div>
      </div>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onConfirm={handleDelete}
        onCancel={() => setShowDeleteDialog(false)}
        title="Delete report"
        message="Are you sure you want to delete this report? This action cannot be undone."
        isLoading={isDeleting}
      />
    </>
  );
}
