import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/shared/ui/card";
import TextareaField from "@/shared/components/TextareaField";
import useCreateReportForm from "@/features/reports/hooks/useCreateReportForm";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function ReportForm() {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit } = useCreateReportForm();

  return (
    <form noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Report details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-5">
            <TextareaField
              id="reportText"
              label="Report text"
              placeholder="Describe what happened when this step completed."
              className="min-h-32"
              value={values.reportText}
              error={errors.reportText}
              required
              onValueChange={getFieldHandler("reportText")}
            />
          </div>
        </CardContent>
        <CardFooter className="gap-3">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : "Save report"}
          </Button>
          <Button type="button" variant="ghost" asChild>
            <Link to={ROUTE_PATHS.cases}>Cancel</Link>
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
