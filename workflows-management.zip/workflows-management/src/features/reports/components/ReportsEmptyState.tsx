import { Link } from "react-router-dom";
import { FileText, Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { ROUTE_PATHS } from "@/routes/routePaths";

const REPORT_BENEFITS = [
  {
    text: "Document what happens when a step completes.",
    accent: "border-l-primary bg-primary/5",
  },
  {
    text: "Attach document links for traceability and audit.",
    accent: "border-l-amber-500 bg-amber-50 dark:border-l-amber-400 dark:bg-amber-950/30",
  },
  {
    text: "Track who filed each report and when they did it.",
    accent: "border-l-emerald-500 bg-emerald-50 dark:border-l-emerald-400 dark:bg-emerald-950/30",
  },
];

export default function ReportsEmptyState() {
  return (
    <div className="border-border flex flex-col items-center rounded-md border border-dashed py-16 text-center">
      <span className="bg-primary/10 text-primary mb-6 flex size-20 items-center justify-center rounded-2xl">
        <FileText className="size-10" />
      </span>
      <h2 className="text-2xl font-semibold tracking-tight">No reports yet</h2>
      <p className="text-muted-foreground mt-2 max-w-md">
        Reports are filed when a step completes inside a workflow case. Open a case and complete
        a step to file your first report.
      </p>
      <ul className="mt-8 flex w-full max-w-lg flex-col gap-3">
        {REPORT_BENEFITS.map((benefit) => (
          <li
            key={benefit.text}
            className={`border-border rounded-lg border-l-4 px-4 py-3 text-left text-sm ${benefit.accent}`}
          >
            {benefit.text}
          </li>
        ))}
      </ul>
      <Button size="lg" className="mt-8" asChild>
        <Link to={ROUTE_PATHS.cases}>
          <Plus />
          Open a case
        </Link>
      </Button>
    </div>
  );
}
