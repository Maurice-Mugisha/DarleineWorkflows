import { Skeleton } from "@/shared/ui/skeleton";
import ReportRow from "@/features/reports/components/ReportRow";
import ReportsEmptyState from "@/features/reports/components/ReportsEmptyState";
import type { Report } from "@/features/reports/types/report";

interface ReportsListProps {
  reports: Report[];
  userNameById: Record<string, string>;
  isLoading: boolean;
  onDelete: (reportId: string) => Promise<void>;
}

function LoadingRows() {
  return (
    <div className="flex flex-col gap-3">
      {Array.from({ length: 3 }).map((_, index) => (
        <div key={index} className="border-border rounded-md border p-4">
          <Skeleton className="mb-2 h-4 w-full" />
          <Skeleton className="h-3 w-24" />
        </div>
      ))}
    </div>
  );
}

export default function ReportsList({
  reports,
  userNameById,
  isLoading,
  onDelete,
}: ReportsListProps) {
  if (isLoading) {
    return <LoadingRows />;
  }
  if (reports.length === 0) {
    return <ReportsEmptyState />;
  }
  return (
    <div className="flex flex-col gap-3">
      {reports.map((report) => (
        <ReportRow
          key={report.id}
          report={report}
          userName={userNameById[report.user_id] ?? ""}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
}
