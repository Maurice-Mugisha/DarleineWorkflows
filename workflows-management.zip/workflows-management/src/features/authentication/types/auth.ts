import type { LoginFormValues } from "@/features/authentication/schemas/loginSchema";

export type LoginPayload = LoginFormValues;
