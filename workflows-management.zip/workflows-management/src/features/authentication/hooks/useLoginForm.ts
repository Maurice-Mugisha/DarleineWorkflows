import { useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import useAuth from "@/shared/hooks/useAuth";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";
import { loginSchema, type LoginFormValues } from "@/features/authentication/schemas/loginSchema";
import loginRequest from "@/features/authentication/services/authApi";

const INITIAL_VALUES: LoginFormValues = {
  email: "",
  password: "",
};

export default function useLoginForm() {
  const navigate = useNavigate();
  const location = useLocation();
  const { authenticate } = useAuth();

  const form = useZodForm<LoginFormValues>({
    schema: loginSchema,
    initialValues: INITIAL_VALUES,
      onValidSubmit: async (values) => {
      try {
        const authUser = await loginRequest(values);
        authenticate(authUser);
        const redirectTo =
          (location.state as { from?: string } | null)?.from ?? ROUTE_PATHS.dashboard;
        navigate(redirectTo, { replace: true, state: { loginSuccess: true } });
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to sign in. Check your credentials."));
      }
    },
  });

  return form;
}
