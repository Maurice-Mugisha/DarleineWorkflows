import useAuth from "@/shared/hooks/useAuth";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";

export default function useLoginPage() {
  const { isAuthenticated } = useAuth();

  useNavigationSuccessToast(
    "registrationSuccess",
    "Workspace created successfully. Please sign in.",
  );

  return { isAuthenticated };
}
