import { Button } from "@/shared/ui/button";
import { Card, CardContent } from "@/shared/ui/card";
import TextField from "@/shared/components/TextField";
import PasswordField from "@/shared/components/PasswordField";
import useLoginForm from "@/features/authentication/hooks/useLoginForm";

export default function LoginForm() {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit } = useLoginForm();

  return (
    <Card>
      <CardContent className="pt-6">
        <form className="flex flex-col gap-5" noValidate onSubmit={handleSubmit}>
          <TextField
            id="email"
            label="Email"
            type="email"
            autoComplete="email"
            placeholder="you@company.com"
            value={values.email}
            error={errors.email}
            required
            onValueChange={getFieldHandler("email")}
          />

          <PasswordField
            id="password"
            label="Password"
            autoComplete="current-password"
            placeholder="Enter your password"
            value={values.password}
            error={errors.password}
            required
            onValueChange={getFieldHandler("password")}
          />

          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Signing in..." : "Sign in"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
