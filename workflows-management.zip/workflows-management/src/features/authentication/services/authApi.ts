import apiClient from "@/shared/lib/apiClient";
import type { AuthUser } from "@/shared/types/auth";
import type { LoginPayload } from "@/features/authentication/types/auth";

interface LoginApiResponse {
  id: string;
  workspace_id: string;
  first_name: string;
  last_name: string;
  email: string;
  job_title: string;
  roles: { id: string; name: string }[];
}

export default async function loginRequest(payload: LoginPayload): Promise<AuthUser> {
  const response = await apiClient.post<LoginApiResponse>("/authentication/login", payload);
  const { id, workspace_id, first_name, last_name, email, job_title, roles } = response.data;
  return { id, workspaceId: workspace_id, firstName: first_name, lastName: last_name, email, jobTitle: job_title, roles };
}
