import { Link, Navigate } from "react-router-dom";
import AuthLayout from "@/shared/components/AuthLayout";
import { ROUTE_PATHS } from "@/routes/routePaths";
import LoginForm from "@/features/authentication/components/LoginForm";
import useLoginPage from "@/features/authentication/hooks/useLoginPage";

export default function LoginPage() {
  const { isAuthenticated } = useLoginPage();

  if (isAuthenticated) {
    return <Navigate to={ROUTE_PATHS.dashboard} replace />;
  }

  return (
    <AuthLayout
      title="Sign in to Flowspace"
      description="Enter your credentials to access your workspace."
      footer={
        <>
          Don&apos;t have a workspace yet?{" "}
          <Link to={ROUTE_PATHS.register} className="text-primary font-medium hover:underline">
            Register one
          </Link>
        </>
      }
    >
      <LoginForm />
    </AuthLayout>
  );
}
