import { useEffect, useState } from "react";
import { Workflow, CircleCheck, Users, ShieldCheck } from "lucide-react";
import useAuth from "@/shared/hooks/useAuth";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";
import { fetchWorkspaceWorkflowsRequest } from "@/features/workflows/services/workflowApi";
import { fetchWorkspaceUsersRequest } from "@/features/users/services/userApi";
import { fetchAllRolesRequest } from "@/features/roles/services/roleApi";
import type { DashboardStat } from "@/features/dashboard/types/dashboard";
import type { Workflow as WorkflowType } from "@/features/workflows/types/workflow";
import type { User } from "@/features/users/types/user";
import type { Role } from "@/features/roles/types/role";
import getInitialsFromEmail from "@/shared/utils/getInitialsFromEmail";

const RECENT_WORKFLOWS_LIMIT = 5;

function resolveGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) {
    return "Good morning";
  }
  if (hour < 18) {
    return "Good afternoon";
  }
  return "Good evening";
}

function getInitialsFromName(firstName: string, lastName: string): string {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
}

export default function useDashboard() {
  const { user } = useAuth();

  const [workflows, setWorkflows] = useState<WorkflowType[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useNavigationSuccessToast("loginSuccess", "Welcome back! You are now signed in.");

  useEffect(() => {
    let cancelled = false;

    async function fetchDashboardData() {
      const [workflowsResult, usersResult, rolesResult] = await Promise.allSettled([
        fetchWorkspaceWorkflowsRequest(),
        fetchWorkspaceUsersRequest(),
        fetchAllRolesRequest(),
      ]);

      if (cancelled) {
        return;
      }

      if (workflowsResult.status === "fulfilled") {
        setWorkflows(workflowsResult.value);
      }
      if (usersResult.status === "fulfilled") {
        setUsers(usersResult.value);
      }
      if (rolesResult.status === "fulfilled") {
        setRoles(rolesResult.value);
      }
      setIsLoading(false);
    }

    fetchDashboardData();

    return () => {
      cancelled = true;
    };
  }, []);

  const currentUser = users.find((candidate) => candidate.email === user?.email) ?? null;
  const roleName = roles.find((role) => role.id === currentUser?.role_id)?.name ?? "";

  const userName = currentUser
    ? `${currentUser.first_name} ${currentUser.last_name}`.trim()
    : `${user?.firstName ?? ""} ${user?.lastName ?? ""}`.trim() || (user?.email.split("@")[0] ?? "");
  const userInitials = currentUser
    ? getInitialsFromName(currentUser.first_name, currentUser.last_name)
    : getInitialsFromEmail(user?.email ?? "");
  const userEmail = user?.email ?? "";
  const userJobTitle = user?.jobTitle ?? currentUser?.job_title ?? "";

  const activeWorkflowCount = workflows.filter((workflow) => workflow.status === "Active").length;

  const stats: DashboardStat[] = [
    {
      label: "Workflows",
      value: String(workflows.length),
      icon: Workflow,
      accent: "bg-primary/10 text-primary",
    },
    {
      label: "Active workflows",
      value: String(activeWorkflowCount),
      icon: CircleCheck,
      accent: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
    },
    {
      label: "Members",
      value: String(users.length),
      icon: Users,
      accent: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
    },
    {
      label: "Roles",
      value: String(roles.length),
      icon: ShieldCheck,
      accent: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
    },
  ];

  return {
    userEmail,
    userName,
    userRole: roleName,
    userJobTitle,
    userInitials,
    greeting: resolveGreeting(),
    stats,
    recentWorkflows: workflows.slice(0, RECENT_WORKFLOWS_LIMIT),
    hasWorkflows: workflows.length > 0,
    isLoading,
  };
}
