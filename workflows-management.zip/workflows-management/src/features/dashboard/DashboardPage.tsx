import DashboardLayout from "@/shared/components/DashboardLayout";
import DashboardWelcome from "@/features/dashboard/components/DashboardWelcome";
import DashboardStats from "@/features/dashboard/components/DashboardStats";
import DashboardNextSteps from "@/features/dashboard/components/DashboardNextSteps";
import DashboardRecentWorkflows from "@/features/dashboard/components/DashboardRecentWorkflows";
import useDashboard from "@/features/dashboard/hooks/useDashboard";

export default function DashboardPage() {
  const {
    greeting,
    userName,
    userEmail,
    userRole,
    userInitials,
    stats,
    recentWorkflows,
    hasWorkflows,
    isLoading,
  } = useDashboard();

  return (
    <DashboardLayout title="Overview" subtitle="A snapshot of your workspace at a glance.">
      <div className="flex flex-col gap-6 min-w-0">
        <DashboardWelcome
          greeting={greeting}
          userName={userName}
          userEmail={userEmail}
          userRole={userRole}
          userInitials={userInitials}
        />
        <DashboardStats stats={stats} isLoading={isLoading} />
        {!isLoading && hasWorkflows ? (
          <DashboardRecentWorkflows workflows={recentWorkflows} />
        ) : null}
        {!isLoading && !hasWorkflows ? <DashboardNextSteps /> : null}
      </div>
    </DashboardLayout>
  );
}
