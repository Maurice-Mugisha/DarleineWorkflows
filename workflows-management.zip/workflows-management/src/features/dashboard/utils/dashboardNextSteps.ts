import { Workflow, Users, GitBranch } from "lucide-react";
import type { DashboardNextStep } from "@/features/dashboard/types/dashboard";

export const DASHBOARD_NEXT_STEPS: DashboardNextStep[] = [
  {
    title: "Create your first workflow",
    description: "Model a process as an ordered set of steps your team can follow.",
    icon: Workflow,
  },
  {
    title: "Invite your team",
    description: "Add members to your workspace and assign roles and privileges.",
    icon: Users,
  },
  {
    title: "Configure steps and thresholds",
    description: "Set progress percentages and warning thresholds to catch bottlenecks early.",
    icon: GitBranch,
  },
];
