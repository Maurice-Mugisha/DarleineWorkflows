import type { LucideIcon } from "lucide-react";

export interface DashboardNextStep {
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface DashboardStat {
  label: string;
  value: string;
  icon: LucideIcon;
  accent: string;
}
