import { Card, CardContent } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import type { DashboardStat } from "@/features/dashboard/types/dashboard";

interface DashboardStatsProps {
  stats: DashboardStat[];
  isLoading: boolean;
}

export default function DashboardStats({ stats, isLoading }: DashboardStatsProps) {
  return (
    <section className="grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card key={stat.label}>
          <CardContent>
            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <p className="text-muted-foreground text-sm font-medium">{stat.label}</p>
                {isLoading ? (
                  <Skeleton className="mt-2 h-8 w-12" />
                ) : (
                  <p className="mt-1 text-3xl font-semibold tracking-tight tabular-nums">
                    {stat.value}
                  </p>
                )}
              </div>
              <span
                className={`flex size-11 items-center justify-center rounded-md ${stat.accent}`}
              >
                <stat.icon className="size-5" />
              </span>
            </div>
          </CardContent>
        </Card>
      ))}
    </section>
  );
}
