import { Badge } from "@/shared/ui/badge";
import InitialsAvatar from "@/shared/components/InitialsAvatar";
import LiveClock from "@/features/dashboard/components/LiveClock";

interface DashboardWelcomeProps {
  greeting: string;
  userName: string;
  userEmail: string;
  userRole: string;
  userInitials: string;
}

export default function DashboardWelcome({
  greeting,
  userName,
  userEmail,
  userRole,
  userInitials,
}: DashboardWelcomeProps) {
  return (
    <div className="border-border from-primary/5 to-card relative overflow-hidden rounded-md border bg-linear-to-br p-6 sm:p-8">
      <div className="relative flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-center gap-4 min-w-0">
          <InitialsAvatar initials={userInitials} className="size-14 text-lg shadow-sm shrink-0" />
          <div className="min-w-0">
            <p className="text-muted-foreground text-sm">{greeting},</p>
            <h2 className="truncate text-2xl font-semibold tracking-tight sm:text-3xl">
              {userName || "there"}
            </h2>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {userRole ? <Badge>{userRole}</Badge> : null}
              {userEmail ? (
                <span className="text-muted-foreground text-sm">{userEmail}</span>
              ) : null}
            </div>
          </div>
        </div>

        <div className="hidden sm:block">
          <LiveClock />
        </div>
      </div>

      <p className="text-muted-foreground relative mt-6 max-w-2xl text-sm">
        This is your workspace home. Set up workflows, bring your team on board, and track every
        case with clarity.
      </p>
    </div>
  );
}
