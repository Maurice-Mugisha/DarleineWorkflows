import useLiveClock from "@/shared/hooks/useLiveClock";

const TIME_FORMATTER = new Intl.DateTimeFormat(undefined, {
  hour: "2-digit",
  minute: "2-digit",
});

const DATE_FORMATTER = new Intl.DateTimeFormat(undefined, {
  weekday: "long",
  month: "long",
  day: "numeric",
});

export default function LiveClock() {
  const now = useLiveClock();

  return (
    <div className="text-right">
      <p className="text-3xl font-semibold tracking-tight tabular-nums">
        {TIME_FORMATTER.format(now)}
      </p>
      <p className="text-muted-foreground mt-0.5 text-sm">{DATE_FORMATTER.format(now)}</p>
    </div>
  );
}
