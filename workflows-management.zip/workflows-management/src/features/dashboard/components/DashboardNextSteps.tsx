import { Card, CardHeader, CardTitle, CardDescription } from "@/shared/ui/card";
import { DASHBOARD_NEXT_STEPS } from "@/features/dashboard/utils/dashboardNextSteps";

export default function DashboardNextSteps() {
  return (
    <section>
      <h2 className="text-lg font-semibold tracking-tight">Get set up</h2>
      <div className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {DASHBOARD_NEXT_STEPS.map((step) => (
          <Card key={step.title} className="h-full">
            <CardHeader>
              <span className="bg-primary/10 text-primary mb-2 flex size-11 items-center justify-center rounded-md">
                <step.icon className="size-6" />
              </span>
              <CardTitle>{step.title}</CardTitle>
              <CardDescription>{step.description}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
    </section>
  );
}
