import { Link } from "react-router-dom";
import { ArrowRight, ChevronRight, ListChecks } from "lucide-react";
import { Badge } from "@/shared/ui/badge";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Workflow } from "@/features/workflows/types/workflow";

interface DashboardRecentWorkflowsProps {
  workflows: Workflow[];
}

export default function DashboardRecentWorkflows({ workflows }: DashboardRecentWorkflowsProps) {
  return (
    <section>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-lg font-semibold tracking-tight">Recent workflows</h2>
        <Link
          to={ROUTE_PATHS.workflows}
          className="text-primary flex items-center gap-1 text-sm font-medium hover:underline"
        >
          View all
          <ArrowRight className="size-4" />
        </Link>
      </div>

      <div className="border-border bg-card divide-border divide-y overflow-hidden rounded-md border">
        {workflows.map((workflow) => (
          <Link
            key={workflow.id}
            to={ROUTE_PATHS.workflowDetail.replace(":workflowId", workflow.id)}
            state={{ workflow }}
            className="hover:bg-muted/50 flex items-center gap-4 px-4 py-3 transition-colors"
          >
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">{workflow.name}</p>
              <p className="text-muted-foreground truncate text-sm">{workflow.description}</p>
            </div>
            <span className="text-muted-foreground hidden items-center gap-1 text-xs sm:flex">
              <ListChecks className="size-3.5" />
              {workflow.number_of_steps} steps
            </span>
            <Badge variant={workflow.status === "Active" ? "default" : "secondary"}>
              {workflow.status}
            </Badge>
            <ChevronRight className="text-muted-foreground size-4 shrink-0" />
          </Link>
        ))}
      </div>
    </section>
  );
}
