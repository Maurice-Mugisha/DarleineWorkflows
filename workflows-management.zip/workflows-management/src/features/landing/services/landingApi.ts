import apiClient from "@/shared/lib/apiClient";
import type { ContactFormValues } from "@/features/landing/schemas/contactSchema";

export default async function sendContactMessageRequest(payload: ContactFormValues): Promise<void> {
  await apiClient.post("/api/v1/contact", payload);
}
