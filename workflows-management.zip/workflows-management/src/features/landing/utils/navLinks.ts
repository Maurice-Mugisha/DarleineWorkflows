import { ROUTE_PATHS } from "@/routes/routePaths";
import type { NavLink } from "@/features/landing/types/landing";

export const NAV_LINKS: NavLink[] = [
  { label: "About", href: `${ROUTE_PATHS.landing}#about` },
  { label: "Features", href: `${ROUTE_PATHS.landing}#features` },
  { label: "Why us", href: `${ROUTE_PATHS.landing}#why-us` },
  { label: "FAQ", href: `${ROUTE_PATHS.landing}#faq` },
  { label: "Contact", href: `${ROUTE_PATHS.landing}#contact` },
];
