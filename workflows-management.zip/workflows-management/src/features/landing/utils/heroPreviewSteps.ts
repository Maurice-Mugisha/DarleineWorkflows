import type { HeroPreviewStep } from "@/features/landing/types/landing";

export const HERO_PREVIEW_WORKFLOW_NAME = "Employee onboarding";

export const HERO_PREVIEW_STEPS: HeroPreviewStep[] = [
  { name: "Submit request", status: "done", percentage: 100 },
  { name: "Manager review", status: "done", percentage: 100 },
  { name: "Compliance check", status: "active", percentage: 60, isAboveWarningThreshold: true },
  { name: "Provision access", status: "pending", percentage: 0 },
];
