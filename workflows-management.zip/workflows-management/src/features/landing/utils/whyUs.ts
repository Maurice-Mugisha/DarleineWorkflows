import { Rocket, LineChart, Puzzle, Headphones } from "lucide-react";
import type { WhyUsItem } from "@/features/landing/types/landing";

export const WHY_US: WhyUsItem[] = [
  {
    title: "Live in minutes",
    description:
      "Register a workspace, invite your team, and model your first workflow the same day.",
    icon: Rocket,
  },
  {
    title: "Clarity at every step",
    description:
      "Real-time visibility into cases and steps means fewer status meetings and no guesswork.",
    icon: LineChart,
  },
  {
    title: "Fits how you work",
    description:
      "Flexible workflows, steps, and time units adapt to your process instead of forcing a rewrite.",
    icon: Puzzle,
  },
  {
    title: "Support that responds",
    description: "A responsive team helps you onboard and get the most out of every workflow.",
    icon: Headphones,
  },
];
