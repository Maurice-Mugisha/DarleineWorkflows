import type { FaqItem } from "@/features/landing/types/landing";

export const FAQS: FaqItem[] = [
  {
    question: "What is Flowspace?",
    answer:
      "Flowspace is a workflow management platform that helps teams design, track, and improve multi-step processes from a single shared workspace.",
  },
  {
    question: "Do I need a credit card to get started?",
    answer:
      "No. You can register a workspace and explore the core features without entering any payment details.",
  },
  {
    question: "Who should the workspace admin be?",
    answer:
      "The admin is usually the person responsible for setting up processes and inviting the team. You can add more members and adjust roles later.",
  },
  {
    question: "Can I manage more than one workflow?",
    answer:
      "Yes. A workspace can hold as many workflows as you need, each with its own steps, statuses, and warning thresholds.",
  },
  {
    question: "Is my data secure?",
    answer:
      "Access is governed by roles and privileges, so team members only see what they are allowed to. Your process data stays within your workspace.",
  },
  {
    question: "Can I change my workspace details later?",
    answer:
      "Absolutely. Workspace information such as name, description, and language can be updated at any time from your settings.",
  },
];
