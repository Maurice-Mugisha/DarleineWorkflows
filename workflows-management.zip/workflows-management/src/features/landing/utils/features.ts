import { GitBranch, Workflow, Gauge, Bell, Users, ShieldCheck } from "lucide-react";
import type { FeatureItem } from "@/features/landing/types/landing";

export const FEATURES: FeatureItem[] = [
  {
    title: "Visual workflow builder",
    description:
      "Design multi-step processes with clear ownership, ordering, and dependencies. No code required.",
    icon: Workflow,
  },
  {
    title: "Step-level tracking",
    description:
      "Break workflows into steps with progress percentages, statuses, and codes your team can rely on.",
    icon: GitBranch,
  },
  {
    title: "Warning thresholds",
    description:
      "Set thresholds on each step and surface bottlenecks before they turn into missed deadlines.",
    icon: Gauge,
  },
  {
    title: "Smart notifications",
    description:
      "Keep everyone aligned with timely updates when cases move, stall, or need attention.",
    icon: Bell,
  },
  {
    title: "Team workspaces",
    description:
      "Give each organization its own workspace with roles, privileges, and tailored access.",
    icon: Users,
  },
  {
    title: "Secure by design",
    description:
      "Granular roles and privileges keep sensitive process data in the right hands at all times.",
    icon: ShieldCheck,
  },
];
