import type { LucideIcon } from "lucide-react";

export interface NavLink {
  label: string;
  href: string;
}

export interface FeatureItem {
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface WhyUsItem {
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export type HeroPreviewStepStatus = "done" | "active" | "pending";

export interface HeroPreviewStep {
  name: string;
  status: HeroPreviewStepStatus;
  percentage: number;
  isAboveWarningThreshold?: boolean;
}
