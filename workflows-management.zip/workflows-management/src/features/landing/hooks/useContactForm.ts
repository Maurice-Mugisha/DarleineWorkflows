import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { contactSchema, type ContactFormValues } from "@/features/landing/schemas/contactSchema";
import sendContactMessageRequest from "@/features/landing/services/landingApi";

const INITIAL_VALUES: ContactFormValues = {
  name: "",
  email: "",
  message: "",
};

export default function useContactForm() {
  const form = useZodForm<ContactFormValues>({
    schema: contactSchema,
    initialValues: INITIAL_VALUES,
    onValidSubmit: async (values) => {
      try {
        await sendContactMessageRequest(values);
        toast.success("Thanks for reaching out! We'll get back to you soon.");
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to send your message. Please try again."));
      }
    },
  });

  return form;
}
