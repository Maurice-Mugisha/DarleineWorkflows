import Navbar from "@/features/landing/components/Navbar";
import HeroSection from "@/features/landing/components/HeroSection";
// import AboutSection from "@/features/landing/components/AboutSection";
// import FeaturesSection from "@/features/landing/components/FeaturesSection";
// import WhyUsSection from "@/features/landing/components/WhyUsSection";
// import FaqSection from "@/features/landing/components/FaqSection";
// import ContactSection from "@/features/landing/components/ContactSection";
import Footer from "@/features/landing/components/Footer";

export default function LandingPage() {
  return (
    <div className="flex min-h-svh flex-col">
      <Navbar />
      <main className="flex-1">
        <HeroSection />
        {/* <AboutSection />
        <FeaturesSection />
        <WhyUsSection />
        <FaqSection />
        <ContactSection /> */}
      </main>
      <Footer />
    </div>
  );
}
