import Section from "@/shared/components/Section";

const STATS = [
  { value: "6-step", label: "workflows modeled with ease" },
  { value: "Real-time", label: "visibility into every case" },
  { value: "Role-based", label: "access for every member" },
];

export default function AboutSection() {
  return (
    <Section id="about" className="bg-muted/40">
      <div className="grid items-center gap-12 lg:grid-cols-2">
        <div>
          <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">
            Built for teams who live in their processes
          </h2>
          <p className="text-muted-foreground mt-4">
            Spreadsheets and scattered tools make it hard to see where work actually stands.
            Flowspace brings your workflows, steps, and cases together so everyone knows what is
            done, what is next, and what needs attention.
          </p>
          <p className="text-muted-foreground mt-4">
            From onboarding to approvals to operations, model the process once and let your team run
            it with confidence. No more guesswork, no more status chasing.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1 lg:gap-6">
          {STATS.map((stat) => (
            <div key={stat.label} className="border-border bg-card rounded-lg border p-6">
              <p className="text-primary text-2xl font-semibold">{stat.value}</p>
              <p className="text-muted-foreground mt-1 text-sm">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
