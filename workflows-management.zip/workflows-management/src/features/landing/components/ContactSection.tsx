import Section from "@/shared/components/Section";
import { Button } from "@/shared/ui/button";
import { Card, CardContent } from "@/shared/ui/card";
import TextField from "@/shared/components/TextField";
import TextareaField from "@/shared/components/TextareaField";
import useContactForm from "@/features/landing/hooks/useContactForm";

export default function ContactSection() {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit } = useContactForm();

  return (
    <Section id="contact" className="bg-muted/40">
      <div className="grid gap-12 lg:grid-cols-2">
        <div>
          <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">Get in touch</h2>
          <p className="text-muted-foreground mt-4">
            Have a question about Flowspace or want to see how it fits your team? Send us a message
            and we&apos;ll get back to you.
          </p>
        </div>
        <Card>
          <CardContent className="pt-6">
            <form className="flex flex-col gap-5" noValidate onSubmit={handleSubmit}>
              <TextField
                id="name"
                label="Name"
                placeholder="Your name"
                value={values.name}
                error={errors.name}
                required
                onValueChange={getFieldHandler("name")}
              />
              <TextField
                id="contactEmail"
                label="Email"
                type="email"
                placeholder="you@company.com"
                value={values.email}
                error={errors.email}
                required
                onValueChange={getFieldHandler("email")}
              />
              <TextareaField
                id="message"
                label="Message"
                placeholder="How can we help?"
                className="min-h-32"
                value={values.message}
                error={errors.message}
                required
                onValueChange={getFieldHandler("message")}
              />
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Sending..." : "Send message"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </Section>
  );
}
