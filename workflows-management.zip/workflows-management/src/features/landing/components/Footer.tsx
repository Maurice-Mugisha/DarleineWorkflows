import { Link } from "react-router-dom";
import Logo from "@/shared/components/Logo";
import { ROUTE_PATHS } from "@/routes/routePaths";
import { NAV_LINKS } from "@/features/landing/utils/navLinks";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-border border-t">
      <div className="mx-auto w-full max-w-6xl px-4 py-12">
        <div className="flex flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <div className="max-w-sm">
            <Logo />
            <p className="text-muted-foreground mt-4 text-sm">
              Design workflows, track every step, and keep your team moving, all in one workspace.
            </p>
          </div>
          <nav className="flex flex-col gap-3">
            <span className="text-sm font-semibold">Product</span>
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-muted-foreground hover:text-foreground text-sm transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>
          <nav className="flex flex-col gap-3">
            <span className="text-sm font-semibold">Get started</span>
            <Link
              to={ROUTE_PATHS.register}
              className="text-muted-foreground hover:text-foreground text-sm transition-colors"
            >
              Register a workspace
            </Link>
            <Link
              to={ROUTE_PATHS.login}
              className="text-muted-foreground hover:text-foreground text-sm transition-colors"
            >
              Log in
            </Link>
          </nav>
        </div>
        <div className="border-border text-muted-foreground mt-10 border-t pt-6 text-sm">
          &copy; {currentYear} Flowspace. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
