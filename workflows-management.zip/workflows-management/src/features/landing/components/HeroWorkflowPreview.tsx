import { AlertTriangle, Check, CircleDot, Circle, TrendingUp } from "lucide-react";
import { cn } from "@/shared/utils/cn";
import {
  HERO_PREVIEW_STEPS,
  HERO_PREVIEW_WORKFLOW_NAME,
} from "@/features/landing/utils/heroPreviewSteps";
import type { HeroPreviewStepStatus } from "@/features/landing/types/landing";

const STATUS_LABEL: Record<HeroPreviewStepStatus, string> = {
  done: "Done",
  active: "In progress",
  pending: "Pending",
};

function StepIcon({ status }: { status: HeroPreviewStepStatus }) {
  if (status === "done") {
    return (
      <span className="flex size-6 items-center justify-center rounded-full bg-green-600 text-white dark:bg-green-500">
        <Check className="size-3.5" />
      </span>
    );
  }
  if (status === "active") {
    return (
      <span className="bg-primary/15 text-primary flex size-6 items-center justify-center rounded-full">
        <CircleDot className="size-3.5" />
      </span>
    );
  }
  return (
    <span className="bg-muted text-muted-foreground flex size-6 items-center justify-center rounded-full">
      <Circle className="size-3.5" />
    </span>
  );
}

export default function HeroWorkflowPreview() {
  const completedStepCount = HERO_PREVIEW_STEPS.filter((step) => step.status === "done").length;

  return (
    <div className="relative">
      <div className="border-border bg-card rounded-xl border p-5 shadow-xl shadow-black/5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-muted-foreground text-xs font-medium">Workflow</p>
            <p className="font-semibold">{HERO_PREVIEW_WORKFLOW_NAME}</p>
          </div>
          <span className="bg-primary/10 text-primary rounded-full px-3 py-1 text-xs font-medium">
            {completedStepCount}/{HERO_PREVIEW_STEPS.length} steps
          </span>
        </div>

        <ul className="mt-5 flex flex-col gap-4">
          {HERO_PREVIEW_STEPS.map((step) => (
            <li key={step.name} className="flex items-center gap-3">
              <StepIcon status={step.status} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={cn(
                      "truncate text-sm font-medium",
                      step.status === "pending" && "text-muted-foreground",
                    )}
                  >
                    {step.name}
                  </span>
                  {step.isAboveWarningThreshold ? (
                    <span className="flex shrink-0 items-center gap-1 rounded-full bg-amber-500/15 px-2 py-0.5 text-xs font-medium text-amber-600 dark:text-amber-400">
                      <AlertTriangle className="size-3" />
                      Over threshold
                    </span>
                  ) : (
                    <span className="text-muted-foreground shrink-0 text-xs">
                      {STATUS_LABEL[step.status]}
                    </span>
                  )}
                </div>
                <div className="bg-muted mt-1.5 h-1.5 w-full overflow-hidden rounded-full">
                  <div
                    className={cn(
                      "h-full rounded-full",
                      step.status === "done" ? "bg-green-600 dark:bg-green-500" : "bg-primary",
                    )}
                    style={{ width: `${step.percentage}%` }}
                  />
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>

      <div className="border-border bg-card animate-in fade-in slide-in-from-top-2 absolute -top-4 -right-3 hidden items-center gap-2 rounded-lg border px-3 py-2 shadow-lg duration-700 sm:flex">
        <span className="flex size-6 items-center justify-center rounded-full bg-green-600/15 text-green-600 dark:text-green-400">
          <TrendingUp className="size-3.5" />
        </span>
        <div className="leading-tight">
          <p className="text-xs font-semibold">98% on time</p>
          <p className="text-muted-foreground text-[11px]">this quarter</p>
        </div>
      </div>

      <div className="border-border bg-card animate-in fade-in slide-in-from-bottom-2 absolute -bottom-4 -left-3 hidden items-center gap-2 rounded-lg border px-3 py-2 shadow-lg duration-700 md:flex">
        <span className="bg-primary/15 text-primary flex size-6 items-center justify-center rounded-full">
          <Check className="size-3.5" />
        </span>
        <p className="text-xs font-medium">Case advanced to Compliance</p>
      </div>
    </div>
  );
}
