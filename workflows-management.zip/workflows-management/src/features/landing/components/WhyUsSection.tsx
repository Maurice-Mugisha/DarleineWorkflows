import Section from "@/shared/components/Section";
import { WHY_US } from "@/features/landing/utils/whyUs";

export default function WhyUsSection() {
  return (
    <Section id="why-us" className="bg-muted/40">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">Why teams choose us</h2>
        <p className="text-muted-foreground mt-4">
          A platform that gets out of your way and helps your processes run themselves.
        </p>
      </div>
      <div className="mt-12 grid gap-8 sm:grid-cols-2">
        {WHY_US.map((item) => (
          <div key={item.title} className="flex gap-4">
            <span className="bg-primary/10 text-primary flex size-11 shrink-0 items-center justify-center rounded-md">
              <item.icon className="size-6" />
            </span>
            <div>
              <h3 className="font-semibold">{item.title}</h3>
              <p className="text-muted-foreground mt-1 text-sm">{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}
