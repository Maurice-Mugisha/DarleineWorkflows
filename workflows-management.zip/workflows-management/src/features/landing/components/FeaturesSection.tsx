import Section from "@/shared/components/Section";
import { Card, CardHeader, CardTitle, CardDescription } from "@/shared/ui/card";
import { FEATURES } from "@/features/landing/utils/features";

export default function FeaturesSection() {
  return (
    <Section id="features">
      <div className="mx-auto max-w-2xl text-center">
        <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">
          Everything you need to manage workflows
        </h2>
        <p className="text-muted-foreground mt-4">
          Powerful building blocks that adapt to your process instead of forcing you into a rigid
          template.
        </p>
      </div>
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map((feature) => (
          <Card key={feature.title} className="h-full">
            <CardHeader>
              <span className="bg-primary/10 text-primary mb-2 flex size-11 items-center justify-center rounded-md">
                <feature.icon className="size-6" />
              </span>
              <CardTitle>{feature.title}</CardTitle>
              <CardDescription>{feature.description}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
    </Section>
  );
}
