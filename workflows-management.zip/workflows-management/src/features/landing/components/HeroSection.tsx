import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { ROUTE_PATHS } from "@/routes/routePaths";
import HeroWorkflowPreview from "@/features/landing/components/HeroWorkflowPreview";

const HERO_HIGHLIGHTS = ["Free to start", "No credit card required", "Set up in minutes"];

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10 [background-image:linear-gradient(to_right,var(--color-border)_1px,transparent_1px),linear-gradient(to_bottom,var(--color-border)_1px,transparent_1px)] [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)] [background-size:44px_44px] opacity-50"
      />
      <div
        aria-hidden="true"
        className="bg-primary/10 pointer-events-none absolute -top-32 left-1/2 -z-10 size-[620px] -translate-x-1/2 rounded-full blur-3xl"
      />

      <div className="mx-auto grid w-full max-w-6xl items-center gap-12 px-4 pt-20 pb-16 sm:pt-24 lg:grid-cols-2 lg:gap-8 lg:pt-28 lg:pb-24">
        <div className="flex flex-col items-center text-center lg:items-start lg:text-left">
          <span className="border-border bg-background/60 text-muted-foreground mb-6 inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-sm font-medium backdrop-blur">
            <span className="bg-primary size-2 rounded-full" />
            Workflow management, simplified
          </span>
          <h1 className="text-4xl font-semibold tracking-tight text-balance sm:text-5xl lg:text-6xl">
            Run every process with <span className="text-primary">total clarity</span>
          </h1>
          <p className="text-muted-foreground mt-6 max-w-xl text-lg text-pretty">
            Flowspace brings your workflows, steps, and cases into one workspace, so your team
            always knows what is done, what is next, and what needs attention.
          </p>
          <div className="mt-8 flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
            <Button size="lg" asChild>
              <Link to={ROUTE_PATHS.register}>
                Get started
                <ArrowRight />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to={ROUTE_PATHS.workspaces}>
                Register in a Workspace
                <ArrowRight />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to={ROUTE_PATHS.login}>Log in</Link>
            </Button>
          </div>
          <ul className="text-muted-foreground mt-10 flex flex-col items-center gap-3 text-sm sm:flex-row sm:gap-6 lg:items-start">
            {HERO_HIGHLIGHTS.map((highlight) => (
              <li key={highlight} className="flex items-center gap-2">
                <CheckCircle2 className="text-primary size-4" />
                {highlight}
              </li>
            ))}
          </ul>
        </div>

        <div className="w-full max-w-md justify-self-center lg:max-w-none lg:justify-self-end">
          <HeroWorkflowPreview />
        </div>
      </div>
    </section>
  );
}
