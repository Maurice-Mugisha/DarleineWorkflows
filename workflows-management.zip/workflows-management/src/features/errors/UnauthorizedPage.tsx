import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import StatusPage from "@/shared/components/StatusPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function UnauthorizedPage() {
  return (
    <StatusPage
      code="401"
      title="You're not signed in"
      message="You are not allowed to access this page. Please sign in to continue."
      action={
        <Button asChild>
          <Link to={ROUTE_PATHS.login}>Go to login</Link>
        </Button>
      }
    />
  );
}
