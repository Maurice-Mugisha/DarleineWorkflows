import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import StatusPage from "@/shared/components/StatusPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function ForbiddenPage() {
  return (
    <StatusPage
      code="403"
      title="Access denied"
      message="You are not allowed to access this page."
      action={
        <Button asChild>
          <Link to={ROUTE_PATHS.dashboard}>Back to dashboard</Link>
        </Button>
      }
    />
  );
}
