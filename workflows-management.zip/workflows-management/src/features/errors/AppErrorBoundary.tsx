import { useRouteError, Link } from "react-router-dom";
import { Bug, AlertTriangle, RefreshCw, ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { Card, CardContent } from "@/shared/ui/card";
import { SidebarInset, SidebarProvider } from "@/shared/ui/sidebar";
import AppSidebar from "@/shared/components/AppSidebar";
import ThemeMenu from "@/shared/components/ThemeMenu";
import UserMenu from "@/shared/components/UserMenu";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function AppErrorBoundary() {
  const error = useRouteError();

  const message = error instanceof Error ? error.message : "An unexpected error occurred.";
  const stack = error instanceof Error ? error.stack : "";

  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="min-w-0">
        <header className="border-border bg-background sticky top-0 z-10 border-b">
          <div className="flex h-16 items-center justify-end px-4 sm:px-6">
            <div className="flex items-center gap-2">
              <ThemeMenu />
              <UserMenu />
            </div>
          </div>
        </header>
        <div className="mx-auto w-full max-w-6xl flex-1 p-4 sm:p-6">
          <div className="flex flex-col items-center py-16 text-center">
            <span className="bg-destructive/10 text-destructive mb-6 flex size-20 items-center justify-center rounded-2xl">
              <Bug className="size-10" />
            </span>

            <h1 className="text-2xl font-semibold tracking-tight">Something went wrong</h1>
            <p className="text-muted-foreground mt-2 max-w-md">
              An unexpected error occurred. The details below may help diagnose the issue.
            </p>

            <Card className="border-destructive/50 mt-8 w-full max-w-2xl text-left">
              <CardContent className="flex items-start gap-3">
                <AlertTriangle className="text-destructive mt-0.5 size-5 shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-medium">Error message</p>
                  <p className="text-muted-foreground mt-1 text-sm break-words">{message}</p>
                </div>
              </CardContent>
            </Card>

            {stack ? (
              <details className="border-border mt-4 w-full max-w-2xl rounded-md border">
                <summary className="cursor-pointer px-4 py-3 text-sm font-medium select-none">
                  Stack trace
                </summary>
                <pre className="text-muted-foreground border-border overflow-auto border-t p-4 text-xs max-h-64 whitespace-pre-wrap break-all">
                  {stack}
                </pre>
              </details>
            ) : null}

            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <Button variant="outline" asChild>
                <Link to={ROUTE_PATHS.dashboard}>
                  <ArrowLeft />
                  Back to dashboard
                </Link>
              </Button>
              <Button onClick={() => window.location.reload()}>
                <RefreshCw />
                Try again
              </Button>
            </div>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}
