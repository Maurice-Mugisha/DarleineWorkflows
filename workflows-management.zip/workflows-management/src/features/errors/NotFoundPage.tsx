import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import StatusPage from "@/shared/components/StatusPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function NotFoundPage() {
  return (
    <StatusPage
      code="404"
      title="Page not found"
      message="The page you are looking for doesn't exist or may have been moved."
      action={
        <Button asChild>
          <Link to={ROUTE_PATHS.dashboard}>Back to dashboard</Link>
        </Button>
      }
    />
  );
}
