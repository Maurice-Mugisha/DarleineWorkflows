import { Link, Navigate, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PrivilegeForm from "@/features/privileges/components/PrivilegeForm";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Privilege } from "@/features/privileges/types/privilege";

export default function EditPrivilegePage() {
  const location = useLocation();
  const privilege = (location.state as { privilege?: Privilege } | null)?.privilege ?? null;

  if (privilege === null) {
    return <Navigate to={ROUTE_PATHS.privileges} replace />;
  }

  return (
    <DashboardLayout title="Edit privilege" subtitle="Update this privilege.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.privileges}>
            <ArrowLeft />
            Back to privileges
          </Link>
        </Button>
        <PrivilegeForm existingPrivilege={privilege} />
      </div>
    </DashboardLayout>
  );
}
