import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PrivilegeForm from "@/features/privileges/components/PrivilegeForm";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function CreatePrivilegePage() {
  return (
    <DashboardLayout title="Create privilege" subtitle="Define a new privilege.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.privileges}>
            <ArrowLeft />
            Back to privileges
          </Link>
        </Button>
        <PrivilegeForm />
      </div>
    </DashboardLayout>
  );
}
