import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import {
  fetchAllPrivilegesRequest,
  deletePrivilegeRequest,
} from "@/features/privileges/services/privilegeApi";
import type { Privilege } from "@/features/privileges/types/privilege";

export default function usePrivilegesPage() {
  const [privileges, setPrivileges] = useState<Privilege[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useNavigationSuccessToast("privilegeCreated", "Privilege created successfully.");
  useNavigationSuccessToast("privilegeUpdated", "Privilege updated successfully.");

  useEffect(() => {
    let cancelled = false;

    async function fetchPrivileges() {
      try {
        const data = await fetchAllPrivilegesRequest();
        if (!cancelled) {
          setPrivileges(data);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load privileges."));
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    fetchPrivileges();

    return () => {
      cancelled = true;
    };
  }, []);

  const handleDeletePrivilege = async (privilegeId: string) => {
    try {
      await deletePrivilegeRequest(privilegeId);
      setPrivileges((previous) => previous.filter((privilege) => privilege.id !== privilegeId));
      toast.success("Privilege deleted.");
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to delete the privilege."));
    }
  };

  return { privileges, isLoading, handleDeletePrivilege };
}
