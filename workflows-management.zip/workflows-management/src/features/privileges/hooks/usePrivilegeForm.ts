import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";
import {
  privilegeSchema,
  type PrivilegeFormValues,
} from "@/features/privileges/schemas/privilegeSchema";
import buildPrivilegePayload from "@/features/privileges/utils/buildPrivilegePayload";
import {
  createPrivilegeRequest,
  updatePrivilegeRequest,
} from "@/features/privileges/services/privilegeApi";
import type { Privilege } from "@/features/privileges/types/privilege";

interface UsePrivilegeFormOptions {
  existingPrivilege?: Privilege;
}

function buildInitialValues(existingPrivilege?: Privilege): PrivilegeFormValues {
  return {
    name: existingPrivilege?.name ?? "",
    description: existingPrivilege?.description ?? "",
  };
}

export default function usePrivilegeForm({ existingPrivilege }: UsePrivilegeFormOptions) {
  const navigate = useNavigate();

  return useZodForm<PrivilegeFormValues>({
    schema: privilegeSchema,
    initialValues: buildInitialValues(existingPrivilege),
    onValidSubmit: async (values) => {
      try {
        if (existingPrivilege) {
          await updatePrivilegeRequest(buildPrivilegePayload(values, existingPrivilege.id));
          navigate(ROUTE_PATHS.privileges, { state: { privilegeUpdated: true } });
        } else {
          await createPrivilegeRequest(buildPrivilegePayload(values));
          navigate(ROUTE_PATHS.privileges, { state: { privilegeCreated: true } });
        }
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to save the privilege. Please try again."));
      }
    },
  });
}
