import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/shared/ui/card";
import TextField from "@/shared/components/TextField";
import TextareaField from "@/shared/components/TextareaField";
import usePrivilegeForm from "@/features/privileges/hooks/usePrivilegeForm";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Privilege } from "@/features/privileges/types/privilege";

interface PrivilegeFormProps {
  existingPrivilege?: Privilege;
}

export default function PrivilegeForm({ existingPrivilege }: PrivilegeFormProps) {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit } = usePrivilegeForm({
    existingPrivilege,
  });

  const isEditing = existingPrivilege !== undefined;

  return (
    <form noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Privilege details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-5">
            <TextField
              id="name"
              label="Privilege name"
              placeholder="Manage workflows"
              value={values.name}
              error={errors.name}
              required
              onValueChange={getFieldHandler("name")}
            />
            <TextareaField
              id="description"
              label="Description"
              placeholder="What does this privilege allow?"
              value={values.description ?? ""}
              error={errors.description}
              onValueChange={getFieldHandler("description")}
            />
          </div>
        </CardContent>
        <CardFooter className="gap-3">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : isEditing ? "Save changes" : "Create privilege"}
          </Button>
          <Button type="button" variant="ghost" asChild>
            <Link to={ROUTE_PATHS.privileges}>Cancel</Link>
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
