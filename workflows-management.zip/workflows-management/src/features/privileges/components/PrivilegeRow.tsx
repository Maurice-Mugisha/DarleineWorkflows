import { useState } from "react";
import { Link } from "react-router-dom";
import { MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/shared/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import ConfirmDialog from "@/shared/components/ConfirmDialog";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Privilege } from "@/features/privileges/types/privilege";

interface PrivilegeRowProps {
  privilege: Privilege;
  onDelete: (privilegeId: string) => Promise<void>;
}

export default function PrivilegeRow({ privilege, onDelete }: PrivilegeRowProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    setIsDeleting(true);
    await onDelete(privilege.id);
    setIsDeleting(false);
    setShowDeleteDialog(false);
  };

  return (
    <>
      <div className="border-border flex items-start justify-between gap-4 rounded-lg border p-4">
        <div className="min-w-0">
          <p className="font-medium">{privilege.name}</p>
          {privilege.description ? (
            <p className="text-muted-foreground mt-0.5 text-sm">{privilege.description}</p>
          ) : null}
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="size-8 shrink-0"
              aria-label="Privilege actions"
            >
              <MoreHorizontal className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem asChild>
              <Link
                to={ROUTE_PATHS.editPrivilege.replace(":privilegeId", privilege.id)}
                state={{ privilege }}
              >
                <Pencil />
                Edit
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem variant="destructive" onClick={() => setShowDeleteDialog(true)}>
              <Trash2 />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onConfirm={handleDelete}
        onCancel={() => setShowDeleteDialog(false)}
        title="Delete privilege"
        message={`Are you sure you want to delete "${privilege.name}"? This action cannot be undone.`}
        isLoading={isDeleting}
      />
    </>
  );
}
