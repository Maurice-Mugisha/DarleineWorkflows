import { Skeleton } from "@/shared/ui/skeleton";
import PrivilegeRow from "@/features/privileges/components/PrivilegeRow";
import PrivilegesEmptyState from "@/features/privileges/components/PrivilegesEmptyState";
import type { Privilege } from "@/features/privileges/types/privilege";

interface PrivilegesListProps {
  privileges: Privilege[];
  isLoading: boolean;
  onDelete: (privilegeId: string) => Promise<void>;
}

function LoadingRows() {
  return (
    <div className="flex flex-col gap-3">
      {Array.from({ length: 3 }).map((_, index) => (
        <div key={index} className="border-border rounded-lg border p-4">
          <Skeleton className="mb-2 h-5 w-40" />
          <Skeleton className="h-4 w-72" />
        </div>
      ))}
    </div>
  );
}

export default function PrivilegesList({ privileges, isLoading, onDelete }: PrivilegesListProps) {
  if (isLoading) {
    return <LoadingRows />;
  }

  if (privileges.length === 0) {
    return <PrivilegesEmptyState />;
  }

  return (
    <div className="flex flex-col gap-3">
      {privileges.map((privilege) => (
        <PrivilegeRow key={privilege.id} privilege={privilege} onDelete={onDelete} />
      ))}
    </div>
  );
}
