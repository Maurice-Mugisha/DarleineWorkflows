import type { PrivilegeFormValues } from "@/features/privileges/schemas/privilegeSchema";
import type { Privilege } from "@/features/privileges/types/privilege";

export default function buildPrivilegePayload(values: PrivilegeFormValues, id?: string): Privilege {
  return {
    id: id ?? crypto.randomUUID(),
    name: values.name.trim(),
    description: values.description?.trim() ?? "",
  };
}
