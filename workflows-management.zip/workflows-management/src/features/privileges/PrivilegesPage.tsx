import { Link } from "react-router-dom";
import { Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PrivilegesList from "@/features/privileges/components/PrivilegesList";
import usePrivilegesPage from "@/features/privileges/hooks/usePrivilegesPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function PrivilegesPage() {
  const { privileges, isLoading, handleDeletePrivilege } = usePrivilegesPage();

  const headerAction = (
    <Button asChild>
      <Link to={ROUTE_PATHS.createPrivilege}>
        <Plus />
        New privilege
      </Link>
    </Button>
  );

  return (
    <DashboardLayout
      title="Privileges"
      subtitle="Granular permissions you can group into roles."
      action={headerAction}
    >
      <PrivilegesList
        privileges={privileges}
        isLoading={isLoading}
        onDelete={handleDeletePrivilege}
      />
    </DashboardLayout>
  );
}
