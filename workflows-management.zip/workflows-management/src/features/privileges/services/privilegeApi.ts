import apiClient from "@/shared/lib/apiClient";
import type { Privilege } from "@/features/privileges/types/privilege";

export async function fetchAllPrivilegesRequest(): Promise<Privilege[]> {
  const response = await apiClient.get<Privilege[]>("/privilege/retrieve_all_privileges");
  return response.data;
}

export async function createPrivilegeRequest(payload: Privilege): Promise<void> {
  await apiClient.post("/privilege/register_a_privilege", payload);
}

export async function updatePrivilegeRequest(payload: Privilege): Promise<void> {
  await apiClient.post("/privilege/update_a_privilege", payload);
}

export async function deletePrivilegeRequest(privilegeId: string): Promise<void> {
  await apiClient.delete("/privilege/delete_a_privilege", {
    params: { privilege_id: privilegeId },
  });
}
