import { z } from "zod";

export const privilegeSchema = z.object({
  name: z.string().min(2, "Privilege name must be at least 2 characters."),
  description: z.string().optional(),
});

export type PrivilegeFormValues = z.infer<typeof privilegeSchema>;
