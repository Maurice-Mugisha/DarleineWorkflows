export interface WorkspaceAdminPayload {
  id: string;
  workspace_id: string;
  first_name: string;
  last_name: string;
  email: string;
  password: string;
  job_title: string;
}

export interface WorkspaceRegistrationPayload {
  id: string;
  name: string;
  description: string;
  language: string;
  organization_type: string;
  email: string;
  country: string;
  admin: WorkspaceAdminPayload;
}
