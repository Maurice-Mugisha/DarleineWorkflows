import type { WorkspaceRegistrationFormValues } from "@/features/workspace-registration/schemas/workspaceRegistrationSchema";
import type { WorkspaceRegistrationPayload } from "@/features/workspace-registration/types/workspaceRegistration";

export default function buildWorkspaceRegistrationPayload(
  values: WorkspaceRegistrationFormValues,
): WorkspaceRegistrationPayload {
  const workspaceId = crypto.randomUUID();
  const description = values.workspaceDescription?.trim() ?? "";

  return {
    id: workspaceId,
    name: values.workspaceName.trim(),
    description,
    language: values.workspaceLanguage,
    organization_type: values.organizationType,
    email: values.workspaceEmail.trim(),
    country: values.country,
    admin: {
      id: crypto.randomUUID(),
      workspace_id: workspaceId,
      first_name: values.adminFirstName.trim(),
      last_name: values.adminLastName.trim(),
      email: values.adminEmail.trim(),
      password: values.adminPassword,
      job_title: values.adminJobTitle.trim(),
    },
  };
}
