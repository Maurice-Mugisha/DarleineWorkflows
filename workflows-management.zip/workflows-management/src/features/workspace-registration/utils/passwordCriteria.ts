export interface PasswordCriterion {
  label: string;
  met: boolean;
}

export function normalizePassword(password: string): string {
  return password.replace(/[ \t]/g, "");
}

export function hasMinimumLength(password: string): boolean {
  return normalizePassword(password).length >= 8;
}

export function hasUppercase(password: string): boolean {
  return /[A-Z]/.test(normalizePassword(password));
}

export function hasLowercase(password: string): boolean {
  return /[a-z]/.test(normalizePassword(password));
}

export function hasNumber(password: string): boolean {
  return /[0-9]/.test(normalizePassword(password));
}

export function hasSpecialCharacter(password: string): boolean {
  return /[^A-Za-z0-9]/.test(normalizePassword(password));
}

export function passwordsMatch(password: string, confirmPassword: string): boolean {
  const normalizedPassword = normalizePassword(password);
  return normalizedPassword.length > 0 && normalizedPassword === normalizePassword(confirmPassword);
}

export function evaluatePasswordCriteria(
  password: string,
  confirmPassword: string,
): PasswordCriterion[] {
  return [
    { label: "At least 8 characters", met: hasMinimumLength(password) },
    { label: "One uppercase letter", met: hasUppercase(password) },
    { label: "One lowercase letter", met: hasLowercase(password) },
    { label: "One number", met: hasNumber(password) },
    { label: "One special character", met: hasSpecialCharacter(password) },
    { label: "Passwords match", met: passwordsMatch(password, confirmPassword) },
  ];
}
