import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";
import {
  workspaceRegistrationSchema,
  type WorkspaceRegistrationFormValues,
} from "@/features/workspace-registration/schemas/workspaceRegistrationSchema";
import buildWorkspaceRegistrationPayload from "@/features/workspace-registration/utils/buildWorkspaceRegistrationPayload";
import registerWorkspaceRequest from "@/features/workspace-registration/services/workspaceRegistrationApi";
import { evaluatePasswordCriteria } from "@/features/workspace-registration/utils/passwordCriteria";

const INITIAL_VALUES: WorkspaceRegistrationFormValues = {
  workspaceName: "",
  workspaceDescription: "",
  workspaceLanguage: "",
  organizationType: "",
  workspaceEmail: "",
  country: "",
  adminFirstName: "",
  adminLastName: "",
  adminJobTitle: "",
  adminEmail: "",
  adminPassword: "",
  confirmPassword: "",
};

export default function useWorkspaceRegistrationForm() {
  const navigate = useNavigate();

  const form = useZodForm<WorkspaceRegistrationFormValues>({
    schema: workspaceRegistrationSchema,
    initialValues: INITIAL_VALUES,
    onValidSubmit: async (values) => {
      try {
        await registerWorkspaceRequest(buildWorkspaceRegistrationPayload(values));
        navigate(ROUTE_PATHS.login, { state: { registrationSuccess: true } });
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to create the workspace. Please try again."));
      }
    },
  });

  const passwordCriteria = useMemo(
    () => evaluatePasswordCriteria(form.values.adminPassword, form.values.confirmPassword),
    [form.values.adminPassword, form.values.confirmPassword],
  );

  return { ...form, passwordCriteria };
}
