import { Check } from "lucide-react";
import { cn } from "@/shared/utils/cn";
import type { PasswordCriterion } from "@/features/workspace-registration/utils/passwordCriteria";

interface PasswordStrengthMeterProps {
  criteria: PasswordCriterion[];
}

export default function PasswordStrengthMeter({ criteria }: PasswordStrengthMeterProps) {
  const metCount = criteria.filter((criterion) => criterion.met).length;
  const progressPercentage = Math.round((metCount / criteria.length) * 100);

  return (
    <div className="border-border bg-muted/40 rounded-md border p-4">
      <div className="bg-border mb-3 h-1.5 w-full overflow-hidden rounded-full">
        <div
          className="bg-primary h-full rounded-full transition-all duration-300"
          style={{ width: `${progressPercentage}%` }}
        />
      </div>
      <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {criteria.map((criterion) => (
          <li key={criterion.label} className="flex items-center gap-2 text-sm">
            <span
              className={cn(
                "flex size-4 shrink-0 items-center justify-center rounded-full transition-colors",
                criterion.met
                  ? "bg-green-600 text-white dark:bg-green-500"
                  : "bg-border text-transparent",
              )}
            >
              <Check className="size-3" />
            </span>
            <span
              className={cn(
                "transition-colors",
                criterion.met ? "text-foreground" : "text-muted-foreground",
              )}
            >
              {criterion.label}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
