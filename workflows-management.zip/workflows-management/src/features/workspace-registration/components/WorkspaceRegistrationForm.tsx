import { Button } from "@/shared/ui/button";
import { Separator } from "@/shared/ui/separator";
import { Card, CardContent } from "@/shared/ui/card";
import TextField from "@/shared/components/TextField";
import TextareaField from "@/shared/components/TextareaField";
import SelectField from "@/shared/components/SelectField";
import PasswordField from "@/shared/components/PasswordField";
import useWorkspaceRegistrationForm from "@/features/workspace-registration/hooks/useWorkspaceRegistrationForm";
import PasswordStrengthMeter from "@/features/workspace-registration/components/PasswordStrengthMeter";
import { ORGANIZATION_TYPES } from "@/shared/utils/organizationTypes";
import { LANGUAGES } from "@/shared/utils/languages";
import { COUNTRIES } from "@/shared/utils/countries";

export default function WorkspaceRegistrationForm() {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit, passwordCriteria } =
    useWorkspaceRegistrationForm();

  return (
    <Card>
      <CardContent className="pt-6">
        <form className="flex flex-col gap-8" noValidate onSubmit={handleSubmit}>
          <fieldset className="flex flex-col gap-5">
            <legend className="text-muted-foreground mb-1 text-sm font-semibold uppercase">
              Workspace details
            </legend>

            <TextField
              id="workspaceName"
              label="Workspace name"
              placeholder="Acme Operations"
              value={values.workspaceName}
              error={errors.workspaceName}
              required
              onValueChange={getFieldHandler("workspaceName")}
            />

            <TextareaField
              id="workspaceDescription"
              label="Description"
              placeholder="Briefly describe what this workspace manages."
              value={values.workspaceDescription ?? ""}
              error={errors.workspaceDescription}
              onValueChange={getFieldHandler("workspaceDescription")}
            />

            <div className="grid gap-5 sm:grid-cols-2">
              <SelectField
                id="workspaceLanguage"
                label="Language"
                placeholder="Select a language"
                value={values.workspaceLanguage}
                options={LANGUAGES}
                error={errors.workspaceLanguage}
                required
                onValueChange={getFieldHandler("workspaceLanguage")}
              />
              <SelectField
                id="organizationType"
                label="Organization type"
                placeholder="Select a type"
                value={values.organizationType}
                options={ORGANIZATION_TYPES}
                error={errors.organizationType}
                required
                onValueChange={getFieldHandler("organizationType")}
              />
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                id="workspaceEmail"
                label="Workspace email"
                type="email"
                placeholder="team@acme.com"
                value={values.workspaceEmail}
                error={errors.workspaceEmail}
                required
                onValueChange={getFieldHandler("workspaceEmail")}
              />
              <SelectField
                id="country"
                label="Country"
                placeholder="Select a country"
                value={values.country}
                options={COUNTRIES}
                error={errors.country}
                required
                onValueChange={getFieldHandler("country")}
              />
            </div>
          </fieldset>

          <Separator />

          <fieldset className="flex flex-col gap-5">
            <legend className="text-muted-foreground mb-1 text-sm font-semibold uppercase">
              Workspace admin
            </legend>

            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                id="adminFirstName"
                label="First name"
                autoComplete="given-name"
                placeholder="Jane"
                value={values.adminFirstName}
                error={errors.adminFirstName}
                required
                onValueChange={getFieldHandler("adminFirstName")}
              />
              <TextField
                id="adminLastName"
                label="Last name"
                autoComplete="family-name"
                placeholder="Doe"
                value={values.adminLastName}
                error={errors.adminLastName}
                required
                onValueChange={getFieldHandler("adminLastName")}
              />
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                id="adminJobTitle"
                label="Job title"
                autoComplete="organization-title"
                placeholder="Operations Manager"
                value={values.adminJobTitle}
                error={errors.adminJobTitle}
                required
                onValueChange={getFieldHandler("adminJobTitle")}
              />
              <TextField
                id="adminEmail"
                label="Admin email"
                type="email"
                autoComplete="email"
                placeholder="jane@acme.com"
                value={values.adminEmail}
                error={errors.adminEmail}
                required
                onValueChange={getFieldHandler("adminEmail")}
              />
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <PasswordField
                id="adminPassword"
                label="Password"
                autoComplete="new-password"
                placeholder="At least 8 characters"
                value={values.adminPassword}
                error={errors.adminPassword}
                required
                onValueChange={getFieldHandler("adminPassword")}
              />
              <PasswordField
                id="confirmPassword"
                label="Confirm password"
                autoComplete="new-password"
                placeholder="Re-enter your password"
                value={values.confirmPassword}
                error={errors.confirmPassword}
                required
                onValueChange={getFieldHandler("confirmPassword")}
              />
            </div>

            <PasswordStrengthMeter criteria={passwordCriteria} />
          </fieldset>

          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Creating workspace..." : "Create workspace"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
