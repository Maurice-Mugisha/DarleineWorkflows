import { Link } from "react-router-dom";
import Logo from "@/shared/components/Logo";
import ThemeMenu from "@/shared/components/ThemeMenu";
import { ROUTE_PATHS } from "@/routes/routePaths";
import WorkspaceRegistrationForm from "@/features/workspace-registration/components/WorkspaceRegistrationForm";

export default function WorkspaceRegistrationPage() {
  return (
    <div className="flex min-h-svh flex-col">
      <header className="flex items-center justify-between px-4 py-4 sm:px-6">
        <Logo />
        <ThemeMenu />
      </header>
      <main className="flex flex-1 justify-center px-4 py-10">
        <div className="w-full max-w-2xl">
          <div className="mb-8 text-center">
            <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
              Register your workspace
            </h1>
            <p className="text-muted-foreground mt-2 text-sm">
              Set up your workspace and its first administrator. It only takes a minute.
            </p>
          </div>
          <WorkspaceRegistrationForm />
          <p className="text-muted-foreground mt-6 text-center text-sm">
            Already have a workspace?{" "}
            <Link to={ROUTE_PATHS.login} className="text-primary font-medium hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}
