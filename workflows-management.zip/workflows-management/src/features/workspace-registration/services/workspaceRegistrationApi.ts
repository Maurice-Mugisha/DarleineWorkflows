import apiClient from "@/shared/lib/apiClient";
import type { WorkspaceRegistrationPayload } from "@/features/workspace-registration/types/workspaceRegistration";

export default async function registerWorkspaceRequest(
  payload: WorkspaceRegistrationPayload,
): Promise<void> {
  await apiClient.post("/workspace/register_a_workspace", payload);
}
