import { z } from "zod";
import {
  hasLowercase,
  hasMinimumLength,
  hasNumber,
  hasSpecialCharacter,
  hasUppercase,
  passwordsMatch,
} from "@/features/workspace-registration/utils/passwordCriteria";

export const workspaceRegistrationSchema = z
  .object({
    workspaceName: z.string().min(2, "Workspace name must be at least 2 characters."),
    workspaceDescription: z
      .string()
      .optional(),
    workspaceLanguage: z.string().min(1, "Please select a language."),
    organizationType: z.string().min(1, "Please select an organization type."),
    workspaceEmail: z.email("Enter a valid workspace email address."),
    country: z.string().min(1, "Please select a country."),
    adminFirstName: z.string().min(2, "First name must be at least 2 characters."),
    adminLastName: z.string().min(2, "Last name must be at least 2 characters."),
    adminJobTitle: z.string().min(2, "Job title must be at least 2 characters."),
    adminEmail: z.email("Enter a valid admin email address."),
    adminPassword: z
      .string()
      .refine(hasMinimumLength, "Password must be at least 8 characters.")
      .refine(hasUppercase, "Password must contain an uppercase letter.")
      .refine(hasLowercase, "Password must contain a lowercase letter.")
      .refine(hasNumber, "Password must contain a number.")
      .refine(hasSpecialCharacter, "Password must contain a special character."),
    confirmPassword: z.string().min(1, "Please confirm your password."),
  })
  .refine((values) => passwordsMatch(values.adminPassword, values.confirmPassword), {
    message: "Passwords do not match.",
    path: ["confirmPassword"],
  });

export type WorkspaceRegistrationFormValues = z.infer<typeof workspaceRegistrationSchema>;
