import { Link, Navigate, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import CaseForm from "@/features/workflow-cases/components/CaseForm";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { WorkflowCase } from "@/features/workflow-cases/types/workflowCase";

export default function EditCasePage() {
  const location = useLocation();
  const workflowCase =
    (location.state as { workflowCase?: WorkflowCase } | null)?.workflowCase ?? null;

  if (workflowCase === null) {
    return <Navigate to={ROUTE_PATHS.cases} replace />;
  }

  return (
    <DashboardLayout title="Edit case" subtitle="Update this workflow case.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.cases}>
            <ArrowLeft />
            Back to cases
          </Link>
        </Button>
        <CaseForm existingCase={workflowCase} />
      </div>
    </DashboardLayout>
  );
}
