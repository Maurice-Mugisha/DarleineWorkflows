import type { Step } from "@/features/workflows/types/step";
import type { Report } from "@/features/reports/types/report";

export interface ProgressReportEntry {
  step_id: string;
  status: string;
  delay_time: number;
}

export interface WorkflowCase {
  id: string;
  legacy_id: string;
  name: string;
  description: string;
  workflow_id_list?: string[] | null;
  step_list?: Step[] | null;
  report_list?: Report[] | null;
  progress_report_list?: ProgressReportEntry[] | null;
}
