import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import CaseForm from "@/features/workflow-cases/components/CaseForm";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function CreateCasePage() {
  return (
    <DashboardLayout title="Create case" subtitle="Create a new workflow case.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.cases}>
            <ArrowLeft />
            Back to cases
          </Link>
        </Button>
        <CaseForm />
      </div>
    </DashboardLayout>
  );
}
