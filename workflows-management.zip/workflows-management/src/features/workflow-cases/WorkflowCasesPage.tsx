import { Link } from "react-router-dom";
import { Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import WorkflowCasesList from "@/features/workflow-cases/components/WorkflowCasesList";
import useWorkflowCasesPage from "@/features/workflow-cases/hooks/useWorkflowCasesPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function WorkflowCasesPage() {
  const { cases, isLoading } = useWorkflowCasesPage();

  const headerAction = (
    <Button asChild>
      <Link to={ROUTE_PATHS.createCase}>
        <Plus />
        New case
      </Link>
    </Button>
  );

  return (
    <DashboardLayout
      title="Workflow Cases"
      subtitle="Track real-world cases moving through your workflows."
      action={headerAction}
    >
      <WorkflowCasesList cases={cases} isLoading={isLoading} />
    </DashboardLayout>
  );
}
