import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, FileText, MoreVertical, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { Badge } from "@/shared/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/shared/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/shared/ui/tabs";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PageLoader from "@/shared/components/PageLoader";
import { Skeleton } from "@/shared/ui/skeleton";
import ConfirmDialog from "@/shared/components/ConfirmDialog";
import StepExecutionCard from "@/features/workflow-cases/components/StepExecutionCard";
import CaseReportCard from "@/features/workflow-cases/components/CaseReportCard";
import CaseProgressReportCard from "@/features/workflow-cases/components/CaseProgressReportCard";
import CaseReportsEmptyState from "@/features/workflow-cases/components/CaseReportsEmptyState";
import NotFoundPage from "@/features/errors/NotFoundPage";
import useCaseDetailPage from "@/features/workflow-cases/hooks/useCaseDetailPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

function LoadingSteps() {
  return (
    <div className="flex flex-col gap-4">
      {Array.from({ length: 3 }).map((_, index) => (
        <Card key={index}>
          <CardContent>
            <Skeleton className="mb-2 h-5 w-32" />
            <Skeleton className="mb-1 h-4 w-full" />
            <Skeleton className="h-4 w-24" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default function CaseDetailPage() {
  const {
    workflowCase,
    isLoadingCase,
    isNotFound,
    caseSteps,
    roleNameById,
    userNameById,
    stepNameById,
    stepTimeUnitById,
    isLoadingSteps,
    currentActiveIndex,
    isActiveStepInProgress,
    isDeletingWorkflowCase,
    activeStepActionId,
    showDeleteDialog,
    setShowDeleteDialog,
    handleExecuteStep,
    handleMarkStepComplete,
    handleDeleteCase,
    reportList,
    progressReportList,
  } = useCaseDetailPage();

  const [activeTab, setActiveTab] = useState("execution");

  if (isLoadingCase) {
    return (
      <DashboardLayout title="Case details">
        <PageLoader />
      </DashboardLayout>
    );
  }

  if (isNotFound || workflowCase === null) {
    return <NotFoundPage />;
  }

  const editPath = ROUTE_PATHS.editCase.replace(":caseId", workflowCase.id);
  const hasReports = reportList.length > 0;
  const hasProgressReports = progressReportList.length > 0;
  const bothReportTypesExist = hasReports && hasProgressReports;

  return (
    <DashboardLayout title={workflowCase.name} subtitle="Execute this case step by step.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.cases}>
            <ArrowLeft />
            Back to cases
          </Link>
        </Button>

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between gap-4">
              <div>
                <Badge variant="outline" className="font-mono text-xs">
                  {workflowCase.legacy_id}
                </Badge>
                <CardTitle className="mt-2 text-2xl">{workflowCase.name}</CardTitle>
                <CardDescription className="mt-1">{workflowCase.description}</CardDescription>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="shrink-0"
                    aria-label="Case actions"
                    disabled={isDeletingWorkflowCase}
                  >
                    <MoreVertical />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-40">
                  <DropdownMenuItem asChild>
                    <Link to={editPath} state={{ workflowCase }}>
                      <Pencil />
                      Edit
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem variant="destructive" onClick={() => setShowDeleteDialog(true)}>
                    <Trash2 />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </CardHeader>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList>
            <TabsTrigger value="execution">Execution</TabsTrigger>
            <TabsTrigger value="reports">
              <FileText className="size-4" />
              Reports
            </TabsTrigger>
          </TabsList>

          <TabsContent value="execution" className="mt-6">
            {isLoadingSteps ? (
              <LoadingSteps />
            ) : caseSteps.length === 0 ? (
              <p className="text-muted-foreground py-8 text-center text-sm">
                This case has no linked workflows with steps. Edit the case to add workflows.
              </p>
            ) : (
              <div className="flex flex-col gap-4">
                {caseSteps.map((caseStep, index) => {
                  let status: "completed" | "in-progress" | "ready" | "pending";
                  if (index === currentActiveIndex) {
                    status = isActiveStepInProgress ? "in-progress" : "ready";
                  } else if (index < currentActiveIndex) {
                    status = "completed";
                  } else {
                    status = "pending";
                  }

                  return (
                    <StepExecutionCard
                      key={caseStep.step.id}
                      caseStep={caseStep}
                      caseId={workflowCase.id}
                      roleNameById={roleNameById}
                      status={status}
                      isBusy={activeStepActionId === caseStep.step.id}
                      onExecute={handleExecuteStep}
                      onMarkComplete={handleMarkStepComplete}
                    />
                  );
                })}
              </div>
            )}

            <div className="text-muted-foreground mt-6 flex items-center gap-2 text-xs">
              <span className="flex items-center gap-1">
                <span className="size-2.5 rounded-full bg-green-600" /> Completed
              </span>
              <span className="flex items-center gap-1">
                <span className="size-2.5 rounded-full bg-amber-500" /> In Progress
              </span>
              <span className="flex items-center gap-1">
                <span className="bg-primary/15 size-2.5 rounded-full" /> Ready
              </span>
              <span className="flex items-center gap-1">
                <span className="bg-muted size-2.5 rounded-full" /> Pending
              </span>
            </div>
          </TabsContent>

          <TabsContent value="reports" className="mt-6">
            {!hasReports && !hasProgressReports ? (
              <CaseReportsEmptyState onGoToExecution={() => setActiveTab("execution")} />
            ) : (
              <div className="flex flex-col gap-6">
                {hasReports ? (
                  <div>
                    {bothReportTypesExist ? (
                      <h3 className="mb-3 text-sm font-medium">Reports</h3>
                    ) : null}
                    <div className="flex flex-col gap-3">
                      {reportList.map((report, index) => (
                        <CaseReportCard
                          key={report.id ?? `report-${index}`}
                          report={report}
                          userNameById={userNameById}
                        />
                      ))}
                    </div>
                  </div>
                ) : null}
                {hasProgressReports ? (
                  <div>
                    {bothReportTypesExist ? (
                      <h3 className="mb-3 text-sm font-medium">Progress Reports</h3>
                    ) : null}
                    <div className="flex flex-col gap-3">
                      {progressReportList.map((entry, index) => (
                        <CaseProgressReportCard
                          key={entry.step_id ?? `progress-${index}`}
                          entry={entry}
                          stepNameById={stepNameById}
                          stepTimeUnitById={stepTimeUnitById}
                        />
                      ))}
                    </div>
                  </div>
                ) : null}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onConfirm={handleDeleteCase}
        onCancel={() => setShowDeleteDialog(false)}
        title="Delete workflow case"
        message={`Are you sure you want to delete "${workflowCase.name}"? This action cannot be undone.`}
        isLoading={isDeletingWorkflowCase}
      />
    </DashboardLayout>
  );
}
