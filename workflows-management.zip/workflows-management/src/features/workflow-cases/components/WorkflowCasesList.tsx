import { Skeleton } from "@/shared/ui/skeleton";
import WorkflowCaseCard from "@/features/workflow-cases/components/WorkflowCaseCard";
import CasesEmptyState from "@/features/workflow-cases/components/CasesEmptyState";
import type { WorkflowCase } from "@/features/workflow-cases/types/workflowCase";

interface WorkflowCasesListProps {
  cases: WorkflowCase[];
  isLoading: boolean;
}

function LoadingCards() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 3 }).map((_, index) => (
        <div key={index} className="border-border rounded-xl border p-6">
          <Skeleton className="mb-3 h-5 w-20" />
          <Skeleton className="mb-2 h-6 w-40" />
          <Skeleton className="mb-4 h-4 w-full" />
          <Skeleton className="h-4 w-24" />
        </div>
      ))}
    </div>
  );
}

export default function WorkflowCasesList({ cases, isLoading }: WorkflowCasesListProps) {
  if (isLoading) {
    return <LoadingCards />;
  }

  if (cases.length === 0) {
    return <CasesEmptyState />;
  }

  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {cases.map((workflowCase) => (
        <WorkflowCaseCard key={workflowCase.id} workflowCase={workflowCase} />
      ))}
    </div>
  );
}
