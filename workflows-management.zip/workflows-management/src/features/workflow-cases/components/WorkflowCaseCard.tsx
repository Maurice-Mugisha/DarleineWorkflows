import { Link } from "react-router-dom";
import { Workflow } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/shared/ui/card";
import { Badge } from "@/shared/ui/badge";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { WorkflowCase } from "@/features/workflow-cases/types/workflowCase";

interface WorkflowCaseCardProps {
  workflowCase: WorkflowCase;
}

export default function WorkflowCaseCard({ workflowCase }: WorkflowCaseCardProps) {
  const workflowCount = workflowCase.workflow_id_list?.length ?? 0;
  const detailPath = ROUTE_PATHS.caseDetail.replace(":caseId", workflowCase.id);

  return (
    <Link to={detailPath} state={{ workflowCase }} className="block">
      <Card className="h-full transition-shadow hover:shadow-md">
        <CardHeader>
          <Badge variant="outline" className="w-fit font-mono text-xs">
            {workflowCase.legacy_id}
          </Badge>
          <CardTitle className="mt-2">{workflowCase.name}</CardTitle>
          <CardDescription>{workflowCase.description}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground flex items-center gap-2 text-sm">
            <Workflow className="size-4" />
            {workflowCount} {workflowCount === 1 ? "workflow" : "workflows"}
          </p>
        </CardContent>
      </Card>
    </Link>
  );
}
