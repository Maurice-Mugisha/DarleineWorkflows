import { Link } from "react-router-dom";
import { Eye, FileText } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { Badge } from "@/shared/ui/badge";
import { Card, CardContent } from "@/shared/ui/card";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Report } from "@/features/reports/types/report";

interface CaseReportCardProps {
  report: Report;
  userNameById: Record<string, string>;
}

export default function CaseReportCard({ report, userNameById }: CaseReportCardProps) {
  const userName = userNameById[report.user_id] ?? "Unknown user";
  const userInitial = userName.charAt(0).toUpperCase();
  const rawText = report.report_text ?? "";
  const textPreview =
    rawText.length > 250 ? rawText.slice(0, 250) + "..." : rawText;

  return (
    <Card className="hover:shadow-sm transition-shadow">
      <CardContent>
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3 min-w-0 flex-1">
            <span className="bg-primary/10 text-primary mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold">
              {userInitial}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium">{userName}</span>
                <Badge variant="secondary" className="text-[0.65rem] font-normal">
                  <FileText className="mr-1 size-2.5" />
                  Report
                </Badge>
              </div>
              <p className="text-muted-foreground mt-1.5 text-sm leading-relaxed">
                {textPreview}
              </p>
              {report.optional_document_url ? (
                <a
                  href={report.optional_document_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary mt-2 inline-flex items-center gap-1 text-xs font-medium hover:underline"
                >
                  <FileText className="size-3" />
                  View attached document
                </a>
              ) : null}
            </div>
          </div>
          <Button variant="ghost" size="icon" className="size-8 shrink-0" aria-label="View report" asChild>
            <Link
              to={ROUTE_PATHS.reportDetail.replace(":reportId", report.id ?? "")}
              state={{ report, userName }}
            >
              <Eye className="size-4" />
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
