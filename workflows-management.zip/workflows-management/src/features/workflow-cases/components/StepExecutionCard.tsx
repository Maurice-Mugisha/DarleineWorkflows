import { Link } from "react-router-dom";
import { Check, Circle, CircleDot, FileText, MoreHorizontal, Play } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import { Button } from "@/shared/ui/button";
import { Badge } from "@/shared/ui/badge";
import { Card, CardContent, CardDescription, CardTitle } from "@/shared/ui/card";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { CaseStepInfo } from "@/features/workflow-cases/hooks/useCaseDetailPage";

interface StepExecutionCardProps {
  caseStep: CaseStepInfo;
  caseId: string;
  roleNameById: Record<string, string>;
  status: "completed" | "in-progress" | "ready" | "pending";
  isBusy: boolean;
  onExecute: (stepId: string) => void;
  onMarkComplete: (stepId: string) => void;
}

function StepStatusIcon({ status }: { status: "completed" | "in-progress" | "ready" | "pending" }) {
  if (status === "completed") {
    return (
      <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-green-600 text-white">
        <Check className="size-4" />
      </span>
    );
  }
  if (status === "in-progress") {
    return (
      <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-500/15 text-amber-600 dark:text-amber-400">
        <CircleDot className="size-4" />
      </span>
    );
  }
  if (status === "ready") {
    return (
      <span className="bg-primary/15 text-primary flex size-7 shrink-0 items-center justify-center rounded-full">
        <CircleDot className="size-4" />
      </span>
    );
  }
  return (
    <span className="bg-muted text-muted-foreground flex size-7 shrink-0 items-center justify-center rounded-full">
      <Circle className="size-4" />
    </span>
  );
}

export default function StepExecutionCard({
  caseStep,
  caseId,
  roleNameById,
  status,
  isBusy,
  onExecute,
  onMarkComplete,
}: StepExecutionCardProps) {
  const { step, workflowName } = caseStep;
  const percentageColor = step.percentage >= step.warning_threshold ? "bg-primary" : "bg-amber-500";

  const reportUrl = `${ROUTE_PATHS.createReport.replace(":caseId", caseId)}?stepId=${step.id}`;

  const statusLabel = (() => {
    if (status === "completed") return "Completed";
    if (status === "in-progress") return "In Progress";
    if (status === "ready") return "Ready";
    return "Pending";
  })();

  const statusBadgeClass = (() => {
    if (status === "completed") return "bg-green-600 text-white";
    if (status === "in-progress") return "bg-amber-500/15 text-amber-600 dark:text-amber-400";
    if (status === "ready") return "bg-primary/15 text-primary";
    return "bg-muted text-muted-foreground";
  })();

  const cardClasses = (() => {
    if (status === "completed") return "border-l-4 border-l-green-600";
    if (status === "in-progress") return "border-l-4 border-l-amber-500";
    if (status === "ready") return "border-l-4 border-l-primary";
    return undefined;
  })();

  return (
    <Card className={cardClasses}>
      <CardContent>
        <div className="flex items-start gap-3">
          <StepStatusIcon status={status} />

          <div className="min-w-0 flex-1">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-muted-foreground text-xs font-medium">
                    Step {step.step_number}
                  </span>
                  <Badge variant="outline" className="text-xs">
                    {workflowName}
                  </Badge>
                  <Badge className={`text-xs ${statusBadgeClass}`}>
                    {statusLabel}
                  </Badge>
                </div>
                <CardTitle className="mt-1 text-base">{step.name}</CardTitle>
                {step.description ? (
                  <CardDescription className="mt-1">{step.description}</CardDescription>
                ) : null}
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="size-8 shrink-0" disabled={isBusy}>
                    <MoreHorizontal className="size-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    onClick={() => onExecute(step.id)}
                    disabled={status !== "ready" || isBusy}
                  >
                    <Play />
                    {isBusy ? "Starting..." : "Execute"}
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => onMarkComplete(step.id)}
                    disabled={status !== "in-progress" || isBusy}
                  >
                    <Check />
                    {isBusy ? "Completing..." : "Mark as Complete"}
                  </DropdownMenuItem>
                  {status === "completed" ? (
                    <DropdownMenuItem asChild>
                      <Link to={reportUrl}>
                        <FileText />
                        Record a Report
                      </Link>
                    </DropdownMenuItem>
                  ) : (
                    <DropdownMenuItem disabled>
                      <FileText />
                      Record a Report
                    </DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="mt-4 flex flex-wrap items-center gap-3">
              <div className="min-w-30">
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Progress</span>
                  <span className="font-medium">{step.percentage}%</span>
                </div>
                <div className="bg-muted h-1.5 w-full overflow-hidden rounded-full">
                  <div
                    className={`h-full rounded-full ${percentageColor}`}
                    style={{ width: `${Math.min(step.percentage, 100)}%` }}
                  />
                </div>
              </div>
              <Badge variant="outline" className="font-mono text-xs">
                {step.code}
              </Badge>
              {step.percentage < step.warning_threshold ? (
                <span className="text-xs font-medium text-amber-600 dark:text-amber-400">
                  Below threshold ({step.warning_threshold}%)
                </span>
              ) : null}
            </div>

            {step.role_id_list && step.role_id_list.length > 0 ? (
              <div className="mt-3 flex flex-wrap items-center gap-1.5">
                <span className="text-muted-foreground text-xs">Roles:</span>
                {step.role_id_list.map((roleId) => (
                  <Badge key={roleId} variant="outline">
                    {roleNameById[roleId] ?? "Unknown role"}
                  </Badge>
                ))}
              </div>
            ) : null}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
