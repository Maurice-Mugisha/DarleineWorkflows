import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/shared/ui/card";
import { Separator } from "@/shared/ui/separator";
import { Checkbox } from "@/shared/ui/checkbox";
import { Label } from "@/shared/ui/label";
import TextField from "@/shared/components/TextField";
import TextareaField from "@/shared/components/TextareaField";
import useCaseForm from "@/features/workflow-cases/hooks/useCaseForm";
import WorkflowCheckboxGroup from "@/features/workflow-cases/components/WorkflowCheckboxGroup";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { WorkflowCase } from "@/features/workflow-cases/types/workflowCase";

interface CaseFormProps {
  existingCase?: WorkflowCase;
}

export default function CaseForm({ existingCase }: CaseFormProps) {
  const {
    values,
    errors,
    isSubmitting,
    setFieldValue,
    getFieldHandler,
    handleSubmit,
    workflows,
    isLoadingWorkflows,
    showLegacyId,
    handleToggleLegacyId,
  } = useCaseForm({ existingCase });

  const isEditing = existingCase !== undefined;

  const toggleWorkflow = (workflowId: string) => {
    const nextWorkflowIds = values.workflowIds.includes(workflowId)
      ? values.workflowIds.filter((id) => id !== workflowId)
      : [...values.workflowIds, workflowId];
    setFieldValue("workflowIds", nextWorkflowIds);
  };

  return (
    <form noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Case details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-5">
            <TextField
              id="name"
              label="Case name"
              placeholder="Q3 onboarding batch"
              value={values.name}
              error={errors.name}
              required
              onValueChange={getFieldHandler("name")}
            />

            <TextareaField
              id="description"
              label="Description"
              placeholder="What does this case cover?"
              value={values.description ?? ""}
              error={errors.description}
              onValueChange={getFieldHandler("description")}
            />

            <div className="flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <Checkbox
                  id="hasLegacyId"
                  checked={showLegacyId}
                  onCheckedChange={(checked) => handleToggleLegacyId(checked === true)}
                  className="mt-0.5"
                />
                <Label
                  htmlFor="hasLegacyId"
                  className="flex flex-col items-start gap-0.5 font-normal"
                >
                  <span className="font-medium">This case has a legacy ID</span>
                  <span className="text-muted-foreground text-xs">
                    An identifier from a previous or external system.
                  </span>
                </Label>
              </div>

              {showLegacyId ? (
                <TextField
                  id="legacyId"
                  label="Legacy ID"
                  placeholder="e.g. CASE-2023-0142"
                  value={values.legacyId}
                  error={errors.legacyId}
                  onValueChange={getFieldHandler("legacyId")}
                />
              ) : null}
            </div>

            <Separator />

            <WorkflowCheckboxGroup
              workflows={workflows}
              selectedWorkflowIds={values.workflowIds}
              isLoading={isLoadingWorkflows}
              onToggle={toggleWorkflow}
            />
          </div>
        </CardContent>
        <CardFooter className="gap-3">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : isEditing ? "Save changes" : "Create case"}
          </Button>
          <Button type="button" variant="ghost" asChild>
            <Link to={ROUTE_PATHS.cases}>Cancel</Link>
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
