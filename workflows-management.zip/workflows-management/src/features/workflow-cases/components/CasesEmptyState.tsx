import { Link } from "react-router-dom";
import { FolderKanban, Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { ROUTE_PATHS } from "@/routes/routePaths";

const CASE_BENEFITS = [
  {
    text: "Track a real-world instance running through your workflows.",
    accent: "border-l-primary bg-primary/5",
  },
  {
    text: "Link a case to the workflows it needs to pass through.",
    accent: "border-l-amber-500 bg-amber-50 dark:border-l-amber-400 dark:bg-amber-950/30",
  },
  {
    text: "Keep external references with a legacy ID for traceability.",
    accent: "border-l-emerald-500 bg-emerald-50 dark:border-l-emerald-400 dark:bg-emerald-950/30",
  },
];

export default function CasesEmptyState() {
  return (
    <div className="border-border flex flex-col items-center rounded-xl border border-dashed py-16 text-center">
      <span className="bg-primary/10 text-primary mb-6 flex size-20 items-center justify-center rounded-2xl">
        <FolderKanban className="size-10" />
      </span>

      <h2 className="text-2xl font-semibold tracking-tight">No workflow cases yet</h2>
      <p className="text-muted-foreground mt-2 max-w-md">
        Create a case to track something moving through one or more of your workflows.
      </p>

      <ul className="mt-8 flex w-full max-w-lg flex-col gap-3">
        {CASE_BENEFITS.map((benefit) => (
          <li
            key={benefit.text}
            className={`border-border rounded-lg border-l-4 px-4 py-3 text-left text-sm ${benefit.accent}`}
          >
            {benefit.text}
          </li>
        ))}
      </ul>

      <Button size="lg" className="mt-8" asChild>
        <Link to={ROUTE_PATHS.createCase}>
          <Plus />
          Create your first case
        </Link>
      </Button>
    </div>
  );
}
