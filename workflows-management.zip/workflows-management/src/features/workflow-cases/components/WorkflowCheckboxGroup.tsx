import { Checkbox } from "@/shared/ui/checkbox";
import { Label } from "@/shared/ui/label";
import type { Workflow } from "@/features/workflows/types/workflow";

interface WorkflowCheckboxGroupProps {
  workflows: Workflow[];
  selectedWorkflowIds: string[];
  isLoading: boolean;
  onToggle: (workflowId: string) => void;
}

export default function WorkflowCheckboxGroup({
  workflows,
  selectedWorkflowIds,
  isLoading,
  onToggle,
}: WorkflowCheckboxGroupProps) {
  return (
    <div className="flex flex-col gap-2">
      <Label>Workflows</Label>
      <p className="text-muted-foreground text-sm">
        Choose which workflows this case runs through. You can pick as many as you need.
      </p>

      {isLoading ? (
        <p className="text-muted-foreground py-2 text-sm">Loading workflows...</p>
      ) : workflows.length === 0 ? (
        <p className="text-muted-foreground py-2 text-sm">No workflows available yet.</p>
      ) : (
        <div className="flex flex-col gap-3 pt-1">
          {workflows.map((workflow) => {
            const checkboxId = `workflow-${workflow.id}`;
            const isSelected = selectedWorkflowIds.includes(workflow.id);

            return (
              <div key={workflow.id} className="flex items-start gap-3">
                <Checkbox
                  id={checkboxId}
                  checked={isSelected}
                  onCheckedChange={() => onToggle(workflow.id)}
                  className="mt-0.5"
                />
                <Label
                  htmlFor={checkboxId}
                  className="flex flex-col items-start gap-0.5 font-normal"
                >
                  <span className="font-medium">{workflow.name}</span>
                  <span className="text-muted-foreground text-xs">{workflow.description}</span>
                </Label>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
