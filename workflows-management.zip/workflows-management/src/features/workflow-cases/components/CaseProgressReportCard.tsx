import { Badge } from "@/shared/ui/badge";
import { Card, CardContent } from "@/shared/ui/card";
import { CheckCircle2, AlertTriangle, List } from "lucide-react";
import type { ProgressReportEntry } from "@/features/workflow-cases/types/workflowCase";

interface CaseProgressReportCardProps {
  entry: ProgressReportEntry;
  stepNameById: Record<string, string>;
  stepTimeUnitById: Record<string, string>;
}

export default function CaseProgressReportCard({
  entry,
  stepNameById,
  stepTimeUnitById,
}: CaseProgressReportCardProps) {
  const stepName = stepNameById[entry.step_id] ?? "Unknown step";
  const timeUnit = stepTimeUnitById[entry.step_id] ?? "h";
  const isDelayed = entry.delay_time > 0;

  const statusClass = (() => {
    if (entry.status === "Complete") return "bg-green-600 text-white";
    if (entry.status === "Pending") return "bg-amber-500/15 text-amber-600 dark:text-amber-400";
    if (entry.status === "In Progress") return "bg-primary/15 text-primary";
    return "bg-muted text-muted-foreground";
  })();

  return (
    <Card className="hover:shadow-sm transition-shadow">
      <CardContent>
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3 min-w-0 flex-1">
            <span className={`mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-full text-xs ${
              isDelayed
                ? "bg-destructive/10 text-destructive"
                : entry.status === "Complete"
                  ? "bg-green-600/10 text-green-600"
                  : "bg-primary/10 text-primary"
            }`}>
              <List className="size-4" />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-medium">{stepName}</p>
              <div className="mt-1.5 flex flex-wrap items-center gap-2">
                <Badge className={`text-xs ${statusClass}`}>{entry.status}</Badge>
                {isDelayed ? (
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-destructive">
                    <AlertTriangle className="size-3.5" />
                    Delayed by {entry.delay_time}{timeUnit}
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-green-600 dark:text-green-400">
                    <CheckCircle2 className="size-3.5" />
                    On schedule
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
