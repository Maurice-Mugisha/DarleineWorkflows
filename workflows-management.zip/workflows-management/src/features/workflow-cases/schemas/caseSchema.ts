import { z } from "zod";

export const caseSchema = z.object({
  name: z.string().min(2, "Case name must be at least 2 characters."),
  legacyId: z.string(),
  description: z.string().optional(),
  workflowIds: z.array(z.string()),
});

export type CaseFormValues = z.infer<typeof caseSchema>;
