import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import {
  fetchAllWorkflowCasesRequest,
  deleteWorkflowCaseRequest,
} from "@/features/workflow-cases/services/workflowCaseApi";
import type { WorkflowCase } from "@/features/workflow-cases/types/workflowCase";

export default function useWorkflowCasesPage() {
  const [cases, setCases] = useState<WorkflowCase[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useNavigationSuccessToast("caseCreated", "Workflow case created successfully.");
  useNavigationSuccessToast("caseUpdated", "Workflow case updated successfully.");

  useEffect(() => {
    let cancelled = false;

    async function fetchCases() {
      try {
        const data = await fetchAllWorkflowCasesRequest();
        if (!cancelled) {
          setCases(data);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load workflow cases."));
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    fetchCases();

    return () => {
      cancelled = true;
    };
  }, []);

  const handleDeleteCase = async (caseId: string) => {
    try {
      await deleteWorkflowCaseRequest(caseId);
      setCases((previousCases) =>
        previousCases.filter((workflowCase) => workflowCase.id !== caseId),
      );
      toast.success("Workflow case deleted.");
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to delete the workflow case."));
    }
  };

  return { cases, isLoading, handleDeleteCase };
}
