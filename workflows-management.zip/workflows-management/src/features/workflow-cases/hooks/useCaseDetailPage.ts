import { useCallback, useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";
import useResolvedEntity from "@/shared/hooks/useResolvedEntity";
import {
  deleteWorkflowCaseRequest,
  fetchCaseByIdRequest,
  updateCaseStepStatusRequest,
} from "@/features/workflow-cases/services/workflowCaseApi";
import { fetchWorkflowByIdRequest } from "@/features/workflows/services/workflowApi";
import { fetchWorkflowStepsRequest } from "@/features/workflows/services/stepApi";
import { fetchAllRolesRequest } from "@/features/roles/services/roleApi";
import { fetchWorkspaceUsersRequest } from "@/features/users/services/userApi";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { WorkflowCase } from "@/features/workflow-cases/types/workflowCase";
import type { Step } from "@/features/workflows/types/step";
import type { Workflow } from "@/features/workflows/types/workflow";

interface CaseStepInfo {
  step: Step;
  workflowName: string;
}

export type { CaseStepInfo };

function isStepCompleted(step: Step): boolean {
  return step.status === "Completed" || step.workflow_case_step_status === "Completed";
}

function isStepInProgress(step: Step): boolean {
  return step.status === "In Progress" || step.workflow_case_step_status === "In Progress";
}

export default function useCaseDetailPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { caseId } = useParams<{ caseId: string }>();
  const stateEntity =
    (location.state as { workflowCase?: WorkflowCase } | null)?.workflowCase ?? null;

  const {
    entity: workflowCase,
    isLoading: isLoadingCase,
    isNotFound,
  } = useResolvedEntity<WorkflowCase>({
    stateEntity,
    id: caseId,
    fetchById: fetchCaseByIdRequest,
  });

  const [caseSteps, setCaseSteps] = useState<CaseStepInfo[]>([]);
  const [roleNameById, setRoleNameById] = useState<Record<string, string>>({});
  const [userNameById, setUserNameById] = useState<Record<string, string>>({});
  const [isLoadingSteps, setIsLoadingSteps] = useState(true);
  const [isDeletingWorkflowCase, setIsDeletingWorkflowCase] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [activeStepActionId, setActiveStepActionId] = useState<string | null>(null);

  useNavigationSuccessToast("reportCreated", "Report created successfully.");

  const caseIdentifier = workflowCase?.id;
  const workflowIds = useMemo(
    () => workflowCase?.workflow_id_list ?? [],
    [workflowCase?.workflow_id_list],
  );

  useEffect(() => {
    if (workflowCase === null || workflowIds.length === 0) {
      setIsLoadingSteps(false);
      return;
    }

    let cancelled = false;

    async function fetchAllSteps() {
      try {
        const [rolesData] = await Promise.allSettled([fetchAllRolesRequest()]);

        if (!cancelled && rolesData.status === "fulfilled") {
          const lookup: Record<string, string> = {};
          for (const role of rolesData.value) {
            lookup[role.id] = role.name;
          }
          setRoleNameById(lookup);
        }

        try {
          const users = await fetchWorkspaceUsersRequest();
          if (!cancelled) {
            const userLookup: Record<string, string> = {};
            for (const u of users) {
              userLookup[u.id] = `${u.first_name} ${u.last_name}`;
            }
            setUserNameById(userLookup);
          }
        } catch {
          // User names are non-critical; falls back to "Unknown user".
        }

        const workflows: Workflow[] = [];
        for (const workflowId of workflowIds) {
          const workflow = await fetchWorkflowByIdRequest(workflowId);
          if (!cancelled) {
            workflows.push(workflow);
          }
        }

        const allCaseSteps: CaseStepInfo[] = [];
        for (const workflow of workflows) {
          const steps = await fetchWorkflowStepsRequest(workflow.id);
          if (!cancelled) {
            const sortedSteps = [...steps].sort((a, b) => a.step_number - b.step_number);
            for (const step of sortedSteps) {
              const existingStep = workflowCase?.step_list?.find(
                (existing) => existing.id === step.id,
              );
              allCaseSteps.push({
                step: existingStep ?? step,
                workflowName: workflow.name,
              });
            }
          }
        }

        if (!cancelled) {
          setCaseSteps(allCaseSteps);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load the case steps."));
        }
      } finally {
        if (!cancelled) {
          setIsLoadingSteps(false);
        }
      }
    }

    fetchAllSteps();

    return () => {
      cancelled = true;
    };
  }, [caseIdentifier, workflowCase, workflowIds]);

  const stepNameById = useMemo(() => {
    const lookup: Record<string, string> = {};
    for (const cs of caseSteps) {
      lookup[cs.step.id] = cs.step.name;
    }
    return lookup;
  }, [caseSteps]);

  const stepTimeUnitById = useMemo(() => {
    const lookup: Record<string, string> = {};
    for (const cs of caseSteps) {
      const processTime = cs.step.time_list?.find(
        (t) => t.time_unit_category === "Process step time",
      );
      if (processTime) {
        lookup[cs.step.id] = processTime.time_unit;
      }
    }
    return lookup;
  }, [caseSteps]);

  const completedStepIndices = useMemo(() => {
    return caseSteps
      .map((casStep, index) => (isStepCompleted(casStep.step) ? index : -1))
      .filter((index) => index !== -1);
  }, [caseSteps]);

  const lastCompletedIndex =
    completedStepIndices.length > 0 ? Math.max(...completedStepIndices) : -1;
  const currentActiveIndex = lastCompletedIndex + 1;

  const isActiveStepInProgress =
    currentActiveIndex < caseSteps.length &&
    isStepInProgress(caseSteps[currentActiveIndex].step);

  const handleExecuteStep = useCallback(
    async (stepId: string) => {
      if (workflowCase === null) return;

      setActiveStepActionId(stepId);
      try {
        await updateCaseStepStatusRequest(workflowCase.id, stepId, "In Progress");

        setCaseSteps((prev) =>
          prev.map((casStep) => ({
            ...casStep,
            step:
              casStep.step.id === stepId
                ? { ...casStep.step, status: "In Progress" }
                : casStep.step,
          })),
        );
        toast.success("Step is now in progress.");
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to start the step."));
      } finally {
        setActiveStepActionId(null);
      }
    },
    [workflowCase],
  );

  const handleMarkStepComplete = useCallback(
    async (stepId: string) => {
      if (workflowCase === null) return;

      setActiveStepActionId(stepId);
      try {
        await updateCaseStepStatusRequest(workflowCase.id, stepId, "Completed");

        setCaseSteps((prev) =>
          prev.map((casStep) => ({
            ...casStep,
            step:
              casStep.step.id === stepId ? { ...casStep.step, status: "Completed" } : casStep.step,
          })),
        );
        toast.success("Step marked as complete.");
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to complete the step."));
      } finally {
        setActiveStepActionId(null);
      }
    },
    [workflowCase],
  );

  const handleDeleteCase = async () => {
    if (workflowCase === null) return;
    setIsDeletingWorkflowCase(true);
    try {
      await deleteWorkflowCaseRequest(workflowCase.id);
      toast.success("Workflow case deleted.");
      navigate(ROUTE_PATHS.cases, { replace: true });
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to delete the case."));
    } finally {
      setIsDeletingWorkflowCase(false);
      setShowDeleteDialog(false);
    }
  };

  return {
    workflowCase,
    isLoadingCase,
    isNotFound,
    caseSteps,
    roleNameById,
    userNameById,
    stepNameById,
    stepTimeUnitById,
    isLoadingSteps,
    currentActiveIndex,
    isActiveStepInProgress,
    isDeletingWorkflowCase,
    activeStepActionId,
    showDeleteDialog,
    setShowDeleteDialog,
    handleExecuteStep,
    handleMarkStepComplete,
    handleDeleteCase,
    reportList: workflowCase?.report_list ?? [],
    progressReportList: workflowCase?.progress_report_list ?? [],
  };
}
