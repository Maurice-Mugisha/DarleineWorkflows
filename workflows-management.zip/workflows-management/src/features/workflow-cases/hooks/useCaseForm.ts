import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";
import { caseSchema, type CaseFormValues } from "@/features/workflow-cases/schemas/caseSchema";
import buildCasePayload from "@/features/workflow-cases/utils/buildCasePayload";
import {
  createWorkflowCaseRequest,
  updateWorkflowCaseRequest,
} from "@/features/workflow-cases/services/workflowCaseApi";
import { fetchWorkspaceWorkflowsRequest } from "@/features/workflows/services/workflowApi";
import type { Workflow } from "@/features/workflows/types/workflow";
import type { WorkflowCase } from "@/features/workflow-cases/types/workflowCase";

interface UseCaseFormOptions {
  existingCase?: WorkflowCase;
}

function buildInitialValues(existingCase?: WorkflowCase): CaseFormValues {
  return {
    name: existingCase?.name ?? "",
    legacyId: existingCase?.legacy_id ?? "",
    description: existingCase?.description ?? "",
    workflowIds: existingCase?.workflow_id_list ?? [],
  };
}

export default function useCaseForm({ existingCase }: UseCaseFormOptions) {
  const navigate = useNavigate();
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [isLoadingWorkflows, setIsLoadingWorkflows] = useState(true);
  const [showLegacyId, setShowLegacyId] = useState(Boolean(existingCase?.legacy_id));

  useEffect(() => {
    let cancelled = false;

    fetchWorkspaceWorkflowsRequest()
      .then((data) => {
        if (!cancelled) {
          setWorkflows(data);
        }
      })
      .catch(() => {
        if (!cancelled) {
          toast.error("Unable to load workflows.");
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoadingWorkflows(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const form = useZodForm<CaseFormValues>({
    schema: caseSchema,
    initialValues: buildInitialValues(existingCase),
    onValidSubmit: async (values) => {
      try {
        if (existingCase) {
          await updateWorkflowCaseRequest(buildCasePayload(values, existingCase.id));
          navigate(ROUTE_PATHS.cases, { state: { caseUpdated: true } });
        } else {
          await createWorkflowCaseRequest(buildCasePayload(values));
          navigate(ROUTE_PATHS.cases, { state: { caseCreated: true } });
        }
      } catch (error) {
        toast.error(
          getApiErrorMessage(error, "Unable to save the workflow case. Please try again."),
        );
      }
    },
  });

  const handleToggleLegacyId = (checked: boolean) => {
    setShowLegacyId(checked);
    if (!checked) {
      form.setFieldValue("legacyId", "");
    }
  };

  return { ...form, workflows, isLoadingWorkflows, showLegacyId, handleToggleLegacyId };
}
