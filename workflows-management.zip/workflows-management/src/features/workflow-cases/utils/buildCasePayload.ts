import type { CaseFormValues } from "@/features/workflow-cases/schemas/caseSchema";
import type { WorkflowCase } from "@/features/workflow-cases/types/workflowCase";

export default function buildCasePayload(values: CaseFormValues, id?: string): WorkflowCase {
  return {
    id: id ?? crypto.randomUUID(),
    legacy_id: values.legacyId.trim(),
    name: values.name.trim(),
    description: values.description?.trim() ?? "",
    workflow_id_list: values.workflowIds,
    step_list: null,
  };
}
