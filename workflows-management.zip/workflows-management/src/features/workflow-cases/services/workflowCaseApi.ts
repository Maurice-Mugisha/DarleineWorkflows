import apiClient from "@/shared/lib/apiClient";
import type { WorkflowCase } from "@/features/workflow-cases/types/workflowCase";

export async function fetchAllWorkflowCasesRequest(): Promise<WorkflowCase[]> {
  const response = await apiClient.get<WorkflowCase[]>(
    "/workflow_case/retrieve_all_workflow_cases",
  );
  return response.data;
}

export async function fetchCaseByIdRequest(caseId: string): Promise<WorkflowCase> {
  const response = await apiClient.get<WorkflowCase>(
    `/workflow_case/retrieve_a_workflow_case/${caseId}`,
  );
  return response.data;
}

export async function createWorkflowCaseRequest(payload: WorkflowCase): Promise<void> {
  await apiClient.post("/workflow_case/register_a_workflow_case", payload);
}

export async function updateWorkflowCaseRequest(payload: WorkflowCase): Promise<void> {
  await apiClient.post("/workflow_case/update_a_workflow_case", payload);
}

export async function deleteWorkflowCaseRequest(workflowCaseId: string): Promise<void> {
  await apiClient.delete("/workflow_case/delete_a_workflow_case", {
    params: { workflow_case_id: workflowCaseId },
  });
}

export async function updateCaseStepStatusRequest(
  workflowCaseId: string,
  stepId: string,
  status: string,
): Promise<WorkflowCase> {
  const response = await apiClient.post<WorkflowCase>(
    "/workflow_case/update_a_workflow_case_step_status",
    { workflow_case_id: workflowCaseId, step_id: stepId, status },
  );
  return response.data;
}
