import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/shared/ui/card";
import TextField from "@/shared/components/TextField";
import TextareaField from "@/shared/components/TextareaField";
import SelectField from "@/shared/components/SelectField";
import useWorkspaceSettingsForm from "@/features/workspace-settings/hooks/useWorkspaceSettingsForm";
import { LANGUAGES } from "@/shared/utils/languages";
import { ORGANIZATION_TYPES } from "@/shared/utils/organizationTypes";
import { COUNTRIES } from "@/shared/utils/countries";
import type { Workspace } from "@/features/workspace-settings/types/workspace";

interface WorkspaceSettingsFormProps {
  workspace: Workspace;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function WorkspaceSettingsForm({
  workspace,
  onSuccess,
  onCancel,
}: WorkspaceSettingsFormProps) {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit } = useWorkspaceSettingsForm({
    workspace,
    onSuccess,
  });

  return (
    <form noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Edit workspace</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-5">
            <TextField
              id="name"
              label="Workspace name"
              placeholder="Acme Operations"
              value={values.name}
              error={errors.name}
              required
              onValueChange={getFieldHandler("name")}
            />

            <TextareaField
              id="description"
              label="Description"
              placeholder="Briefly describe what this workspace manages."
              value={values.description ?? ""}
              error={errors.description}
              onValueChange={getFieldHandler("description")}
            />

            <div className="grid gap-5 sm:grid-cols-2">
              <SelectField
                id="language"
                label="Language"
                placeholder="Select a language"
                value={values.language}
                options={LANGUAGES}
                error={errors.language}
                required
                onValueChange={getFieldHandler("language")}
              />
              <SelectField
                id="organizationType"
                label="Organization type"
                placeholder="Select a type"
                value={values.organizationType}
                options={ORGANIZATION_TYPES}
                error={errors.organizationType}
                required
                onValueChange={getFieldHandler("organizationType")}
              />
            </div>

            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                id="email"
                label="Workspace email"
                type="email"
                placeholder="team@acme.com"
                value={values.email}
                error={errors.email}
                required
                onValueChange={getFieldHandler("email")}
              />
              <SelectField
                id="country"
                label="Country"
                placeholder="Select a country"
                value={values.country}
                options={COUNTRIES}
                error={errors.country}
                required
                onValueChange={getFieldHandler("country")}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="gap-3">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : "Save changes"}
          </Button>
          <Button type="button" variant="ghost" onClick={onCancel}>
            Cancel
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
