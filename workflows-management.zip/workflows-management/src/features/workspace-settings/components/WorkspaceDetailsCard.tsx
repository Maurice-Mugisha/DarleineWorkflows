import { MoreVertical, Pencil, Building2, Languages, Mail, MapPin } from "lucide-react";
import { Button } from "@/shared/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import { Card, CardContent } from "@/shared/ui/card";
import InfoField from "@/shared/components/InfoField";
import { LANGUAGES } from "@/shared/utils/languages";
import { ORGANIZATION_TYPES } from "@/shared/utils/organizationTypes";
import { COUNTRIES } from "@/shared/utils/countries";
import type { SelectOption } from "@/shared/utils/organizationTypes";
import type { Workspace } from "@/features/workspace-settings/types/workspace";

interface WorkspaceDetailsCardProps {
  workspace: Workspace;
  onEditClick: () => void;
}

function findOptionLabel(options: SelectOption[], code: string): string {
  return options.find((option) => option.value === code)?.label ?? code;
}

export default function WorkspaceDetailsCard({
  workspace,
  onEditClick,
}: WorkspaceDetailsCardProps) {
  const languageLabel = findOptionLabel(LANGUAGES, workspace.language ?? "");
  const orgTypeLabel = findOptionLabel(ORGANIZATION_TYPES, workspace.organization_type ?? "");
  const countryLabel = findOptionLabel(COUNTRIES, workspace.country ?? "");

  return (
    <div className="flex flex-col gap-6">
      <Card className="from-primary/10 via-card to-card gap-0 bg-linear-to-br py-0">
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <span className="bg-primary/15 text-primary flex size-16 shrink-0 items-center justify-center rounded-md">
                <Building2 className="size-8" />
              </span>
              <div className="min-w-0">
                <h2 className="text-2xl font-semibold tracking-tight">{workspace.name}</h2>
                <p className="text-muted-foreground mt-1 max-w-xl text-sm">
                  {workspace.description}
                </p>
              </div>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="shrink-0"
                  aria-label="Workspace actions"
                >
                  <MoreVertical />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuItem onClick={onEditClick}>
                  <Pencil />
                  Edit
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2">
        <InfoField icon={Languages} label="Language" value={languageLabel} />
        <InfoField icon={Building2} label="Organization type" value={orgTypeLabel} />
        <InfoField icon={Mail} label="Email" value={workspace.email ?? ""} />
        <InfoField icon={MapPin} label="Country" value={countryLabel} />
      </div>
    </div>
  );
}
