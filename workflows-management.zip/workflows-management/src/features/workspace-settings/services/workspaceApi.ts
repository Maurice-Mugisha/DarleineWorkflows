import apiClient from "@/shared/lib/apiClient";
import getCurrentWorkspaceId from "@/shared/lib/currentWorkspace";
import type { Workspace } from "@/features/workspace-settings/types/workspace";

export async function fetchWorkspaceRequest(): Promise<Workspace> {
  const response = await apiClient.get<Workspace>(
    `/workspace/retrieve_a_workspace/${encodeURIComponent(getCurrentWorkspaceId())}`,
  );
  return response.data;
}

export async function updateWorkspaceRequest(payload: Workspace): Promise<void> {
  await apiClient.post("/workspace/update_a_workspace", payload);
}
