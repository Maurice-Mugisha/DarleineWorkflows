import { z } from "zod";

export const workspaceSettingsSchema = z.object({
  name: z.string().min(2, "Workspace name must be at least 2 characters."),
  description: z.string().optional(),
  language: z.string().min(1, "Please select a language."),
  organizationType: z.string().min(1, "Please select an organization type."),
  email: z.email("Enter a valid workspace email address."),
  country: z.string().min(1, "Please select a country."),
});

export type WorkspaceSettingsFormValues = z.infer<typeof workspaceSettingsSchema>;
