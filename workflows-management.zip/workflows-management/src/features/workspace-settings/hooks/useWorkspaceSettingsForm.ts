import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import {
  workspaceSettingsSchema,
  type WorkspaceSettingsFormValues,
} from "@/features/workspace-settings/schemas/workspaceSettingsSchema";
import buildWorkspacePayload from "@/features/workspace-settings/utils/buildWorkspacePayload";
import { updateWorkspaceRequest } from "@/features/workspace-settings/services/workspaceApi";
import type { Workspace } from "@/features/workspace-settings/types/workspace";

interface UseWorkspaceSettingsFormOptions {
  workspace: Workspace;
  onSuccess: () => void;
}

function buildInitialValues(workspace: Workspace): WorkspaceSettingsFormValues {
  return {
    name: workspace.name,
    description: workspace.description ?? "",
    language: workspace.language ?? "",
    organizationType: workspace.organization_type ?? "",
    email: workspace.email ?? "",
    country: workspace.country ?? "",
  };
}

export default function useWorkspaceSettingsForm({
  workspace,
  onSuccess,
}: UseWorkspaceSettingsFormOptions) {
  return useZodForm<WorkspaceSettingsFormValues>({
    schema: workspaceSettingsSchema,
    initialValues: buildInitialValues(workspace),
    onValidSubmit: async (values) => {
      try {
        await updateWorkspaceRequest(buildWorkspacePayload(values, workspace));
        toast.success("Workspace updated successfully.");
        onSuccess();
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to update the workspace. Please try again."));
      }
    },
  });
}
