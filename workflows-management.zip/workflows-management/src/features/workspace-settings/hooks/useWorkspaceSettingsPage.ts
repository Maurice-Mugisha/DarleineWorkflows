import { useCallback, useEffect, useState } from "react";
import toast from "react-hot-toast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { fetchWorkspaceRequest } from "@/features/workspace-settings/services/workspaceApi";
import type { Workspace } from "@/features/workspace-settings/types/workspace";

export default function useWorkspaceSettingsPage() {
  const [workspace, setWorkspace] = useState<Workspace | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const handleRefreshWorkspace = useCallback(async () => {
    try {
      const data = await fetchWorkspaceRequest();
      setWorkspace(data);
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to reload the workspace."));
    }
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function fetchWorkspace() {
      try {
        const data = await fetchWorkspaceRequest();
        if (!cancelled) {
          setWorkspace(data);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load the workspace."));
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    fetchWorkspace();

    return () => {
      cancelled = true;
    };
  }, []);

  return { workspace, isLoading, handleRefreshWorkspace };
}
