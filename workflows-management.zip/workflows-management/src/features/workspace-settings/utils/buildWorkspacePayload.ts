import type { WorkspaceSettingsFormValues } from "@/features/workspace-settings/schemas/workspaceSettingsSchema";
import type { Workspace } from "@/features/workspace-settings/types/workspace";

export default function buildWorkspacePayload(
  values: WorkspaceSettingsFormValues,
  existingWorkspace: Workspace,
): Workspace {
  return {
    id: existingWorkspace.id,
    name: values.name.trim(),
    description: values.description?.trim() ?? "",
    language: values.language,
    organization_type: values.organizationType,
    email: values.email.trim(),
    country: values.country,
    admin: existingWorkspace.admin ?? null,
  };
}
