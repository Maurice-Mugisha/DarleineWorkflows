import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import DashboardLayout from "@/shared/components/DashboardLayout";
import WorkspaceDetailsCard from "@/features/workspace-settings/components/WorkspaceDetailsCard";
import WorkspaceSettingsForm from "@/features/workspace-settings/components/WorkspaceSettingsForm";
import useWorkspaceSettingsPage from "@/features/workspace-settings/hooks/useWorkspaceSettingsPage";

function LoadingWorkspace() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-6 w-40" />
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-5">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      </CardContent>
    </Card>
  );
}

export default function WorkspaceSettingsPage() {
  const { workspace, isLoading, handleRefreshWorkspace } = useWorkspaceSettingsPage();
  const [isEditing, setIsEditing] = useState(false);

  const handleEditSuccess = () => {
    handleRefreshWorkspace();
    setIsEditing(false);
  };

  const handleEditCancel = () => {
    setIsEditing(false);
  };

  return (
    <DashboardLayout title="Workspace" subtitle="Manage your workspace details and preferences.">
      {isLoading ? (
        <LoadingWorkspace />
      ) : workspace === null ? (
        <p className="text-muted-foreground">Unable to load the workspace.</p>
      ) : isEditing ? (
        <WorkspaceSettingsForm
          workspace={workspace}
          onSuccess={handleEditSuccess}
          onCancel={handleEditCancel}
        />
      ) : (
        <WorkspaceDetailsCard workspace={workspace} onEditClick={() => setIsEditing(true)} />
      )}
    </DashboardLayout>
  );
}
