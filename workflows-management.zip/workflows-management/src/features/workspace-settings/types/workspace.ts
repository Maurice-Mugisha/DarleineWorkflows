export interface Workspace {
  id: string;
  name: string;
  description: string;
  language?: string | null;
  organization_type?: string | null;
  email?: string | null;
  country?: string | null;
  admin?: unknown;
}
