const TIME_UNIT_DESCRIPTIONS: Record<string, string> = {
  second: "One second",
  minute: "60 seconds",
  hour: "60 minutes",
  day: "24 hours",
  week: "7 days",
  month: "About 30 days",
  quarter: "3 months",
  year: "12 months",
  decade: "10 years",
  century: "100 years",
};

export default function getTimeUnitDescription(unit: string): string {
  return TIME_UNIT_DESCRIPTIONS[unit.toLowerCase()] ?? "";
}
