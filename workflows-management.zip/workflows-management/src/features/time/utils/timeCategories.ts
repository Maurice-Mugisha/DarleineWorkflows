export const PROCESS_STEP_TIME_CATEGORY = "Process step time";
export const PRECEDING_STEP_TIME_CATEGORY = "Preceding step time";
