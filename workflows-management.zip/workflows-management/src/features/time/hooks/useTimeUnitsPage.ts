import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { fetchAllTimeUnitsRequest } from "@/features/time/services/timeApi";

export default function useTimeUnitsPage() {
  const [timeUnits, setTimeUnits] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function fetchTimeUnits() {
      try {
        const data = await fetchAllTimeUnitsRequest();
        if (!cancelled) {
          setTimeUnits(data);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load time units."));
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    fetchTimeUnits();

    return () => {
      cancelled = true;
    };
  }, []);

  return { timeUnits, isLoading };
}
