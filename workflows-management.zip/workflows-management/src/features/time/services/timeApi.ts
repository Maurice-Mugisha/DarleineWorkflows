import apiClient from "@/shared/lib/apiClient";

export async function fetchAllTimeUnitsRequest(): Promise<string[]> {
  const response = await apiClient.get<string[]>("/time/retrieve_all_time_units");
  return response.data;
}
