import { Clock } from "lucide-react";
import { Card, CardContent } from "@/shared/ui/card";
import { Skeleton } from "@/shared/ui/skeleton";
import getTimeUnitDescription from "@/features/time/utils/timeUnitDescriptions";

interface TimeUnitsListProps {
  timeUnits: string[];
  isLoading: boolean;
}

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function LoadingCards() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 6 }).map((_, index) => (
        <Card key={index}>
          <CardContent>
            <Skeleton className="mb-2 h-5 w-20" />
            <Skeleton className="h-4 w-28" />
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default function TimeUnitsList({ timeUnits, isLoading }: TimeUnitsListProps) {
  if (isLoading) {
    return <LoadingCards />;
  }

  if (timeUnits.length === 0) {
    return <p className="text-muted-foreground">No time units are available.</p>;
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {timeUnits.map((unit) => (
        <Card key={unit}>
          <CardContent>
            <div className="flex items-center gap-3">
              <span className="bg-primary/10 text-primary flex size-10 shrink-0 items-center justify-center rounded-md">
                <Clock className="size-5" />
              </span>
              <div className="min-w-0">
                <p className="font-medium">{capitalize(unit)}</p>
                <p className="text-muted-foreground text-sm">{getTimeUnitDescription(unit)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
