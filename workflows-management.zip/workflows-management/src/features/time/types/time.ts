export interface Time {
  id: string;
  step_id: string;
  time_unit: string;
  time_unit_category: string;
  time_unit_value: number;
}
