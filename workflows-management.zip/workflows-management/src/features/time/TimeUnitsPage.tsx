import DashboardLayout from "@/shared/components/DashboardLayout";
import TimeUnitsList from "@/features/time/components/TimeUnitsList";
import useTimeUnitsPage from "@/features/time/hooks/useTimeUnitsPage";

export default function TimeUnitsPage() {
  const { timeUnits, isLoading } = useTimeUnitsPage();

  return (
    <DashboardLayout
      title="Time units"
      subtitle="The units available when defining step timing."
    >
      <div className="flex flex-col gap-6">
        <p className="text-muted-foreground max-w-2xl text-sm">
          Every step defines a process step time (how long the step takes) and a preceding
          step time (the wait before it starts). Both are measured using the time units below.
        </p>
        <TimeUnitsList timeUnits={timeUnits} isLoading={isLoading} />
      </div>
    </DashboardLayout>
  );
}
