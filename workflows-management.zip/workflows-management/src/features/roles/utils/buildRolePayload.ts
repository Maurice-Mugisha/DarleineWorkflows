import type { RoleFormValues } from "@/features/roles/schemas/roleSchema";
import type { Role } from "@/features/roles/types/role";

export default function buildRolePayload(values: RoleFormValues, id?: string): Role {
  return {
    id: id ?? crypto.randomUUID(),
    name: values.name.trim(),
    description: values.description?.trim() ?? "",
  };
}
