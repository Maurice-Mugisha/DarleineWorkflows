import { Link } from "react-router-dom";
import { Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import RolesList from "@/features/roles/components/RolesList";
import useRolesPage from "@/features/roles/hooks/useRolesPage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function RolesPage() {
  const { roles, isLoading, handleDeleteRole } = useRolesPage();

  const headerAction = (
    <Button asChild>
      <Link to={ROUTE_PATHS.createRole}>
        <Plus />
        New role
      </Link>
    </Button>
  );

  return (
    <DashboardLayout
      title="Roles"
      subtitle="Group permissions and assign them to your members."
      action={headerAction}
    >
      <RolesList roles={roles} isLoading={isLoading} onDelete={handleDeleteRole} />
    </DashboardLayout>
  );
}
