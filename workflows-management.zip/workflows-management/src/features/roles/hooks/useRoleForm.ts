import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";
import { roleSchema, type RoleFormValues } from "@/features/roles/schemas/roleSchema";
import buildRolePayload from "@/features/roles/utils/buildRolePayload";
import { createRoleRequest, updateRoleRequest } from "@/features/roles/services/roleApi";
import type { Role } from "@/features/roles/types/role";

interface UseRoleFormOptions {
  existingRole?: Role;
}

function buildInitialValues(existingRole?: Role): RoleFormValues {
  return {
    name: existingRole?.name ?? "",
    description: existingRole?.description ?? "",
  };
}

export default function useRoleForm({ existingRole }: UseRoleFormOptions) {
  const navigate = useNavigate();

  return useZodForm<RoleFormValues>({
    schema: roleSchema,
    initialValues: buildInitialValues(existingRole),
    onValidSubmit: async (values) => {
      try {
        if (existingRole) {
          await updateRoleRequest(buildRolePayload(values, existingRole.id));
          navigate(ROUTE_PATHS.roles, { state: { roleUpdated: true } });
        } else {
          await createRoleRequest(buildRolePayload(values));
          navigate(ROUTE_PATHS.roles, { state: { roleCreated: true } });
        }
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to save the role. Please try again."));
      }
    },
  });
}
