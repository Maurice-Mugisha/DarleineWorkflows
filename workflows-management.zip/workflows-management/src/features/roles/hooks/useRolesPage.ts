import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import useNavigationSuccessToast from "@/shared/hooks/useNavigationSuccessToast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { fetchAllRolesRequest, deleteRoleRequest } from "@/features/roles/services/roleApi";
import type { Role } from "@/features/roles/types/role";

export default function useRolesPage() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useNavigationSuccessToast("roleCreated", "Role created successfully.");
  useNavigationSuccessToast("roleUpdated", "Role updated successfully.");

  useEffect(() => {
    let cancelled = false;

    async function fetchRoles() {
      try {
        const data = await fetchAllRolesRequest();
        if (!cancelled) {
          setRoles(data);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load roles."));
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    fetchRoles();

    return () => {
      cancelled = true;
    };
  }, []);

  const handleDeleteRole = async (roleId: string) => {
    try {
      await deleteRoleRequest(roleId);
      setRoles((previousRoles) => previousRoles.filter((role) => role.id !== roleId));
      toast.success("Role deleted.");
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to delete the role."));
    }
  };

  return { roles, isLoading, handleDeleteRole };
}
