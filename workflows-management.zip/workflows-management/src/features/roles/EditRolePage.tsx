import { Link, useLocation, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import PageLoader from "@/shared/components/PageLoader";
import NotFoundPage from "@/features/errors/NotFoundPage";
import RoleForm from "@/features/roles/components/RoleForm";
import useResolvedEntity from "@/shared/hooks/useResolvedEntity";
import { fetchRoleByIdRequest } from "@/features/roles/services/roleApi";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Role } from "@/features/roles/types/role";

export default function EditRolePage() {
  const location = useLocation();
  const { roleId } = useParams();
  const stateRole = (location.state as { role?: Role } | null)?.role ?? null;

  const {
    entity: role,
    isLoading,
    isNotFound,
  } = useResolvedEntity<Role>({
    stateEntity: stateRole,
    id: roleId,
    fetchById: fetchRoleByIdRequest,
  });

  if (isLoading) {
    return (
      <DashboardLayout title="Edit role" subtitle="Update this role.">
        <PageLoader />
      </DashboardLayout>
    );
  }

  if (isNotFound || role === null) {
    return <NotFoundPage />;
  }

  return (
    <DashboardLayout title="Edit role" subtitle="Update this role.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.roles}>
            <ArrowLeft />
            Back to roles
          </Link>
        </Button>
        <RoleForm existingRole={role} />
      </div>
    </DashboardLayout>
  );
}
