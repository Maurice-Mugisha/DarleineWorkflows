import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import DashboardLayout from "@/shared/components/DashboardLayout";
import RoleForm from "@/features/roles/components/RoleForm";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function CreateRolePage() {
  return (
    <DashboardLayout title="Create role" subtitle="Define a new role for your workspace.">
      <div className="flex flex-col gap-6">
        <Button variant="ghost" size="sm" asChild className="w-fit">
          <Link to={ROUTE_PATHS.roles}>
            <ArrowLeft />
            Back to roles
          </Link>
        </Button>
        <RoleForm />
      </div>
    </DashboardLayout>
  );
}
