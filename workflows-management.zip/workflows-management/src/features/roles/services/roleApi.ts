import apiClient from "@/shared/lib/apiClient";
import getCurrentWorkspaceId from "@/shared/lib/currentWorkspace";
import type { Role } from "@/features/roles/types/role";

export async function fetchAllRolesRequest(): Promise<Role[]> {
  const response = await apiClient.get<Role[]>(
    `/role/retrieve_all_roles/${encodeURIComponent(getCurrentWorkspaceId())}`,
  );
  return response.data;
}

export async function fetchRoleByIdRequest(roleId: string): Promise<Role> {
  const response = await apiClient.get<Role>(`/role/retrieve_a_role/${encodeURIComponent(roleId)}`);
  return response.data;
}

export async function createRoleRequest(payload: Role): Promise<void> {
  await apiClient.post("/role/register_a_role", payload);
}

export async function updateRoleRequest(payload: Role): Promise<void> {
  await apiClient.post("/role/update_a_role", payload);
}

export async function deleteRoleRequest(roleId: string): Promise<void> {
  await apiClient.delete("/role/delete_a_role", {
    params: { role_id: roleId },
  });
}
