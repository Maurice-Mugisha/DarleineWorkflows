import { useState } from "react";
import { Link } from "react-router-dom";
import { MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/shared/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import ConfirmDialog from "@/shared/components/ConfirmDialog";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Role } from "@/features/roles/types/role";

interface RoleRowProps {
  role: Role;
  onDelete: (roleId: string) => Promise<void>;
}

export default function RoleRow({ role, onDelete }: RoleRowProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    setIsDeleting(true);
    await onDelete(role.id);
    setIsDeleting(false);
    setShowDeleteDialog(false);
  };

  return (
    <>
      <div className="border-border flex items-start justify-between gap-4 rounded-lg border p-4">
        <div className="min-w-0">
          <p className="font-medium">{role.name}</p>
          {role.description ? (
            <p className="text-muted-foreground mt-0.5 text-sm">{role.description}</p>
          ) : null}
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="size-8 shrink-0"
              aria-label="Role actions"
            >
              <MoreHorizontal className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem asChild>
              <Link to={ROUTE_PATHS.editRole.replace(":roleId", role.id)} state={{ role }}>
                <Pencil />
                Edit
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem variant="destructive" onClick={() => setShowDeleteDialog(true)}>
              <Trash2 />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <ConfirmDialog
        isOpen={showDeleteDialog}
        onConfirm={handleDelete}
        onCancel={() => setShowDeleteDialog(false)}
        title="Delete role"
        message={`Are you sure you want to delete "${role.name}"? This action cannot be undone.`}
        isLoading={isDeleting}
      />
    </>
  );
}
