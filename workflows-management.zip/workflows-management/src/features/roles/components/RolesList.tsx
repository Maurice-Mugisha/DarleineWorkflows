import { Skeleton } from "@/shared/ui/skeleton";
import RoleRow from "@/features/roles/components/RoleRow";
import RolesEmptyState from "@/features/roles/components/RolesEmptyState";
import type { Role } from "@/features/roles/types/role";

interface RolesListProps {
  roles: Role[];
  isLoading: boolean;
  onDelete: (roleId: string) => Promise<void>;
}

function LoadingRows() {
  return (
    <div className="flex flex-col gap-3">
      {Array.from({ length: 3 }).map((_, index) => (
        <div key={index} className="border-border rounded-lg border p-4">
          <Skeleton className="mb-2 h-5 w-40" />
          <Skeleton className="h-4 w-72" />
        </div>
      ))}
    </div>
  );
}

export default function RolesList({ roles, isLoading, onDelete }: RolesListProps) {
  if (isLoading) {
    return <LoadingRows />;
  }

  if (roles.length === 0) {
    return <RolesEmptyState />;
  }

  return (
    <div className="flex flex-col gap-3">
      {roles.map((role) => (
        <RoleRow key={role.id} role={role} onDelete={onDelete} />
      ))}
    </div>
  );
}
