import { Link } from "react-router-dom";
import { ShieldCheck, Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { ROUTE_PATHS } from "@/routes/routePaths";

const ROLE_BENEFITS = [
  {
    text: "Group people by what they are allowed to do.",
    accent: "border-l-primary bg-primary/5",
  },
  {
    text: "Assign roles to steps to control who can run each one.",
    accent: "border-l-amber-500 bg-amber-50 dark:border-l-amber-400 dark:bg-amber-950/30",
  },
  {
    text: "Keep access clear and consistent across your workspace.",
    accent: "border-l-emerald-500 bg-emerald-50 dark:border-l-emerald-400 dark:bg-emerald-950/30",
  },
];

export default function RolesEmptyState() {
  return (
    <div className="border-border flex flex-col items-center rounded-xl border border-dashed py-16 text-center">
      <span className="bg-primary/10 text-primary mb-6 flex size-20 items-center justify-center rounded-2xl">
        <ShieldCheck className="size-10" />
      </span>

      <h2 className="text-2xl font-semibold tracking-tight">No roles yet</h2>
      <p className="text-muted-foreground mt-2 max-w-md">
        Create roles to define what your team members can access across workflows and steps.
      </p>

      <ul className="mt-8 flex w-full max-w-lg flex-col gap-3">
        {ROLE_BENEFITS.map((benefit) => (
          <li
            key={benefit.text}
            className={`border-border rounded-lg border-l-4 px-4 py-3 text-left text-sm ${benefit.accent}`}
          >
            {benefit.text}
          </li>
        ))}
      </ul>

      <Button size="lg" className="mt-8" asChild>
        <Link to={ROUTE_PATHS.createRole}>
          <Plus />
          Create your first role
        </Link>
      </Button>
    </div>
  );
}
