import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/shared/ui/card";
import TextField from "@/shared/components/TextField";
import TextareaField from "@/shared/components/TextareaField";
import useRoleForm from "@/features/roles/hooks/useRoleForm";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { Role } from "@/features/roles/types/role";

interface RoleFormProps {
  existingRole?: Role;
}

export default function RoleForm({ existingRole }: RoleFormProps) {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit } = useRoleForm({
    existingRole,
  });

  const isEditing = existingRole !== undefined;

  return (
    <form noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Role details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-5">
            <TextField
              id="name"
              label="Role name"
              placeholder="Workflow step user"
              value={values.name}
              error={errors.name}
              required
              onValueChange={getFieldHandler("name")}
            />
            <TextareaField
              id="description"
              label="Description"
              placeholder="What can users with this role do?"
              value={values.description ?? ""}
              error={errors.description}
              onValueChange={getFieldHandler("description")}
            />
          </div>
        </CardContent>
        <CardFooter className="gap-3">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : isEditing ? "Save changes" : "Create role"}
          </Button>
          <Button type="button" variant="ghost" asChild>
            <Link to={ROUTE_PATHS.roles}>Cancel</Link>
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
