import { Link, Navigate, useParams } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/shared/ui/button";
import Logo from "@/shared/components/Logo";
import ThemeMenu from "@/shared/components/ThemeMenu";
import JoinWorkspaceForm from "@/features/workspaces/components/JoinWorkspaceForm";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function JoinWorkspacePage() {
  const { workspaceId } = useParams();

  if (workspaceId === undefined) {
    return <Navigate to={ROUTE_PATHS.workspaces} replace />;
  }

  return (
    <div className="flex min-h-svh flex-col">
      <header className="flex items-center justify-between px-4 py-4 sm:px-6">
        <Logo />
        <ThemeMenu />
      </header>
      <main className="flex flex-1 justify-center px-4 py-10">
        <div className="w-full max-w-2xl">
          <div className="mb-8">
            <Button variant="ghost" size="sm" asChild className="w-fit">
              <Link to={ROUTE_PATHS.workspaces}>
                <ArrowLeft />
                Back to workspaces
              </Link>
            </Button>
            <h1 className="mt-4 text-2xl font-semibold tracking-tight sm:text-3xl">
              Join this workspace
            </h1>
            <p className="text-muted-foreground mt-2 text-sm">
              Fill in your details to register as a member of this workspace.
            </p>
          </div>
          <JoinWorkspaceForm />
          <p className="text-muted-foreground mt-6 text-center text-sm">
            Already a member?{" "}
            <Link to={ROUTE_PATHS.login} className="text-primary font-medium hover:underline">
              Sign in
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}
