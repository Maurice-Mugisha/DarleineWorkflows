import type { JoinWorkspaceFormValues } from "@/features/workspaces/schemas/joinWorkspaceSchema";

interface BuildJoinWorkspacePayloadParams {
  values: JoinWorkspaceFormValues;
  workspaceId: string;
}

export default function buildJoinWorkspacePayload({
  values,
  workspaceId,
}: BuildJoinWorkspacePayloadParams) {
  return {
    id: crypto.randomUUID(),
    workspace_id: workspaceId,
    first_name: values.firstName.trim(),
    last_name: values.lastName.trim(),
    email: values.email.trim(),
    password: values.password,
    job_title: values.jobTitle.trim(),
  };
}
