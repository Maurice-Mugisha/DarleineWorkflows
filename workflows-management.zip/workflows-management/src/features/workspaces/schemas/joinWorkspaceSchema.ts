import { z } from "zod";

export const joinWorkspaceSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters."),
  lastName: z.string().min(2, "Last name must be at least 2 characters."),
  email: z.email("Enter a valid email address."),
  password: z.string().min(8, "Password must be at least 8 characters."),
  jobTitle: z.string().min(2, "Job title must be at least 2 characters."),
});

export type JoinWorkspaceFormValues = z.infer<typeof joinWorkspaceSchema>;
