import apiClient from "@/shared/lib/apiClient";
import type { WorkspacePublic } from "@/features/workspaces/types/workspace";

export async function fetchAllWorkspacesRequest(): Promise<WorkspacePublic[]> {
  const response = await apiClient.get<WorkspacePublic[]>("/workspace/retrieve_all_workspaces");
  return response.data;
}
