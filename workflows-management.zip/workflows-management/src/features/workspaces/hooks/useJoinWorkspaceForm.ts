import { useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";
import useZodForm from "@/shared/hooks/useZodForm";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";
import {
  joinWorkspaceSchema,
  type JoinWorkspaceFormValues,
} from "@/features/workspaces/schemas/joinWorkspaceSchema";
import buildJoinWorkspacePayload from "@/features/workspaces/utils/buildJoinWorkspacePayload";
import { createUserRequest } from "@/features/users/services/userApi";

const INITIAL_VALUES: JoinWorkspaceFormValues = {
  firstName: "",
  lastName: "",
  email: "",
  password: "",
  jobTitle: "",
};

export default function useJoinWorkspaceForm() {
  const navigate = useNavigate();
  const { workspaceId } = useParams();

  return useZodForm<JoinWorkspaceFormValues>({
    schema: joinWorkspaceSchema,
    initialValues: INITIAL_VALUES,
    onValidSubmit: async (values) => {
      try {
        if (workspaceId === undefined) return;

        await createUserRequest(buildJoinWorkspacePayload({ values, workspaceId }));
        navigate(ROUTE_PATHS.login, { state: { registrationSuccess: true } });
      } catch (error) {
        toast.error(getApiErrorMessage(error, "Unable to register. Please try again."));
      }
    },
  });
}
