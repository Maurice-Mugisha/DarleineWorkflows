import { useEffect, useState } from "react";
import toast from "react-hot-toast";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { fetchAllWorkspacesRequest } from "@/features/workspaces/services/workspaceApi";
import type { WorkspacePublic } from "@/features/workspaces/types/workspace";

export default function useWorkspacesPage() {
  const [workspaces, setWorkspaces] = useState<WorkspacePublic[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function fetchData() {
      try {
        const data = await fetchAllWorkspacesRequest();
        if (!cancelled) {
          setWorkspaces(data);
        }
      } catch (error) {
        if (!cancelled) {
          toast.error(getApiErrorMessage(error, "Unable to load workspaces."));
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    }

    fetchData();

    return () => {
      cancelled = true;
    };
  }, []);

  return { workspaces, isLoading };
}
