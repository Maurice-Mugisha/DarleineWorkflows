export interface WorkspacePublic {
  id: string;
  name: string;
  description: string;
  language?: string | null;
  organization_type?: string | null;
  email?: string | null;
  country?: string | null;
}
