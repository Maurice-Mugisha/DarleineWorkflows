import Logo from "@/shared/components/Logo";
import ThemeMenu from "@/shared/components/ThemeMenu";
import WorkspacePublicCard from "@/features/workspaces/components/WorkspacePublicCard";
import WorkspacesEmptyState from "@/features/workspaces/components/WorkspacesEmptyState";
import { Skeleton } from "@/shared/ui/skeleton";
import useWorkspacesPage from "@/features/workspaces/hooks/useWorkspacesPage";

function LoadingCards() {
  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {Array.from({ length: 3 }).map((_, index) => (
        <div key={index} className="border-border rounded-md border p-6">
          <Skeleton className="mb-2 h-6 w-48" />
          <Skeleton className="mb-4 h-4 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ))}
    </div>
  );
}

export default function WorkspacesPage() {
  const { workspaces, isLoading } = useWorkspacesPage();

  return (
    <div className="flex min-h-svh flex-col">
      <header className="flex items-center justify-between px-4 py-4 sm:px-6">
        <Logo />
        <ThemeMenu />
      </header>
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-10">
        <div className="mb-10 text-center">
          <h1 className="text-3xl font-semibold tracking-tight">Find a workspace</h1>
          <p className="text-muted-foreground mt-2">Choose a workspace and register as a member.</p>
        </div>
        {isLoading ? (
          <LoadingCards />
        ) : workspaces.length === 0 ? (
          <WorkspacesEmptyState />
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {workspaces.map((workspace) => (
              <WorkspacePublicCard key={workspace.id} workspace={workspace} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
