import { Link } from "react-router-dom";
import { Building2, Plus } from "lucide-react";
import { Button } from "@/shared/ui/button";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function WorkspacesEmptyState() {
  return (
    <div className="border-border flex flex-col items-center rounded-md border border-dashed py-16 text-center">
      <span className="bg-primary/10 text-primary mb-6 flex size-20 items-center justify-center rounded-2xl">
        <Building2 className="size-10" />
      </span>
      <h2 className="text-2xl font-semibold tracking-tight">No workspaces yet</h2>
      <p className="text-muted-foreground mt-2 max-w-md">
        No workspaces are currently available. Create one to get started.
      </p>
      <Button size="lg" className="mt-8" asChild>
        <Link to={ROUTE_PATHS.register}>
          <Plus />
          Create a workspace
        </Link>
      </Button>
    </div>
  );
}
