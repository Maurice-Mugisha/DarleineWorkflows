import { Link } from "react-router-dom";
import { ArrowRight, Building2, MapPin } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/shared/ui/card";
import { Button } from "@/shared/ui/button";
import { ORGANIZATION_TYPES } from "@/shared/utils/organizationTypes";
import { COUNTRIES } from "@/shared/utils/countries";
import { ROUTE_PATHS } from "@/routes/routePaths";
import type { WorkspacePublic } from "@/features/workspaces/types/workspace";

function findOptionLabel(options: { value: string; label: string }[], code: string): string {
  return options.find((o) => o.value === code)?.label ?? code;
}

export default function WorkspacePublicCard({ workspace }: { workspace: WorkspacePublic }) {
  const orgLabel = workspace.organization_type
    ? findOptionLabel(ORGANIZATION_TYPES, workspace.organization_type)
    : "";
  const countryLabel = workspace.country ? findOptionLabel(COUNTRIES, workspace.country) : "";

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle>{workspace.name}</CardTitle>
        <CardDescription className="line-clamp-3">{workspace.description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-muted-foreground mt-auto mb-4 flex flex-wrap items-center gap-3 text-xs">
          {orgLabel ? (
            <span className="flex items-center gap-1">
              <Building2 className="size-3" />
              {orgLabel}
            </span>
          ) : null}
          {countryLabel ? (
            <span className="flex items-center gap-1">
              <MapPin className="size-3" />
              {countryLabel}
            </span>
          ) : null}
        </div>
        <Button asChild className="w-full">
          <Link to={ROUTE_PATHS.joinWorkspace.replace(":workspaceId", workspace.id)}>
            Register
            <ArrowRight />
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}
