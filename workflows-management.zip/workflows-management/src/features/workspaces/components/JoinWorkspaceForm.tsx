import { Link } from "react-router-dom";
import { Button } from "@/shared/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/shared/ui/card";
import TextField from "@/shared/components/TextField";
import useJoinWorkspaceForm from "@/features/workspaces/hooks/useJoinWorkspaceForm";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function JoinWorkspaceForm() {
  const { values, errors, isSubmitting, getFieldHandler, handleSubmit } = useJoinWorkspaceForm();

  return (
    <form noValidate onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Your details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-5">
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                id="firstName"
                label="First name"
                placeholder="Jane"
                value={values.firstName}
                error={errors.firstName}
                required
                onValueChange={getFieldHandler("firstName")}
              />
              <TextField
                id="lastName"
                label="Last name"
                placeholder="Doe"
                value={values.lastName}
                error={errors.lastName}
                required
                onValueChange={getFieldHandler("lastName")}
              />
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              <TextField
                id="email"
                label="Email"
                type="email"
                placeholder="jane@company.com"
                value={values.email}
                error={errors.email}
                required
                onValueChange={getFieldHandler("email")}
              />
              <TextField
                id="jobTitle"
                label="Job title"
                placeholder="Operations Manager"
                value={values.jobTitle}
                error={errors.jobTitle}
                required
                onValueChange={getFieldHandler("jobTitle")}
              />
            </div>
            <TextField
              id="password"
              label="Password"
              type="password"
              placeholder="At least 8 characters"
              value={values.password}
              error={errors.password}
              required
              onValueChange={getFieldHandler("password")}
            />
          </div>
        </CardContent>
        <CardFooter className="gap-3">
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : "Register"}
          </Button>
          <Button type="button" variant="ghost" asChild>
            <Link to={ROUTE_PATHS.workspaces}>Cancel</Link>
          </Button>
        </CardFooter>
      </Card>
    </form>
  );
}
