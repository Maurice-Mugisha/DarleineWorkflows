import { createBrowserRouter } from "react-router-dom";
import { ROUTE_PATHS } from "@/routes/routePaths";
import RootLayout from "@/routes/RootLayout";
import ProtectedRoute from "@/shared/components/ProtectedRoute";
import LandingPage from "@/features/landing/LandingPage";
import WorkspaceRegistrationPage from "@/features/workspace-registration/WorkspaceRegistrationPage";
import LoginPage from "@/features/authentication/LoginPage";
import DashboardPage from "@/features/dashboard/DashboardPage";
import WorkflowsPage from "@/features/workflows/WorkflowsPage";
import CreateWorkflowPage from "@/features/workflows/CreateWorkflowPage";
import WorkflowDetailPage from "@/features/workflows/WorkflowDetailPage";
import EditWorkflowPage from "@/features/workflows/EditWorkflowPage";
import CreateProcessPage from "@/features/workflows/CreateProcessPage";
import EditProcessPage from "@/features/workflows/EditProcessPage";
import RolesPage from "@/features/roles/RolesPage";
import CreateRolePage from "@/features/roles/CreateRolePage";
import EditRolePage from "@/features/roles/EditRolePage";
import PrivilegesPage from "@/features/privileges/PrivilegesPage";
import CreatePrivilegePage from "@/features/privileges/CreatePrivilegePage";
import EditPrivilegePage from "@/features/privileges/EditPrivilegePage";
import UsersPage from "@/features/users/UsersPage";
import CreateUserPage from "@/features/users/CreateUserPage";
import UserDetailPage from "@/features/users/UserDetailPage";
import EditUserPage from "@/features/users/EditUserPage";
import WorkspaceSettingsPage from "@/features/workspace-settings/WorkspaceSettingsPage";
import TimeUnitsPage from "@/features/time/TimeUnitsPage";
import WorkflowCasesPage from "@/features/workflow-cases/WorkflowCasesPage";
import CreateCasePage from "@/features/workflow-cases/CreateCasePage";
import CaseDetailPage from "@/features/workflow-cases/CaseDetailPage";
import EditCasePage from "@/features/workflow-cases/EditCasePage";
import ReportsPage from "@/features/reports/ReportsPage";
import CreateReportPage from "@/features/reports/CreateReportPage";
import ReportDetailPage from "@/features/reports/ReportDetailPage";
import WorkspacesPage from "@/features/workspaces/WorkspacesPage";
import JoinWorkspacePage from "@/features/workspaces/JoinWorkspacePage";
import NotFoundPage from "@/features/errors/NotFoundPage";
import ForbiddenPage from "@/features/errors/ForbiddenPage";
import UnauthorizedPage from "@/features/errors/UnauthorizedPage";
import AppErrorBoundary from "@/features/errors/AppErrorBoundary";

const router = createBrowserRouter([
  {
    element: <RootLayout />,
    errorElement: <AppErrorBoundary />,
    children: [
      { path: ROUTE_PATHS.landing, element: <LandingPage /> },
      { path: ROUTE_PATHS.register, element: <WorkspaceRegistrationPage /> },
      { path: ROUTE_PATHS.login, element: <LoginPage /> },
      { path: ROUTE_PATHS.unauthorized, element: <UnauthorizedPage /> },
      { path: ROUTE_PATHS.forbidden, element: <ForbiddenPage /> },
      {
        path: ROUTE_PATHS.dashboard,
        element: (
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.workflows,
        element: (
          <ProtectedRoute>
            <WorkflowsPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.createWorkflow,
        element: (
          <ProtectedRoute>
            <CreateWorkflowPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.workflowDetail,
        element: (
          <ProtectedRoute>
            <WorkflowDetailPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.editWorkflow,
        element: (
          <ProtectedRoute>
            <EditWorkflowPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.createProcess,
        element: (
          <ProtectedRoute>
            <CreateProcessPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.editProcess,
        element: (
          <ProtectedRoute>
            <EditProcessPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.roles,
        element: (
          <ProtectedRoute>
            <RolesPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.createRole,
        element: (
          <ProtectedRoute>
            <CreateRolePage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.editRole,
        element: (
          <ProtectedRoute>
            <EditRolePage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.privileges,
        element: (
          <ProtectedRoute>
            <PrivilegesPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.createPrivilege,
        element: (
          <ProtectedRoute>
            <CreatePrivilegePage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.editPrivilege,
        element: (
          <ProtectedRoute>
            <EditPrivilegePage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.members,
        element: (
          <ProtectedRoute>
            <UsersPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.createUser,
        element: (
          <ProtectedRoute>
            <CreateUserPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.userDetail,
        element: (
          <ProtectedRoute>
            <UserDetailPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.editUser,
        element: (
          <ProtectedRoute>
            <EditUserPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.workspace,
        element: (
          <ProtectedRoute>
            <WorkspaceSettingsPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.timeUnits,
        element: (
          <ProtectedRoute>
            <TimeUnitsPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.cases,
        element: (
          <ProtectedRoute>
            <WorkflowCasesPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.createCase,
        element: (
          <ProtectedRoute>
            <CreateCasePage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.caseDetail,
        element: (
          <ProtectedRoute>
            <CaseDetailPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.editCase,
        element: (
          <ProtectedRoute>
            <EditCasePage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.createReport,
        element: (
          <ProtectedRoute>
            <CreateReportPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.reports,
        element: (
          <ProtectedRoute>
            <ReportsPage />
          </ProtectedRoute>
        ),
      },
      {
        path: ROUTE_PATHS.reportDetail,
        element: (
          <ProtectedRoute>
            <ReportDetailPage />
          </ProtectedRoute>
        ),
      },
      { path: "*", element: <NotFoundPage /> },
      { path: ROUTE_PATHS.workspaces, element: <WorkspacesPage /> },
      { path: ROUTE_PATHS.joinWorkspace, element: <JoinWorkspacePage /> },
    ],
  },
]);

export default router;
