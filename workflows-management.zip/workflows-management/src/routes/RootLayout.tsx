import { Outlet } from "react-router-dom";
import useApiErrorRedirects from "@/shared/hooks/useApiErrorRedirects";

export default function RootLayout() {
  useApiErrorRedirects();

  return <Outlet />;
}
