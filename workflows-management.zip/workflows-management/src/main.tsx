import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Toaster } from "react-hot-toast";
import "./index.css";
import App from "./App.tsx";
import ThemeProvider from "@/shared/components/ThemeProvider";
import AuthProvider from "@/shared/components/AuthProvider";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ThemeProvider>
      <AuthProvider>
        <App />
        <Toaster
          position="top-right"
          toastOptions={{
            className:
              "bg-popover! text-popover-foreground! border! border-border! shadow-md! rounded-md!",
          }}
        />
      </AuthProvider>
    </ThemeProvider>
  </StrictMode>,
);
