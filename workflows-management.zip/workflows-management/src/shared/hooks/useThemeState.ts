import { useCallback, useEffect, useState } from "react";
import type { ResolvedTheme, Theme, ThemeContextValue } from "@/shared/types/theme";

const DARK_MODE_MEDIA_QUERY = "(prefers-color-scheme: dark)";

function readStoredTheme(storageKey: string, fallbackTheme: Theme): Theme {
  const storedTheme = window.localStorage.getItem(storageKey);
  if (storedTheme === "light" || storedTheme === "dark" || storedTheme === "system") {
    return storedTheme;
  }
  return fallbackTheme;
}

function resolveSystemTheme(): ResolvedTheme {
  return window.matchMedia(DARK_MODE_MEDIA_QUERY).matches ? "dark" : "light";
}

function resolveTheme(theme: Theme): ResolvedTheme {
  return theme === "system" ? resolveSystemTheme() : theme;
}

export default function useThemeState(defaultTheme: Theme, storageKey: string): ThemeContextValue {
  const [theme, setThemeState] = useState<Theme>(() => readStoredTheme(storageKey, defaultTheme));
  const [resolvedTheme, setResolvedTheme] = useState<ResolvedTheme>(() => resolveTheme(theme));

  useEffect(() => {
    const nextResolvedTheme = resolveTheme(theme);
    setResolvedTheme(nextResolvedTheme);

    const rootElement = window.document.documentElement;
    rootElement.classList.remove("light", "dark");
    rootElement.classList.add(nextResolvedTheme);
  }, [theme]);

  useEffect(() => {
    if (theme !== "system") {
      return;
    }

    const systemThemeQuery = window.matchMedia(DARK_MODE_MEDIA_QUERY);
    const handleSystemThemeChange = () => {
      const nextResolvedTheme = resolveSystemTheme();
      setResolvedTheme(nextResolvedTheme);

      const rootElement = window.document.documentElement;
      rootElement.classList.remove("light", "dark");
      rootElement.classList.add(nextResolvedTheme);
    };

    systemThemeQuery.addEventListener("change", handleSystemThemeChange);
    return () => systemThemeQuery.removeEventListener("change", handleSystemThemeChange);
  }, [theme]);

  const setTheme = useCallback(
    (nextTheme: Theme) => {
      window.localStorage.setItem(storageKey, nextTheme);
      setThemeState(nextTheme);
    },
    [storageKey],
  );

  return { theme, resolvedTheme, setTheme };
}
