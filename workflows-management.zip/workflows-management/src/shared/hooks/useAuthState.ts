import { useCallback, useState } from "react";
import type { AuthContextValue, AuthUser } from "@/shared/types/auth";

const AUTH_STORAGE_KEY = "workflows-management-auth";

function readStoredUser(): AuthUser | null {
  const storedValue = window.localStorage.getItem(AUTH_STORAGE_KEY);
  if (storedValue === null) {
    return null;
  }
  try {
    const parsedValue = JSON.parse(storedValue) as Partial<AuthUser>;
    if (typeof parsedValue.id !== "string" || typeof parsedValue.email !== "string") {
      return null;
    }
    return {
      id: parsedValue.id,
      email: parsedValue.email,
      firstName: parsedValue.firstName ?? "",
      lastName: parsedValue.lastName ?? "",
      workspaceId: parsedValue.workspaceId ?? "",
      jobTitle: parsedValue.jobTitle ?? "",
      roles: Array.isArray(parsedValue.roles) ? parsedValue.roles : [],
    };
  } catch {
    return null;
  }
}

export default function useAuthState(): AuthContextValue {
  const [user, setUser] = useState<AuthUser | null>(() => readStoredUser());

  const authenticate = useCallback((nextUser: AuthUser) => {
    window.localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(nextUser));
    setUser(nextUser);
  }, []);

  const clearAuthentication = useCallback(() => {
    window.localStorage.removeItem(AUTH_STORAGE_KEY);
    setUser(null);
  }, []);

  return {
    isAuthenticated: user !== null,
    user,
    authenticate,
    clearAuthentication,
  };
}
