import { useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";
import apiClient from "@/shared/lib/apiClient";
import useAuth from "@/shared/hooks/useAuth";
import getApiErrorMessage from "@/shared/utils/getApiErrorMessage";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function useLogout() {
  const navigate = useNavigate();
  const { clearAuthentication } = useAuth();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const logout = useCallback(async () => {
    setIsLoggingOut(true);
    try {
      await apiClient.post("/authentication/logout");
    } catch (error) {
      toast.error(getApiErrorMessage(error, "Unable to sign out. Please try again."));
      setIsLoggingOut(false);
      return;
    }
    clearAuthentication();
    navigate(ROUTE_PATHS.login, { replace: true });
  }, [clearAuthentication, navigate]);

  return { logout, isLoggingOut };
}
