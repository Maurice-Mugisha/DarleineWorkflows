import { useCallback, useState } from "react";

interface UsePasswordVisibilityResult {
  isVisible: boolean;
  inputType: "text" | "password";
  toggleVisibility: () => void;
}

export default function usePasswordVisibility(): UsePasswordVisibilityResult {
  const [isVisible, setIsVisible] = useState(false);

  const toggleVisibility = useCallback(() => {
    setIsVisible((previousIsVisible) => !previousIsVisible);
  }, []);

  return {
    isVisible,
    inputType: isVisible ? "text" : "password",
    toggleVisibility,
  };
}
