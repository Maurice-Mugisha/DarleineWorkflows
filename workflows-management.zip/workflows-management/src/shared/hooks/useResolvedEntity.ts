import { useEffect, useState } from "react";

interface UseResolvedEntityOptions<T> {
  stateEntity: T | null;
  id: string | undefined;
  fetchById: (id: string) => Promise<T>;
}

interface UseResolvedEntityResult<T> {
  entity: T | null;
  isLoading: boolean;
  isNotFound: boolean;
}

export default function useResolvedEntity<T>({
  stateEntity,
  id,
  fetchById,
}: UseResolvedEntityOptions<T>): UseResolvedEntityResult<T> {
  const [entity, setEntity] = useState<T | null>(stateEntity);
  const [isLoading, setIsLoading] = useState(stateEntity === null);
  const [isNotFound, setIsNotFound] = useState(false);

  useEffect(() => {
    if (stateEntity !== null) {
      setEntity(stateEntity);
      setIsLoading(false);
      setIsNotFound(false);
      return;
    }

    if (id === undefined) {
      setIsNotFound(true);
      setIsLoading(false);
      return;
    }

    let cancelled = false;
    setIsLoading(true);
    setIsNotFound(false);

    fetchById(id)
      .then((data) => {
        if (!cancelled) {
          setEntity(data);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setIsNotFound(true);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [stateEntity, id, fetchById]);

  return { entity, isLoading, isNotFound };
}
