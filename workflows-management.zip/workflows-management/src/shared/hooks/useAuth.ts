import { createContext, useContext } from "react";
import type { AuthContextValue } from "@/shared/types/auth";

export const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export default function useAuth(): AuthContextValue {
  const authContextValue = useContext(AuthContext);
  if (authContextValue === undefined) {
    throw new Error("useAuth must be used within an AuthProvider.");
  }
  return authContextValue;
}
