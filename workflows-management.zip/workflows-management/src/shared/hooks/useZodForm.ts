import { useCallback, useRef, useState, type FormEvent } from "react";
import type { ZodType } from "zod";
import type { FieldErrors } from "@/shared/types/form";

interface UseZodFormOptions<Values> {
  schema: ZodType<Values>;
  initialValues: Values;
  onValidSubmit: (values: Values) => Promise<void> | void;
}

interface UseZodFormResult<Values> {
  values: Values;
  errors: FieldErrors<Values>;
  isSubmitting: boolean;
  setFieldValue: <Field extends keyof Values>(field: Field, value: Values[Field]) => void;
  getFieldHandler: <Field extends keyof Values>(field: Field) => (value: Values[Field]) => void;
  handleSubmit: (event: FormEvent<HTMLFormElement>) => Promise<void>;
}

export default function useZodForm<Values>({
  schema,
  initialValues,
  onValidSubmit,
}: UseZodFormOptions<Values>): UseZodFormResult<Values> {
  const [values, setValues] = useState<Values>(initialValues);
  const [errors, setErrors] = useState<FieldErrors<Values>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const setFieldValue = useCallback(
    <Field extends keyof Values>(field: Field, value: Values[Field]) => {
      setValues((previousValues) => ({ ...previousValues, [field]: value }));
      setErrors((previousErrors) => {
        if (previousErrors[field] === undefined) {
          return previousErrors;
        }
        const nextErrors = { ...previousErrors };
        delete nextErrors[field];
        return nextErrors;
      });
    },
    [],
  );

  const fieldHandlersRef = useRef(new Map<keyof Values, (value: Values[keyof Values]) => void>());

  const getFieldHandler = useCallback(
    <Field extends keyof Values>(field: Field) => {
      const cache = fieldHandlersRef.current;
      if (!cache.has(field)) {
        cache.set(field, (value) => setFieldValue(field, value as Values[Field]));
      }
      return cache.get(field) as (value: Values[Field]) => void;
    },
    [setFieldValue],
  );

  const handleSubmit = useCallback(
    async (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();

      const result = schema.safeParse(values);
      if (!result.success) {
        const validationErrors: FieldErrors<Values> = {};
        for (const issue of result.error.issues) {
          const field = issue.path[0] as keyof Values | undefined;
          if (field !== undefined && validationErrors[field] === undefined) {
            validationErrors[field] = issue.message;
          }
        }
        setErrors(validationErrors);
        return;
      }

      setErrors({});
      setIsSubmitting(true);
      try {
        await onValidSubmit(result.data);
      } finally {
        setIsSubmitting(false);
      }
    },
    [schema, values, onValidSubmit],
  );

  return { values, errors, isSubmitting, setFieldValue, getFieldHandler, handleSubmit };
}
