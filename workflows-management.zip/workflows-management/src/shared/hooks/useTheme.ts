import { createContext, useContext } from "react";
import type { ThemeContextValue } from "@/shared/types/theme";

export const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

export default function useTheme(): ThemeContextValue {
  const themeContextValue = useContext(ThemeContext);
  if (themeContextValue === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider.");
  }
  return themeContextValue;
}
