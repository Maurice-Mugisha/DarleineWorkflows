import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

export default function useNavigationSuccessToast(flagKey: string, message: string) {
  const location = useLocation();
  const navigate = useNavigate();
  const locationState = location.state as Record<string, unknown> | null;
  const shouldShowToast = locationState?.[flagKey] === true;

  useEffect(() => {
    if (!shouldShowToast) {
      return;
    }
    toast.success(message, { id: flagKey });

    const remainingState: Record<string, unknown> = { ...(locationState ?? {}) };
    delete remainingState[flagKey];
    const nextState = Object.keys(remainingState).length > 0 ? remainingState : null;
    navigate(location.pathname, { replace: true, state: nextState });
  }, [shouldShowToast, message, flagKey, navigate, location.pathname, locationState]);
}
