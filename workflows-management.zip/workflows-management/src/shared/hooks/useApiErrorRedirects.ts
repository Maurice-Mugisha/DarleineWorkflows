import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { registerApiErrorHandlers } from "@/shared/lib/apiClient";
import useAuth from "@/shared/hooks/useAuth";
import { ROUTE_PATHS } from "@/routes/routePaths";

export default function useApiErrorRedirects() {
  const navigate = useNavigate();
  const { clearAuthentication } = useAuth();

  useEffect(() => {
    registerApiErrorHandlers({
      onUnauthorized: () => {
        clearAuthentication();
        navigate(ROUTE_PATHS.unauthorized, { replace: true });
      },
      onForbidden: () => {
        navigate(ROUTE_PATHS.forbidden, { replace: true });
      },
    });
  }, [navigate, clearAuthentication]);
}
