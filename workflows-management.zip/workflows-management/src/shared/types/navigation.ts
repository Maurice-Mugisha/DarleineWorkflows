import type { LucideIcon } from "lucide-react";

export interface NavSubItem {
  title: string;
  to?: string;
}

export interface NavItem {
  title: string;
  icon: LucideIcon;
  to?: string;
  children?: NavSubItem[];
}

export interface NavGroup {
  label: string;
  items: NavItem[];
}
