export type FieldErrors<Values> = Partial<Record<keyof Values, string>>;
