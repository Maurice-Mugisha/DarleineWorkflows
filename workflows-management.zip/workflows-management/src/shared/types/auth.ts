export interface AuthRole {
  id: string;
  name: string;
}

export interface AuthUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  workspaceId: string;
  jobTitle: string;
  roles: AuthRole[];
}

export interface AuthContextValue {
  isAuthenticated: boolean;
  user: AuthUser | null;
  authenticate: (user: AuthUser) => void;
  clearAuthentication: () => void;
}
