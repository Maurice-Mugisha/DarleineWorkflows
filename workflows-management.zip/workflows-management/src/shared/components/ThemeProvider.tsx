import type { ReactNode } from "react";
import { ThemeContext } from "@/shared/hooks/useTheme";
import useThemeState from "@/shared/hooks/useThemeState";
import type { Theme } from "@/shared/types/theme";

interface ThemeProviderProps {
  children: ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
}

export default function ThemeProvider({
  children,
  defaultTheme = "system",
  storageKey = "workflows-management-theme",
}: ThemeProviderProps) {
  const themeContextValue = useThemeState(defaultTheme, storageKey);

  return <ThemeContext value={themeContextValue}>{children}</ThemeContext>;
}
