import type { ReactNode } from "react";
import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/shared/ui/sidebar";
import AppSidebar from "@/shared/components/AppSidebar";
import ThemeMenu from "@/shared/components/ThemeMenu";
import UserMenu from "@/shared/components/UserMenu";

interface DashboardLayoutProps {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
}

export default function DashboardLayout({
  title,
  subtitle,
  action,
  children,
}: DashboardLayoutProps) {
  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset className="min-w-0">
        <header className="border-border bg-background sticky top-0 z-10 border-b">
          <div className="relative flex h-16 items-center">
            <div className="absolute inset-y-0 left-2 flex items-center sm:left-3">
              <SidebarTrigger />
            </div>
            <div className="mx-auto flex w-full max-w-6xl items-center px-4 sm:px-6">
              <div className="ml-auto flex items-center gap-2">
                <ThemeMenu />
                <UserMenu />
              </div>
            </div>
          </div>
        </header>
        <div className="mx-auto w-full max-w-6xl flex-1 overflow-x-clip p-4 sm:p-6">
          <div className="border-border flex flex-wrap items-start justify-between gap-3 border-b pb-5">
            <div className="min-w-0">
              <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
              {subtitle ? <p className="text-muted-foreground mt-1 text-sm">{subtitle}</p> : null}
            </div>
            {action ? <div className="shrink-0">{action}</div> : null}
          </div>
          <div className="mt-6">{children}</div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}
