import { LogOut } from "lucide-react";
import { Button } from "@/shared/ui/button";
import useLogout from "@/shared/hooks/useLogout";

export default function LogoutButton() {
  const { logout, isLoggingOut } = useLogout();

  return (
    <Button variant="outline" size="sm" disabled={isLoggingOut} onClick={() => logout()}>
      <LogOut />
      {isLoggingOut ? "Signing out..." : "Sign out"}
    </Button>
  );
}
