import { cn } from "@/shared/utils/cn";

interface InitialsAvatarProps {
  initials: string;
  className?: string;
}

export default function InitialsAvatar({ initials, className }: InitialsAvatarProps) {
  return (
    <span
      className={cn(
        "bg-primary text-primary-foreground flex size-10 shrink-0 items-center justify-center rounded-full text-sm font-semibold",
        className,
      )}
    >
      {initials}
    </span>
  );
}
