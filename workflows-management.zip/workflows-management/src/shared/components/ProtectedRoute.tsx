import type { ReactNode } from "react";
import { Navigate, useLocation } from "react-router-dom";
import useAuth from "@/shared/hooks/useAuth";
import { ROUTE_PATHS } from "@/routes/routePaths";

interface ProtectedRouteProps {
  children: ReactNode;
}

export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated } = useAuth();
  const location = useLocation();

  if (!isAuthenticated) {
    return <Navigate to={ROUTE_PATHS.login} replace state={{ from: location.pathname }} />;
  }

  return children;
}
