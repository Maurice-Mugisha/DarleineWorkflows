import type { ReactNode } from "react";
import Logo from "@/shared/components/Logo";
import ThemeMenu from "@/shared/components/ThemeMenu";

interface StatusPageProps {
  code: string;
  title: string;
  message: string;
  action: ReactNode;
}

export default function StatusPage({ code, title, message, action }: StatusPageProps) {
  return (
    <div className="flex min-h-svh flex-col">
      <header className="flex items-center justify-between px-4 py-4 sm:px-6">
        <Logo />
        <ThemeMenu />
      </header>
      <main className="flex flex-1 items-center justify-center px-4 py-10">
        <div className="flex w-full max-w-md flex-col items-center text-center">
          <p className="text-primary/80 text-7xl font-bold tracking-tight tabular-nums sm:text-8xl">
            {code}
          </p>
          <h1 className="mt-4 text-2xl font-semibold tracking-tight">{title}</h1>
          <p className="text-muted-foreground mt-2">{message}</p>
          <div className="mt-8">{action}</div>
        </div>
      </main>
    </div>
  );
}
