import { Link, useLocation } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/shared/ui/collapsible";
import {
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from "@/shared/ui/sidebar";
import type { NavItem } from "@/shared/types/navigation";

interface AppSidebarNavItemProps {
  item: NavItem;
}

export default function AppSidebarNavItem({ item }: AppSidebarNavItemProps) {
  const { pathname } = useLocation();

  if (!item.children) {
    return (
      <SidebarMenuItem>
        <SidebarMenuButton tooltip={item.title} isActive={item.to === pathname} asChild={!!item.to}>
          {item.to ? (
            <Link to={item.to}>
              <item.icon />
              <span>{item.title}</span>
            </Link>
          ) : (
            <>
              <item.icon />
              <span>{item.title}</span>
            </>
          )}
        </SidebarMenuButton>
      </SidebarMenuItem>
    );
  }

  return (
    <Collapsible defaultOpen className="group/collapsible">
      <SidebarMenuItem>
        <CollapsibleTrigger asChild>
          <SidebarMenuButton tooltip={item.title}>
            <item.icon />
            <span>{item.title}</span>
            <ChevronRight className="ml-auto transition-transform group-data-[state=open]/collapsible:rotate-90" />
          </SidebarMenuButton>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <SidebarMenuSub>
            {item.children.map((child) => (
              <SidebarMenuSubItem key={child.title}>
                <SidebarMenuSubButton isActive={child.to === pathname} asChild={!!child.to}>
                  {child.to ? <Link to={child.to}>{child.title}</Link> : <span>{child.title}</span>}
                </SidebarMenuSubButton>
              </SidebarMenuSubItem>
            ))}
          </SidebarMenuSub>
        </CollapsibleContent>
      </SidebarMenuItem>
    </Collapsible>
  );
}
