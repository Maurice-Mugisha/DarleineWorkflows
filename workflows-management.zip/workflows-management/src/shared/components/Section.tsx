import type { ElementType, ReactNode } from "react";
import { cn } from "@/shared/utils/cn";

interface SectionProps {
  id?: string;
  as?: ElementType;
  className?: string;
  containerClassName?: string;
  children: ReactNode;
}

export default function Section({
  id,
  as: Component = "section",
  className,
  containerClassName,
  children,
}: SectionProps) {
  return (
    <Component id={id} className={cn("scroll-mt-20 px-4 py-16 sm:py-24", className)}>
      <div className={cn("mx-auto w-full max-w-6xl", containerClassName)}>{children}</div>
    </Component>
  );
}
