import { memo } from "react";
import { Textarea } from "@/shared/ui/textarea";
import FormField from "@/shared/components/FormField";

interface TextareaFieldProps {
  id: string;
  label: string;
  value: string;
  onValueChange: (value: string) => void;
  error?: string;
  required?: boolean;
  placeholder?: string;
  className?: string;
}

function TextareaField({
  id,
  label,
  value,
  onValueChange,
  error,
  required = false,
  placeholder,
  className,
}: TextareaFieldProps) {
  return (
    <FormField id={id} label={label} error={error} required={required}>
      <Textarea
        id={id}
        placeholder={placeholder}
        className={className}
        value={value}
        aria-invalid={error !== undefined}
        onChange={(event) => onValueChange(event.target.value)}
      />
    </FormField>
  );
}

export default memo(TextareaField);
