import { LogOut, Settings, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import useAuth from "@/shared/hooks/useAuth";
import useLogout from "@/shared/hooks/useLogout";

const ACCOUNT_LINKS = [
  { label: "Profile", icon: User },
  { label: "Account settings", icon: Settings },
];

export default function UserMenu() {
  const { user } = useAuth();
  const { logout, isLoggingOut } = useLogout();

  const displayName = user ? `${user.firstName} ${user.lastName}`.trim() || user.email : "Signed in";
  const initials = user
    ? `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`.toUpperCase()
    : "??";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label="Open user menu"
          className="bg-primary text-primary-foreground focus-visible:ring-ring focus-visible:ring-offset-background flex size-9 items-center justify-center rounded-full text-sm font-medium transition-opacity outline-none hover:opacity-90 focus-visible:ring-2 focus-visible:ring-offset-2"
        >
          {initials}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-64">
        <DropdownMenuLabel className="flex items-center gap-3 font-normal">
          <span className="bg-primary text-primary-foreground flex size-10 items-center justify-center rounded-full text-sm font-medium">
            {initials}
          </span>
          <span className="grid">
            <span className="truncate text-sm font-medium">{displayName}</span>
            <span className="text-muted-foreground text-xs">
              {user?.jobTitle || user?.email || "Signed in"}
            </span>
          </span>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {ACCOUNT_LINKS.map((link) => (
          <DropdownMenuItem key={link.label}>
            <link.icon />
            {link.label}
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <DropdownMenuItem disabled={isLoggingOut} onClick={() => logout()}>
          <LogOut />
          {isLoggingOut ? "Signing out..." : "Sign out"}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
