import type { ReactNode } from "react";
import Logo from "@/shared/components/Logo";
import ThemeMenu from "@/shared/components/ThemeMenu";

interface AuthLayoutProps {
  title: string;
  description: string;
  children: ReactNode;
  footer: ReactNode;
}

export default function AuthLayout({ title, description, children, footer }: AuthLayoutProps) {
  return (
    <div className="flex min-h-svh flex-col">
      <header className="flex items-center justify-between px-4 py-4 sm:px-6">
        <Logo />
        <ThemeMenu />
      </header>
      <main className="flex flex-1 items-center justify-center px-4 py-10">
        <div className="w-full max-w-md">
          <div className="mb-6 text-center">
            <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
            <p className="text-muted-foreground mt-2 text-sm">{description}</p>
          </div>
          {children}
          <div className="text-muted-foreground mt-6 text-center text-sm">{footer}</div>
        </div>
      </main>
    </div>
  );
}
