import type { ReactNode } from "react";
import { AuthContext } from "@/shared/hooks/useAuth";
import useAuthState from "@/shared/hooks/useAuthState";

interface AuthProviderProps {
  children: ReactNode;
}

export default function AuthProvider({ children }: AuthProviderProps) {
  const authContextValue = useAuthState();

  return <AuthContext value={authContextValue}>{children}</AuthContext>;
}
