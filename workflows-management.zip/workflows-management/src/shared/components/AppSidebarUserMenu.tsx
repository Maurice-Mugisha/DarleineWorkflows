import { ChevronsUpDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/shared/ui/dropdown-menu";
import { SidebarMenu, SidebarMenuButton, SidebarMenuItem } from "@/shared/ui/sidebar";
import useAuth from "@/shared/hooks/useAuth";
import useLogout from "@/shared/hooks/useLogout";

export default function AppSidebarUserMenu() {
  const { user } = useAuth();
  const { logout, isLoggingOut } = useLogout();

  const displayName = user ? `${user.firstName} ${user.lastName}`.trim() || user.email : "Signed in";
  const initial = displayName.charAt(0).toUpperCase();

  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <SidebarMenuButton size="lg">
              <span className="bg-primary text-primary-foreground flex size-8 items-center justify-center rounded-md text-sm font-medium">
                {initial}
              </span>
              <span className="grid flex-1 text-left text-sm">
                <span className="truncate font-medium">{displayName}</span>
                {user?.email ? (
                  <span className="text-muted-foreground truncate text-xs">{user.email}</span>
                ) : null}
              </span>
              <ChevronsUpDown className="ml-auto size-4" />
            </SidebarMenuButton>
          </DropdownMenuTrigger>
          <DropdownMenuContent side="right" align="end" className="w-56">
            <DropdownMenuLabel className="font-normal">
              <span className="block truncate text-sm font-medium">{displayName}</span>
              {user?.email ? (
                <span className="text-muted-foreground block truncate text-xs">{user.email}</span>
              ) : null}
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem disabled={isLoggingOut} onClick={() => logout()}>
              {isLoggingOut ? "Signing out..." : "Sign out"}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </SidebarMenuItem>
    </SidebarMenu>
  );
}
