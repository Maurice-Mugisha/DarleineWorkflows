import { Link } from "react-router-dom";
import { Workflow } from "lucide-react";
import { ROUTE_PATHS } from "@/routes/routePaths";
import { cn } from "@/shared/utils/cn";

interface LogoProps {
  className?: string;
}

export default function Logo({ className }: LogoProps) {
  return (
    <Link
      to={ROUTE_PATHS.landing}
      className={cn("flex items-center gap-2 font-semibold tracking-tight", className)}
    >
      <span className="bg-primary text-primary-foreground flex size-8 items-center justify-center rounded-md">
        <Workflow className="size-5" />
      </span>
      <span className="text-lg">Flowspace</span>
    </Link>
  );
}
