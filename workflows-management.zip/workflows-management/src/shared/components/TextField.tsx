import { memo, type ComponentProps } from "react";
import { Input } from "@/shared/ui/input";
import FormField from "@/shared/components/FormField";

interface TextFieldProps {
  id: string;
  label: string;
  value: string;
  onValueChange: (value: string) => void;
  error?: string;
  required?: boolean;
  type?: ComponentProps<"input">["type"];
  placeholder?: string;
  autoComplete?: string;
  min?: number;
  max?: number;
}

function TextField({
  id,
  label,
  value,
  onValueChange,
  error,
  required = false,
  type = "text",
  placeholder,
  autoComplete,
  min,
  max,
}: TextFieldProps) {
  return (
    <FormField id={id} label={label} error={error} required={required}>
      <Input
        id={id}
        type={type}
        placeholder={placeholder}
        autoComplete={autoComplete}
        min={min}
        max={max}
        value={value}
        aria-invalid={error !== undefined}
        onChange={(event) => onValueChange(event.target.value)}
      />
    </FormField>
  );
}

export default memo(TextField);
