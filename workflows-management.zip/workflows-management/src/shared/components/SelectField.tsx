import { memo, useMemo } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/shared/ui/select";
import FormField from "@/shared/components/FormField";

interface SelectFieldOption {
  value: string;
  label: string;
}

interface SelectFieldProps {
  id: string;
  label: string;
  placeholder: string;
  value: string;
  options: SelectFieldOption[];
  error?: string;
  required?: boolean;
  onValueChange: (value: string) => void;
}

function SelectField({
  id,
  label,
  placeholder,
  value,
  options,
  error,
  required = false,
  onValueChange,
}: SelectFieldProps) {
  const optionItems = useMemo(
    () =>
      options.map((option) => (
        <SelectItem key={option.value} value={option.value}>
          {option.label}
        </SelectItem>
      )),
    [options],
  );

  return (
    <FormField id={id} label={label} error={error} required={required}>
      <Select value={value} onValueChange={onValueChange}>
        <SelectTrigger id={id} className="w-full" aria-invalid={error !== undefined}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>{optionItems}</SelectContent>
      </Select>
    </FormField>
  );
}

export default memo(SelectField);
