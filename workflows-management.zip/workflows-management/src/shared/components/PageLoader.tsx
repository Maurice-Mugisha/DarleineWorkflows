import { Loader2 } from "lucide-react";

export default function PageLoader() {
  return (
    <div className="flex min-h-64 items-center justify-center">
      <Loader2 className="text-muted-foreground size-6 animate-spin" />
    </div>
  );
}
