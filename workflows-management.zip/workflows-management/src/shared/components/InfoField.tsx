import type { LucideIcon } from "lucide-react";

interface InfoFieldProps {
  icon: LucideIcon;
  label: string;
  value: string;
}

export default function InfoField({ icon: Icon, label, value }: InfoFieldProps) {
  return (
    <div className="border-border bg-muted/30 flex items-start gap-3 rounded-md border p-4">
      <span className="bg-background text-muted-foreground flex size-9 shrink-0 items-center justify-center rounded-md border">
        <Icon className="size-4" />
      </span>
      <div className="min-w-0">
        <p className="text-muted-foreground text-xs font-medium tracking-wide uppercase">{label}</p>
        <p className="mt-0.5 text-sm font-medium break-words">{value || "—"}</p>
      </div>
    </div>
  );
}
