import { memo } from "react";
import { Eye, EyeOff } from "lucide-react";
import { Input } from "@/shared/ui/input";
import FormField from "@/shared/components/FormField";
import usePasswordVisibility from "@/shared/hooks/usePasswordVisibility";

interface PasswordFieldProps {
  id: string;
  label: string;
  value: string;
  onValueChange: (value: string) => void;
  error?: string;
  required?: boolean;
  placeholder?: string;
  autoComplete?: string;
}

function PasswordField({
  id,
  label,
  value,
  onValueChange,
  error,
  required = false,
  placeholder,
  autoComplete,
}: PasswordFieldProps) {
  const { isVisible, inputType, toggleVisibility } = usePasswordVisibility();

  return (
    <FormField id={id} label={label} error={error} required={required}>
      <div className="relative">
        <Input
          id={id}
          type={inputType}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className="pr-10"
          value={value}
          aria-invalid={error !== undefined}
          onChange={(event) => onValueChange(event.target.value)}
        />
        <button
          type="button"
          onClick={toggleVisibility}
          aria-label={isVisible ? "Hide password" : "Show password"}
          aria-pressed={isVisible}
          className="text-muted-foreground hover:text-foreground absolute inset-y-0 right-0 flex items-center px-3 transition-colors"
        >
          {isVisible ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
        </button>
      </div>
    </FormField>
  );
}

export default memo(PasswordField);
