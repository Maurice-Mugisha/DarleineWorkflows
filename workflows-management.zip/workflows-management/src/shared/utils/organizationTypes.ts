export interface SelectOption {
  value: string;
  label: string;
}

export const ORGANIZATION_TYPES: SelectOption[] = [
  { value: "private_company", label: "Private company" },
  { value: "public_company", label: "Public company" },
  { value: "startup", label: "Startup" },
  { value: "non_profit", label: "Non-profit" },
  { value: "government", label: "Government agency" },
  { value: "educational", label: "Educational institution" },
  { value: "healthcare", label: "Healthcare" },
  { value: "financial", label: "Financial services" },
  { value: "freelance", label: "Freelance / Sole proprietor" },
  { value: "other", label: "Other" },
];
