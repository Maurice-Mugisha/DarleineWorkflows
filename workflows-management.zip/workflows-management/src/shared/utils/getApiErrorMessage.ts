import axios from "axios";

interface FastApiValidationIssue {
  msg?: unknown;
}

function extractValidationMessage(detail: unknown): string | undefined {
  if (!Array.isArray(detail) || detail.length === 0) {
    return undefined;
  }
  const firstIssue = detail[0] as FastApiValidationIssue;
  return typeof firstIssue?.msg === "string" ? firstIssue.msg : undefined;
}

export default function getApiErrorMessage(error: unknown, fallbackMessage: string): string {
  if (axios.isAxiosError(error)) {
    if (error.response === undefined) {
      return "Unable to reach the server. Please check your connection and try again.";
    }

    const responseData = error.response.data as { detail?: unknown; message?: unknown } | undefined;

    if (typeof responseData?.detail === "string") {
      return responseData.detail;
    }

    const validationMessage = extractValidationMessage(responseData?.detail);
    if (validationMessage !== undefined) {
      return validationMessage;
    }

    if (typeof responseData?.message === "string") {
      return responseData.message;
    }

    if (error.response.status >= 500) {
      return "Something went wrong on the server. Please try again later.";
    }
  }
  return fallbackMessage;
}
