import {
  LayoutDashboard,
  Workflow,
  FileText,
  Users,
  ShieldCheck,
  KeyRound,
  Building2,
  Clock,
} from "lucide-react";
import type { NavGroup } from "@/shared/types/navigation";
import { ROUTE_PATHS } from "@/routes/routePaths";

export const DASHBOARD_NAVIGATION: NavGroup[] = [
  {
    label: "Overview",
    items: [{ title: "Dashboard", icon: LayoutDashboard, to: ROUTE_PATHS.dashboard }],
  },
  {
    label: "Workflows",
    items: [
      {
        title: "Workflows",
        icon: Workflow,
        children: [
          { title: "All workflows", to: ROUTE_PATHS.workflows },
          { title: "Workflow Cases", to: ROUTE_PATHS.cases },
        ],
      },
      { title: "Reports", icon: FileText, to: ROUTE_PATHS.reports },
    ],
  },
  {
    label: "People & access",
    items: [
      { title: "Members", icon: Users, to: ROUTE_PATHS.members },
      { title: "Roles", icon: ShieldCheck, to: ROUTE_PATHS.roles },
      { title: "Privileges", icon: KeyRound, to: ROUTE_PATHS.privileges },
    ],
  },
  {
    label: "Settings",
    items: [
      { title: "Workspace", icon: Building2, to: ROUTE_PATHS.workspace },
      { title: "Time units", icon: Clock, to: ROUTE_PATHS.timeUnits },
    ],
  },
];
