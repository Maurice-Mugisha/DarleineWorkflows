export default function getInitialsFromEmail(email: string): string {
  const localPart = email.split("@")[0] ?? "";
  const segments = localPart.split(/[._+-]/).filter((segment) => segment.length > 0);
  const initials = segments
    .slice(0, 2)
    .map((segment) => segment.charAt(0))
    .join("");

  if (initials.length > 0) {
    return initials.toUpperCase();
  }

  return email.charAt(0).toUpperCase() || "U";
}
