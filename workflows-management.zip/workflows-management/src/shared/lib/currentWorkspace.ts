const AUTH_STORAGE_KEY = "workflows-management-auth";

function forceLogout(): never {
  window.localStorage.removeItem(AUTH_STORAGE_KEY);
  window.location.href = "/401";
  throw new Error("Workspace ID not available. Redirecting to login.");
}

export default function getCurrentWorkspaceId(): string {
  try {
    const storedValue = window.localStorage.getItem(AUTH_STORAGE_KEY);
    if (storedValue === null) {
      forceLogout();
    }
    const parsedValue = JSON.parse(storedValue) as { workspaceId?: string };
    const workspaceId = parsedValue.workspaceId;
    if (typeof workspaceId !== "string" || workspaceId === "") {
      forceLogout();
    }
    return workspaceId;
  } catch {
    forceLogout();
  }
}
