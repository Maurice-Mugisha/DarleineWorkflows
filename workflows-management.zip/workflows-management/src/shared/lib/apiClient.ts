import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_URL;
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  withCredentials: true,
  headers: {
    "Content-Type": "application/json",
  },
});

interface ApiErrorHandlers {
  onUnauthorized: () => void;
  onForbidden: () => void;
}

let apiErrorHandlers: ApiErrorHandlers | null = null;

export function registerApiErrorHandlers(handlers: ApiErrorHandlers): void {
  apiErrorHandlers = handlers;
}

function isAuthEndpoint(url: string | undefined): boolean {
  return url?.includes("/authentication/") ?? false;
}

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (axios.isAxiosError(error) && !isAuthEndpoint(error.config?.url)) {
      const status = error.response?.status;
      if (status === 401) {
        apiErrorHandlers?.onUnauthorized();
      } else if (status === 403) {
        apiErrorHandlers?.onForbidden();
      }
    }
    return Promise.reject(error);
  },
);

export default apiClient;
