# Flowspace

A modern workflow management platform for designing, tracking, and improving multi-step processes. Built with React, TypeScript, and Vite.

## Tech stack

- **Vite 8** + **React 19** + **TypeScript 6**
- **Tailwind CSS v4** + **shadcn/ui** (new-york style)
- **React Router v7**, **Zod v4**, **Axios**, **react-hot-toast**
- **ESLint 10** (flat config) + **Prettier**

## Getting started

```bash
npm install
cp .env.example .env.local   # then fill in your backend URL and development flags
npm run dev
```

The app runs on `http://localhost:5173`. You'll need the FastAPI backend running at the URL configured in `VITE_API_URL`.

## Available commands

| Command                | Description                                           |
| ---------------------- | ----------------------------------------------------- |
| `npm run dev`          | Start the Vite dev server with HMR                    |
| `npm run build`        | Type-check (`tsc -b`) then produce a production build |
| `npm run preview`      | Preview the production build locally                  |
| `npm run lint`         | Run ESLint across the project                         |
| `npm run format`       | Format all files with Prettier                        |
| `npm run format:check` | Check formatting without writing changes              |

## Environment variables

See `.env.example` for the full list. The most important ones:

- `VITE_API_URL` — backend base URL (defaults to `http://192.168.1.91:8000`)
- `VITE_AUTH_BYPASS` — temporary dev flag to skip the backend login
- `VITE_WORKSPACE_ID` — overrides the hardcoded current workspace id
